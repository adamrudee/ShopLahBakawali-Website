<?php
session_start();
if (!isset($_SESSION['guestID'])) {
    $_SESSION['guestID'] = bin2hex(random_bytes(16));
}
$guestID = $_SESSION['guestID'];

// Database connection for SearchInterface.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// --- User ID for persistence ---
$customerID = isset($_SESSION['customerID']) ? $_SESSION['customerID'] : null;
$is_member = isset($_SESSION['is_member']) && $_SESSION['is_member'];

// --- Helper: get cart_id for user or guest ---
function get_cart_id($pdo, $customerID, $guestID) {
    if ($customerID) {
        $stmt = $pdo->prepare("SELECT cartID FROM cart WHERE customerID=?");
        $stmt->execute([$customerID]);
        $cart_id = $stmt->fetchColumn();
        if (!$cart_id) {
            $stmt = $pdo->prepare("INSERT INTO cart (customerID, totalPrice) VALUES (?, 0)");
            $stmt->execute([$customerID]);
            $cart_id = $pdo->lastInsertId();
        }
        return $cart_id;
    } else {
        $stmt = $pdo->prepare("SELECT cartID FROM cart WHERE guestID=?");
        $stmt->execute([$guestID]);
        $cart_id = $stmt->fetchColumn();
        if (!$cart_id) {
            $stmt = $pdo->prepare("INSERT INTO cart (guestID, totalPrice) VALUES (?, 0)");
            $stmt->execute([$guestID]);
            $cart_id = $pdo->lastInsertId();
        }
        return $cart_id;
    }
}

// --- Helper: get wishlist_id for user ---
function get_wishlist_id($pdo, $customerID) {
    $wishlist_id = null;
    $stmt = $pdo->prepare("SELECT wishlistID FROM customer WHERE customerID=?");
    if (!$stmt) {
        error_log("Failed to prepare SELECT statement");
        return null;
    }
    $stmt->execute([$customerID]);
    $wishlist_id = $stmt->fetchColumn();
    
    // If no wishlist exists, create one
    if (!$wishlist_id) {
        // Create new wishlist (wishlist table only has wishlistID as auto-increment)
        $stmt = $pdo->prepare("INSERT INTO wishlist () VALUES ()");
        if (!$stmt) {
            error_log("Failed to prepare INSERT wishlist statement");
            return null;
        }
        $stmt->execute();
        $wishlist_id = $pdo->lastInsertId();
        
        // Update customer table with the new wishlistID
        $stmt = $pdo->prepare("UPDATE customer SET wishlistID = ? WHERE customerID = ?");
        if (!$stmt) {
            error_log("Failed to prepare UPDATE customer statement");
            return null;
        }
        $stmt->execute([$wishlist_id, $customerID]);
    }
    
    return $wishlist_id;
}

// --- Handle AJAX for cart/wishlist ---
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    // Debug: log session customerID
    if (!isset($_SESSION['customerID'])) {
        echo json_encode(['success' => false, 'error' => 'No customerID in session', 'session' => $_SESSION]); exit;
    }
    if ($_POST['action'] === 'add_to_cart' && isset($_POST['product_id'])) {
        $pid = intval($_POST['product_id']);
        $qty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
        $cart_id = get_cart_id($pdo, $customerID, $guestID);
        // Check if product already in cart
        $stmt = $pdo->prepare("SELECT quantity FROM cart_product WHERE cartID=? AND productID=?");
        if (!$stmt) {
            echo json_encode(['success' => false, 'error' => 'Database error']); exit;
        }
        $stmt->execute([$cart_id, $pid]);
        if ($stmt->rowCount() > 0) {
            // Product exists, update quantity
            $stmt2 = $pdo->prepare("UPDATE cart_product SET quantity = quantity + ? WHERE cartID=? AND productID=?");
            if (!$stmt2) {
                echo json_encode(['success' => false, 'error' => 'Database error']); exit;
            }
            if (!$stmt2->execute([$qty, $cart_id, $pid])) {
                echo json_encode(['success' => false, 'error' => 'Update failed']); exit;
            }
        } else {
            // Product not in cart, insert new row
            $stmt2 = $pdo->prepare("INSERT INTO cart_product (cartID, productID, quantity) VALUES (?, ?, ?)");
            if (!$stmt2) {
                echo json_encode(['success' => false, 'error' => 'Database error']); exit;
            }
            if (!$stmt2->execute([$cart_id, $pid, $qty])) {
                echo json_encode(['success' => false, 'error' => 'Insert failed']); exit;
            }
        }
        echo json_encode(['success' => true, 'cart_count' => get_cart_count($pdo, $customerID, $guestID), 'cart_id' => $cart_id]); exit;
    }
    if ($_POST['action'] === 'add_to_wishlist' && isset($_POST['product_id'])) {
        $pid = intval($_POST['product_id']);
        if ($customerID) {
            $wishlist_id = get_wishlist_id($pdo, $customerID);
            if ($wishlist_id) {
                // Insert if not exists
                $stmt = $pdo->prepare("INSERT IGNORE INTO wishlist_product (wishlistID, productID) VALUES (?, ?)");
                if (!$stmt) {
                    echo json_encode(['success' => false, 'error' => 'Failed to prepare INSERT wishlist_product']); exit;
                }
                $stmt->execute([$wishlist_id, $pid]);
            }
        } else {
            if (!isset($_SESSION['wishlist'])) $_SESSION['wishlist'] = [];
            $_SESSION['wishlist'][$pid] = true;
        }
        echo json_encode(['success' => true, 'wishlist_count' => get_wishlist_count($pdo, $customerID)]); exit;
    }
    if ($_POST['action'] === 'remove_from_wishlist' && isset($_POST['product_id'])) {
        $pid = intval($_POST['product_id']);
        if ($customerID) {
            $wishlist_id = get_wishlist_id($pdo, $customerID);
            if ($wishlist_id) {
                $stmt = $pdo->prepare("DELETE FROM wishlist_product WHERE wishlistID=? AND productID=?");
                if (!$stmt) {
                    echo json_encode(['success' => false, 'error' => 'Failed to prepare DELETE wishlist_product']); exit;
                }
                $stmt->execute([$wishlist_id, $pid]);
            }
        } else {
            if (isset($_SESSION['wishlist'][$pid])) unset($_SESSION['wishlist'][$pid]);
        }
        echo json_encode(['success' => true, 'wishlist_count' => get_wishlist_count($pdo, $customerID)]); exit;
    }
    if ($_POST['action'] === 'get_counts') {
        echo json_encode([
            'cart_count' => get_cart_count($pdo, $customerID, $guestID),
            'wishlist_count' => get_wishlist_count($pdo, $customerID)
        ]); exit;
    }
    exit;
}

function get_cart_count($pdo, $customerID, $guestID) {
    $cart_id = get_cart_id($pdo, $customerID, $guestID);
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM cart_product WHERE cartID=?");
    $stmt->execute([$cart_id]);
    return intval($stmt->fetchColumn());
}

function get_wishlist_count($pdo, $customerID) {
    if ($customerID) {
        $wishlist_id = get_wishlist_id($pdo, $customerID);
        if ($wishlist_id) {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM wishlist_product WHERE wishlistID=?");
            if (!$stmt) {
                error_log("Failed to prepare COUNT wishlist_product statement");
                return 0;
            }
            $stmt->execute([$wishlist_id]);
            return intval($stmt->fetchColumn());
        } else {
            return 0;
        }
    } else {
        return isset($_SESSION['wishlist']) ? count($_SESSION['wishlist']) : 0;
    }
}

// --- Handle GET parameters for product display ---
$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : 'All';
$sort = isset($_GET['sort']) ? $_GET['sort'] : '';

// --- Build SQL query ---
$sql = "SELECT * FROM product WHERE 1";
$params = [];
if ($search !== '') {
    $sql .= " AND name LIKE ?";
    $params[] = "%$search%";
}
if ($category !== 'All' && $category !== '') {
    $sql .= " AND category = ?";
    $params[] = $category;
}
if ($sort === 'low') {
    $sql .= " ORDER BY price ASC";
} elseif ($sort === 'high') {
    $sql .= " ORDER BY price DESC";
} else {
    $sql .= " ORDER BY RAND()";
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

// --- Category list ---
$categories = ['All', 'Personal Care', 'Beverages', 'Dairy', 'Snacks', 'Household', 'Stationery'];

// --- Helper function for image paths ---
function get_image_path($image_filename) {
    if (empty($image_filename)) {
        return '../Images/placeholder.png'; // Default placeholder
    }
    return '../Images/' . $image_filename;
}

// --- Cart and wishlist counts (live via AJAX) ---
$cart_count = get_cart_count($pdo, $customerID, $guestID);
$wishlist_count = get_wishlist_count($pdo, $customerID);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Search | ShopLahBakawali</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    /* Base styles */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    body {
      background-color: #ffffff;
      color: #333;
      min-width: 100vw;
      min-height: 100vh;
      overflow-x: hidden;
    }
    .container {
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 20px;
    }
    header {
      background-color: #064e3b;
      color: white;
      width: 100%;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    .top-bar {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding: 10px 20px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      width: 100%;
    }
    .user-tools {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    .user-tools a {
      color: white;
      text-decoration: none;
      margin-left: 15px;
      font-size: 14px;
      display: flex;
      align-items: center;
    }
    .user-tools i {
      margin-right: 5px;
    }
    nav {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      gap: 30px;
      width: 100%;
    }
    .nav-history {
      display: inline-block;
      margin-left: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }
    .logo {
      height: 40px;
      margin-right: 40px;
    }
    .logo img {
      height: 100%;
    }
    .cart {
      margin-left: auto;
      margin-right: 20px;
    }
    .cart-icon {
      position: relative;
      color: white;
    }
    .cart-count {
      position: absolute;
      top: -8px;
      right: -8px;
      background-color: #ffcc00;
      color: #333;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      font-weight: bold;
    }
    .search-section {
      background-color: #f8f9fa;
      padding: 20px 0;
      margin-bottom: 20px;
    }
    .search-container {
      display: flex;
      align-items: center;
      background: white;
      border-radius: 30px;
      padding: 8px 20px;
      box-shadow: 0 2px 15px rgba(0,0,0,0.1);
      max-width: 800px;
      margin: 0 auto;
    }
    .search-container input {
      flex: 1;
      border: none;
      padding: 12px;
      font-size: 16px;
      outline: none;
      background: transparent;
    }
    .search-container button {
      background: #064e3b;
      border: none;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      cursor: pointer;
      color: white;
      font-size: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background-color 0.3s;
    }
    .search-container button:hover {
      background: #043927;
    }
    main {
      flex: 1;
      width: 100%;
      padding: 0;
    }
    .filters {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
      flex-wrap: wrap;
      gap: 10px;
      padding: 0 20px;
    }
    .categories, .sorting {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 8px;
    }
    .category-btn, .sort-btn {
      padding: 8px 15px;
      border-radius: 25px;
      background: white;
      border: 2px solid #064e3b;
      cursor: pointer;
      transition: all 0.3s;
      font-weight: 500;
      color: #064e3b;
      font-size: 0.9rem;
    }
    .category-btn:hover, .sort-btn:hover,
    .category-btn.active, .sort-btn.active {
      background: #064e3b;
      color: white;
    }
    .products-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      margin: 0 auto;
      padding: 0 20px;
    }
    .product-card {
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 3px 10px rgba(0,0,0,0.15);
      transition: transform 0.3s;
      height: 100%;
      display: flex;
      flex-direction: column;
    }
    .product-card:hover {
      transform: translateY(-5px);
    }
    .product-image {
      height: 180px;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 15px;
      background: #f8f9fa;
      position: relative;
    }
    .product-image img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }
    .product-info {
      padding: 20px;
      flex: 1;
      display: flex;
      flex-direction: column;
    }
    .product-title {
      display: block;
      font-weight: 600;
      margin-bottom: 12px;
      font-size: 1.1rem;
      color: #333;
    }
    .product-brand, .product-name {
      display: inline;
      color: #333;
    }
    .price-wishlist {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 15px;
    }
    .product-price {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .regular-price {
      color: #064e3b;
      font-weight: bold;
      font-size: 1.3rem;
    }

    .discount-badge {
      background-color: #ff6b00;
      color: white;
      padding: 2px 6px;
      border-radius: 8px;
      font-size: 0.7rem;
      font-weight: bold;
      align-self: flex-start;
      margin-top: 2px;
    }
    .wishlist-icon {
      color: #064e3b;
      cursor: pointer;
      font-size: 1.2rem;
      transition: color 0.3s;
      margin-left: 10px;
    }
    .wishlist-icon:hover {
      color: #ff4d4d;
    }
    .add-to-cart {
      width: 100%;
      padding: 12px;
      background-color: #064e3b;
      border: none;
      border-radius: 8px;
      color: white;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s;
      margin-top: auto;
      font-size: 1rem;
    }
    .add-to-cart:hover {
      background-color: #043927;
    }
    @media (max-width: 768px) {
      nav {
        flex-direction: column;
        align-items: flex-start;
      }
      .products-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
        padding: 0 10px;
      }
      .filters {
        flex-direction: column;
        gap: 15px;
        padding: 0 10px;
      }
      .categories, .sorting {
        justify-content: center;
      }
    }
  </style>
</head>
<body>
  <header>
    <div class="top-bar">
      <div class="user-tools">
        <a href="../4.Accounts/Wishlist.php"><i class="far fa-heart"></i> Wishlist</a>
        <a href="../4.Accounts/AccountCustomer.php"><i class="far fa-user"></i> Account</a>
      </div>
    </div>
    <nav>
      <a href="#" class="logo" id="bakawaliLogoLink">
        <img src="bakawaliLogo.png" alt="bakawali Logo">
      </a>
      <div class="nav-history">
        <button type="button" class="back-forward-btn" onclick="window.history.back();">
          <i class="fas fa-arrow-left"></i> Back
        </button>
        <button type="button" class="back-forward-btn" onclick="window.history.forward();">
          Forward <i class="fas fa-arrow-right"></i>
        </button>
      </div>
      <div class="cart">
        <a href="../5.Checkout/CartInterface.php" class="cart-icon">
          <i class="fas fa-shopping-cart"></i>
          <span class="cart-count"><?php echo $cart_count; ?></span>
        </a>
      </div>
    </nav>
  </header>
  <main>
    <section class="search-section">
      <div class="container">
        <form class="search-container" method="get" action="">
          <input type="text" name="q" placeholder="Search for groceries..." value="<?php echo htmlspecialchars($search); ?>">
          <button type="submit"><i class="fas fa-search"></i></button>
        </form>
      </div>
    </section>
    <div class="container">
      <div class="filters">
        <div class="categories">
          <span style="margin-right: 10px; font-weight: bold;">Categories:</span>
          <?php foreach ($categories as $cat): ?>
            <button type="button" class="category-btn<?php if ($category === $cat) echo ' active'; ?>" data-category="<?php echo htmlspecialchars($cat); ?>"><?php echo $cat; ?></button>
          <?php endforeach; ?>
        </div>
        <div class="sorting">
          <span style="margin-right: 10px; font-weight: bold;">Sort by:</span>
          <button type="button" class="sort-btn<?php if ($sort === 'low') echo ' active'; ?>" data-sort="low">Price: Low to High</button>
          <button type="button" class="sort-btn<?php if ($sort === 'high') echo ' active'; ?>" data-sort="high">Price: High to Low</button>
        </div>
      </div>
      <div class="products-grid">
        <?php if (count($result) === 0): ?>
          <p>No products found.</p>
        <?php else: ?>
          <?php
          // Get wishlist items for this user/session
          $wishlist_items = [];
          if ($customerID) {
              $wishlist_id = get_wishlist_id($pdo, $customerID);
              if ($wishlist_id) {
                  $stmt = $pdo->prepare("SELECT productID FROM wishlist_product WHERE wishlistID=?");
                  if (!$stmt) {
                      error_log("Failed to prepare SELECT wishlist_product statement");
                  } else {
                      $stmt->execute([$wishlist_id]);
                      $res = $stmt->fetchAll(PDO::FETCH_ASSOC);
                      foreach ($res as $r) $wishlist_items[$r['productID']] = true;
                  }
              }
          } else if (isset($_SESSION['wishlist'])) {
              foreach ($_SESSION['wishlist'] as $pid => $v) $wishlist_items[$pid] = true;
          }
          ?>
          <?php foreach ($result as $row): ?>
            <div class="product-card" data-product-id="<?php echo $row['productID']; ?>">
              <div class="product-image">
                <img src="<?php echo get_image_path($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
              </div>
              <div class="product-info">
                <div class="product-title">
                  <span class="product-brand"><?php echo htmlspecialchars($row['brand']); ?></span>
                  <span class="product-name"><?php echo htmlspecialchars($row['name']); ?></span>
                </div>
                <div class="price-wishlist">
                  <div class="product-price">
                    <span class="regular-price">RM <?php echo number_format($row['price'], 2); ?></span>
                  </div>
                  <button type="button" class="wishlist-icon-btn" data-product-id="<?php echo $row['productID']; ?>" style="background:none;border:none;cursor:pointer;">
                    <i class="<?php echo isset($wishlist_items[$row['productID']]) ? 'fas' : 'far'; ?> fa-heart wishlist-icon" style="color: <?php echo isset($wishlist_items[$row['productID']]) ? '#ff4d4d' : '#064e3b'; ?>;"></i>
                  </button>
                </div>
                <button type="button" class="add-to-cart" data-product-id="<?php echo $row['productID']; ?>">Add to Cart</button>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </main>
  <script>
    // Live update cart and wishlist counts
    function updateCounts() {
      fetch('', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'action=get_counts'})
        .then(r=>r.json()).then(data=>{
          document.querySelector('.cart-count').textContent = data.cart_count;
        });
    }

    // AJAX product fetcher
    function fetchProducts(params) {
      const url = new URL(window.location.href);
      Object.keys(params).forEach(key => url.searchParams.set(key, params[key]));
      fetch(url, {method: 'GET'})
        .then(r => r.text())
        .then(html => {
          // Extract just the products grid from the returned HTML
          const parser = new DOMParser();
          const doc = parser.parseFromString(html, 'text/html');
          const newGrid = doc.querySelector('.products-grid');
          if (newGrid) {
            document.querySelector('.products-grid').innerHTML = newGrid.innerHTML;
            attachProductEventListeners();
          }
        });
    }

    function attachProductEventListeners() {
      // Add to cart
      document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', function() {
          const card = btn.closest('.product-card');
          const pid = btn.dataset.productId;
          // Always add 1 quantity
          fetch('', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`action=add_to_cart&product_id=${pid}&quantity=1`})
            .then(r=>r.json()).then(data=>{
              updateCounts();
              btn.textContent = 'Added!';
              setTimeout(()=>{btn.textContent='Add to Cart';}, 1000);
            });
          // Flying animation
          const productImage = card.querySelector('.product-image img');
          if (productImage) {
            flyToCart(productImage);
          }
        });
      });
      // Wishlist toggle
      document.querySelectorAll('.wishlist-icon-btn').forEach(btn => {
        btn.addEventListener('click', function() {
          const pid = btn.dataset.productId;
          const icon = btn.querySelector('i');
          const isWishlisted = icon.classList.contains('fas');
          fetch('', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`action=${isWishlisted?'remove_from_wishlist':'add_to_wishlist'}&product_id=${pid}`})
            .then(r=>r.json()).then(data=>{
              updateCounts();
              if (isWishlisted) {
                icon.classList.remove('fas');
                icon.classList.add('far');
                icon.style.color = '#064e3b';
              } else {
                icon.classList.remove('far');
                icon.classList.add('fas');
                icon.style.color = '#ff4d4d';
              }
            });
        });
      });
    }

    function flyToCart(targetElement) {
      const cartIcon = document.querySelector('.cart-icon');
      if (!targetElement || !cartIcon) return;
      const targetRect = targetElement.getBoundingClientRect();
      const cartRect = cartIcon.getBoundingClientRect();
      const flyingImage = targetElement.cloneNode(true);
      flyingImage.style.cssText = `
        position: fixed;
        top: ${targetRect.top}px;
        left: ${targetRect.left}px;
        width: ${targetRect.width}px;
        height: ${targetRect.height}px;
        object-fit: contain;
        z-index: 10000;
        transition: all 1s cubic-bezier(0.5, 0, 0.75, 0);
        border-radius: 15px;
        pointer-events: none;
      `;
      document.body.appendChild(flyingImage);
      requestAnimationFrame(() => {
        flyingImage.style.top = `${cartRect.top + cartRect.height / 2 - 10}px`;
        flyingImage.style.left = `${cartRect.left + cartRect.width / 2 - 10}px`;
        flyingImage.style.width = '20px';
        flyingImage.style.height = '20px';
        flyingImage.style.transform = 'rotate(360deg)';
      });
      setTimeout(() => {
        if (flyingImage.parentNode) {
          document.body.removeChild(flyingImage);
        }
        cartIcon.style.transition = 'transform 0.2s ease';
        cartIcon.style.transform = 'scale(1.2)';
        setTimeout(() => {
          cartIcon.style.transform = 'scale(1)';
        }, 200);
      }, 1000);
    }

    document.addEventListener('DOMContentLoaded', function() {
      updateCounts();
      attachProductEventListeners();
      // Category filter
      document.querySelectorAll('.category-btn').forEach(btn => {
        btn.addEventListener('click', function() {
          document.querySelectorAll('.category-btn').forEach(b=>b.classList.remove('active'));
          btn.classList.add('active');
          const category = btn.dataset.category;
          const search = document.querySelector('.search-container input').value;
          const sortBtn = document.querySelector('.sort-btn.active');
          const sort = sortBtn ? sortBtn.dataset.sort : '';
          fetchProducts({q: search, category: category, sort: sort});
        });
      });
      // Sort filter
      document.querySelectorAll('.sort-btn').forEach(btn => {
        btn.addEventListener('click', function() {
          const wasActive = btn.classList.contains('active');
          document.querySelectorAll('.sort-btn').forEach(b=>b.classList.remove('active'));
          let sort = '';
          if (!wasActive) {
            btn.classList.add('active');
            sort = btn.dataset.sort;
          }
          const categoryBtn = document.querySelector('.category-btn.active');
          const category = categoryBtn ? categoryBtn.dataset.category : 'All';
          const search = document.querySelector('.search-container input').value;
          fetchProducts({q: search, category: category, sort: sort});
        });
      });
      // Real-time search
      const searchInput = document.querySelector('.search-container input');
      if (searchInput) {
        searchInput.addEventListener('input', function() {
          const search = searchInput.value;
          const categoryBtn = document.querySelector('.category-btn.active');
          const category = categoryBtn ? categoryBtn.dataset.category : 'All';
          const sortBtn = document.querySelector('.sort-btn.active');
          const sort = sortBtn ? sortBtn.dataset.sort : '';
          fetchProducts({q: search, category: category, sort: sort});
        });
      }
    });

    var logoLink = document.getElementById('bakawaliLogoLink');
    if (logoLink) {
      logoLink.addEventListener('click', function(e) {
        e.preventDefault();
        var isMember = sessionStorage.getItem('isMember') === 'true';
        if (isMember) {
          window.location.href = '../2.Homes/MemberHome\'s.php';
        } else {
          window.location.href = '../2.Homes/NonMemberHome\'s.php';
        }
      });
    }
  </script>
</body>
</html> 