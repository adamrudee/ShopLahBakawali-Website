<?php
session_start();
if (!isset($_SESSION['guestID'])) {
    $_SESSION['guestID'] = bin2hex(random_bytes(16));
}
$guestID = $_SESSION['guestID'];

// Database connection for ReceiptInterface.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$checkout_id = isset($_GET['checkout_id']) ? intval($_GET['checkout_id']) : 0;
$order = null;
$order_items = [];
$customerID = isset($_SESSION['customerID']) ? $_SESSION['customerID'] : null;

if ($checkout_id) {
    $stmt = $pdo->prepare("SELECT * FROM checkout WHERE checkoutID=?");
    $stmt->execute([$checkout_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($order && $order['cartID']) {
        $cart_id = $order['cartID'];
        $stmt_items = $pdo->prepare("SELECT cp.*, p.name, p.brand, p.price, p.image FROM cart_product cp JOIN product p ON cp.productID = p.productID WHERE cp.cartID=?");
        $stmt_items->execute([$cart_id]);
        $order_items = $stmt_items->fetchAll(PDO::FETCH_ASSOC);
        
        // Store purchased products before deleting cart items (only once)
        if (!isset($_SESSION['cart_cleared_' . $checkout_id])) {
            // Copy cart products to purchased_product
            $stmt_copy = $pdo->prepare("SELECT cp.*, p.name, p.brand, p.price, p.image FROM cart_product cp JOIN product p ON cp.productID = p.productID WHERE cp.cartID=?");
            $stmt_copy->execute([$cart_id]);
            $cart_products = $stmt_copy->fetchAll(PDO::FETCH_ASSOC);
            foreach ($cart_products as $item) {
                $stmt_insert = $pdo->prepare("INSERT INTO checkout_product (checkoutID, productID, quantity, price, name, brand, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt_insert->execute([
                    $checkout_id,
                    $item['productID'],
                    $item['quantity'],
                    $item['price'],
                    $item['name'],
                    $item['brand'],
                    $item['image']
                ]);
            }
            // Delete cart items after storing purchased products
            $stmt = $pdo->prepare("DELETE FROM cart_product WHERE cartID=?");
            $stmt->execute([$cart_id]);
            $_SESSION['cart_cleared_' . $checkout_id] = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Complete | ShopLahBakawali</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #ffffff;
      color: #333;
      min-width: 100vw;
      min-height: 100vh;
      overflow-x: hidden;
    }
    .container {
      width: 100%;
      max-width: 100%;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    header {
      background-color: #064e3b;
      color: white;
      padding: 10px 0;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      width: 100vw;
      margin: 0;
      position: relative;
      left: 50%;
      right: 50%;
      margin-left: -50vw;
      margin-right: -50vw;
    }
    .top-bar {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding: 0 20px 10px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      width: 100%;
      box-sizing: border-box;
    }
    .user-tools {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    .user-tools a {
      color: white;
      text-decoration: none;
      margin-left: 15px;
      font-size: 14px;
      display: flex;
      align-items: center;
    }
    .user-tools i {
      margin-right: 5px;
    }
    nav {
      display: flex;
      align-items: center;
      padding: 15px 40px;
      gap: 30px;
      width: 100%;
      box-sizing: border-box;
    }
    .logo {
      height: 40px;
      margin-right: 40px;
    }
    .logo img {
      height: 100%;
    }
    .nav-history {
      display: inline-block;
      margin-left: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }
    .breadcrumb {
      font-size: 0.8rem;
      color: #666;
      margin: 2rem 0 1rem 5rem;
    }
    .breadcrumb a {
      color: #064e3b;
      text-decoration: none;
      font-weight: 500;
    }
    .breadcrumb a:hover {
      text-decoration: underline;
    }
    .checkout-steps {
      display: flex;
      justify-content: center;
      margin-bottom: 30px;
    }
    .step {
      display: flex;
      flex-direction: column;
      align-items: center;
      position: relative;
      padding: 0 30px;
    }
    .step-number {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background-color: #ddd;
      color: #666;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      margin-bottom: 10px;
      z-index: 1;
    }
    .step.completed .step-number {
      background-color: #ffcc00;
      color: #333;
    }
    .step-name {
      color: #666;
      font-weight: 500;
    }
    .step.completed .step-name {
      color: #333;
    }
    .step::before {
      content: '';
      position: absolute;
      top: 20px;
      left: 0;
      right: 0;
      height: 3px;
      background-color: #ddd;
      z-index: 0;
    }
    .step:first-child::before {
      left: 50%;
    }
    .step:last-child::before {
      right: 50%;
    }
    .step.completed::before {
      background-color: #ffcc00;
    }
    h1, h2 {
      color: #2E7D32;
      font-size: 0.9rem;
    }
    p, table, .contact-info {
      font-size: 0.7rem;
    }
    .section {
      margin-bottom: 12px;
    }
    .order-summary table {
      width: 100%;
      border-collapse: collapse;
    }
    .order-summary th, .order-summary td {
      text-align: left;
      padding: 8px 8px;
      border-bottom: 1px solid #ddd;
    }
    .order-summary th {
      background-color: #f8f9fa;
      font-weight: 600;
      color: #333;
      padding: 15px 8px;
    }
    .order-summary td:last-child {
      text-align: right;
    }
    .order-summary tr:last-child td {
      font-weight: bold;
      color: #2e9933;
    }
    /* Specific spacing for quantity column */
    .order-summary th:nth-child(2), .order-summary td:nth-child(2) {
      padding: 8px 15px;
      text-align: center;
    }
    /* Specific spacing for price column */
    .order-summary th:nth-child(3), .order-summary td:nth-child(3) {
      padding: 8px 20px;
      text-align: right;
    }
    /* Align summary rows (subtotal, delivery fee, total paid) */
    .order-summary tr:not(:first-child) td:first-child {
      text-align: left;
    }
    .order-summary tr:not(:first-child) td:nth-child(2) {
      text-align: center;
      padding: 8px 15px;
    }
    .order-summary tr:not(:first-child) td:nth-child(3) {
      text-align: right;
      padding: 8px 20px;
    }
    .total {
      font-weight: bold;
      color: #2E7D32;
    }
    .buttons {
      display: flex;
      justify-content: space-between;
      margin-top: 12px;
    }
    .buttons a {
      background: #2E7D32;
      color: white;
      padding: 6px 12px;
      text-decoration: none;
      border-radius: 4px;
      font-size: 0.7rem;
    }
    .contact-info {
      color: #555;
    }
    .receipt-container {
      max-width: 600px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    @media (max-width: 768px) {
      nav {
        flex-direction: column;
        gap: 15px;
      }
      nav ul {
        margin-top: 15px;
      }
    }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
  <header>
    <div class="container">
      <div class="top-bar">
        <div class="user-tools">
          <a href="#"><i class="far fa-heart"></i> Wishlist</a>
          <a href="#"><i class="far fa-user"></i> Account</a>
        </div>
      </div>
      <nav>
        <a href="#" class="logo">
          <img src="bakawaliLogo.png" alt="SPEEDMART Logo" />
        </a>
        <div class="nav-history">
          <button type="button" class="back-forward-btn" onclick="window.history.back();">
            <i class="fas fa-arrow-left"></i> Back
          </button>
          <button type="button" class="back-forward-btn" onclick="window.history.forward();">
            Forward <i class="fas fa-arrow-right"></i>
          </button>
        </div>
      </nav>
    </div>
  </header>
  <main class="container">
    <div class="breadcrumb">
      <a href="#" id="breadcrumbHome">Home</a> / <span>cart</span>
    </div>
    <div class="checkout-steps">
      <div class="step completed">
        <div class="step-number">1</div>
        <div class="step-name">Cart</div>
      </div>
      <div class="step completed">
        <div class="step-number">2</div>
        <div class="step-name">Information</div>
      </div>
      <div class="step completed">
        <div class="step-number">3</div>
        <div class="step-name">Complete</div>
      </div>
    </div>
    <div class="receipt-container" id="receiptContainer">
      <?php if (!$order): ?>
        <h1 style="color:#c00">No order found</h1><p>Please complete your order first.</p>
      <?php else: ?>
        <h1>✅ Order Confirmed!</h1>
        <p>Thank you for your purchase, <strong> <?php echo htmlspecialchars($order['fullName'] ?? 'Customer'); ?></strong>! Your order has been successfully placed.</p>
        <div class="section">
          <h2>📅 Order Summary</h2>
          <p><strong>Order Number:</strong> #<?php echo $order['checkoutID']; ?></p>
          <p><strong>Estimated Delivery:</strong> <?php echo htmlspecialchars($order['deliveryMethod'] ?? 'Standard Delivery'); ?></p>
          <p><strong>Delivery Address:</strong><br>
            <?php echo htmlspecialchars($order['address'] ?? ''); ?><br>
            <?php echo htmlspecialchars($order['city'] ?? ''); ?>, <?php echo htmlspecialchars($order['postcode'] ?? ''); ?><br>
            <?php echo htmlspecialchars(ucfirst($order['state'] ?? '')); ?>, <?php echo htmlspecialchars(ucfirst($order['country'] ?? '')); ?>
          </p>
          <p><strong>Contact:</strong> <?php echo htmlspecialchars($order['email'] ?? ''); ?> | <?php echo htmlspecialchars($order['phoneNumber'] ?? ''); ?></p>
        </div>
        <div class="section order-summary">
          <h2>📦 Items Ordered</h2>
          <table>
            <tr><th>Item</th><th>Quantity</th><th>Price</th></tr>
            <?php 
            $subtotal = 0;
            foreach ($order_items as $item): 
              $itemTotal = $item['price'] * $item['quantity'];
              $subtotal += $itemTotal;
            ?>
              <tr>
                <td><?php echo htmlspecialchars($item['brand'] . ' ' . $item['name']); ?></td>
                <td><?php echo $item['quantity']; ?></td>
                <td>RM <?php echo number_format($itemTotal, 2); ?></td>
              </tr>
            <?php endforeach; ?>
            <tr><td><strong>Subtotal</strong></td><td></td><td><strong>RM <?php echo number_format($order['subtotal'] ?? $subtotal, 2); ?></strong></td></tr>
            <?php if (!empty($order['pointsDiscount']) && $order['pointsDiscount'] > 0): ?>
            <tr>
              <td><strong>Redeem Points (<?php echo $order['pointsRedeemed']; ?> pts)</strong></td>
              <td></td>
              <td style="color: #ff6b00;"><strong>-RM <?php echo number_format($order['pointsDiscount'], 2); ?></strong></td>
            </tr>
            <?php endif; ?>
            <tr><td><strong>Delivery Fee</strong></td><td></td><td><strong>RM <?php echo number_format($order['deliveryFee'] ?? 5.00, 2); ?></strong></td></tr>
            <tr><td><strong>Total Paid</strong></td><td></td><td><strong>RM <?php echo number_format($order['finalPrice'], 2); ?></strong></td></tr>
          </table>
        </div>
        <div class="section">
          <h2>💳 Payment Method</h2>
          <p><?php echo htmlspecialchars($order['paymentMethod']); ?></p>
        </div>
        <div class="section">
          <h2>🔍 Track Your Order</h2>
          <a href="CustomerTrackOrder.php">Track Order Status</a>
        </div>
        <div class="section contact-info">
          <p><strong>Need Help?</strong><br>
          Contact our customer support:<br>
          📞 1300-88-9989 | ✉️ support@ShopLahBakawali.my</p>
        </div>
        <div class="buttons">
          <a href="../2.Homes/MemberHome's.php">🏠 Back to Home</a>
          <a href="../3.Searches/SearchInterface.php">🛒 Continue Shopping</a>
        </div>
      <?php endif; ?>
    </div>
  </main>
  <script>
  // Membership-based logo redirect
  const logo = document.querySelector('.logo');
  if (logo) {
    logo.addEventListener('click', function(e) {
      e.preventDefault();
      var isMember = sessionStorage.getItem('isMember') === 'true';
      if (isMember) {
        window.location.href = '../2.Homes/MemberHome\'s.php';
      } else {
        window.location.href = '../2.Homes/NonMemberHome\'s.php';
      }
    });
  }
  // Wishlist and Account link handlers
  const wishlistLink = document.querySelector('.user-tools a[href="#"]:nth-child(1)');
  const accountLink = document.querySelector('.user-tools a[href="#"]:nth-child(2)');
  if (wishlistLink) {
    wishlistLink.addEventListener('click', function(e) {
      e.preventDefault();
      window.location.href = '../4.Accounts/Wishlist.php';
    });
  }
  if (accountLink) {
    accountLink.addEventListener('click', function(e) {
      e.preventDefault();
      window.location.href = '../4.Accounts/AccountCustomer.php';
    });
  }
  // Breadcrumb Home link redirect
  const breadcrumbHome = document.getElementById('breadcrumbHome');
  if (breadcrumbHome) {
    breadcrumbHome.addEventListener('click', function(e) {
      e.preventDefault();
      var isMember = sessionStorage.getItem('isMember') === 'true';
      if (isMember) {
        window.location.href = '../2.Homes/MemberHome\'s.php';
      } else {
        window.location.href = '../2.Homes/NonMemberHome\'s.php';
      }
    });
  }
  document.addEventListener('DOMContentLoaded', function() {
    var logoLink = document.getElementById('bakawaliLogoLink');
    if (logoLink) {
      logoLink.addEventListener('click', function(e) {
        e.preventDefault();
        var isMember = sessionStorage.getItem('isMember') === 'true';
        if (isMember) {
          window.location.href = '../2.Homes/MemberHome\'s.php';
        } else {
          window.location.href = '../2.Homes/NonMemberHome\'s.php';
        }
      });
    }
  });
  </script>
</body>
</html> 