<?php
session_start();
if (!isset($_SESSION['guestID'])) {
    $_SESSION['guestID'] = bin2hex(random_bytes(16));
}
$guestID = $_SESSION['guestID'];

// Database connection for CartInterface.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// --- User ID and membership status ---
$customerID = isset($_SESSION['customerID']) ? $_SESSION['customerID'] : null;
$is_member = isset($_SESSION['is_member']) && $_SESSION['is_member'];

// Fetch membership status and points from the database
$customer = null;
$points_balance = 0;
$membership_id = '';
if ($customerID) {
    $stmt = $pdo->prepare("SELECT c.membershipID, m.points FROM customer c LEFT JOIN membership m ON c.membershipID = m.membershipID WHERE c.customerID=?");
    $stmt->execute([$customerID]);
    $customer = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($customer) {
        $membership_id = $customer['membershipID'];
        $points_balance = $customer['points'];
    }
}

// --- Helper: get cart_id for user or guest ---
function get_cart_id($pdo, $customerID, $guestID) {
    if ($customerID) {
        $stmt = $pdo->prepare("SELECT cartID FROM cart WHERE customerID=?");
        $stmt->execute([$customerID]);
        $cart_id = $stmt->fetchColumn();
        if (!$cart_id) {
            $stmt = $pdo->prepare("INSERT INTO cart (customerID, totalPrice) VALUES (?, 0)");
            $stmt->execute([$customerID]);
            $cart_id = $pdo->lastInsertId();
        }
        return $cart_id;
    } else {
        $stmt = $pdo->prepare("SELECT cartID FROM cart WHERE guestID=?");
        $stmt->execute([$guestID]);
        $cart_id = $stmt->fetchColumn();
        if (!$cart_id) {
            $stmt = $pdo->prepare("INSERT INTO cart (guestID, totalPrice) VALUES (?, 0)");
            $stmt->execute([$guestID]);
            $cart_id = $pdo->lastInsertId();
        }
        return $cart_id;
    }
}

// --- Handle AJAX cart actions ---
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    $cart_id = get_cart_id($pdo, $customerID, $guestID);
    if ($_POST['action'] === 'update_quantity' && isset($_POST['product_id'], $_POST['quantity'])) {
        $pid = intval($_POST['product_id']);
        $qty = max(1, intval($_POST['quantity']));
        // Update or insert into cart_product
        $stmt = $pdo->prepare("SELECT quantity FROM cart_product WHERE cartID=? AND productID=?");
        $stmt->execute([$cart_id, $pid]);
        if ($stmt->rowCount() > 0) {
            $stmt2 = $pdo->prepare("UPDATE cart_product SET quantity=? WHERE cartID=? AND productID=?");
            $stmt2->execute([$qty, $cart_id, $pid]);
        } else {
            $stmt2 = $pdo->prepare("INSERT INTO cart_product (cartID, productID, quantity) VALUES (?, ?, ?)");
            $stmt2->execute([$cart_id, $pid, $qty]);
        }
        // Update totalPrice in cart table
        $stmt = $pdo->prepare("SELECT SUM(cp.quantity * p.price) FROM cart_product cp JOIN product p ON cp.productID = p.productID WHERE cp.cartID=?");
        $stmt->execute([$cart_id]);
        $totalPrice = $stmt->fetchColumn() ?: 0;
        $stmt = $pdo->prepare("UPDATE cart SET totalPrice=? WHERE cartID=?");
        $stmt->execute([$totalPrice, $cart_id]);
        echo json_encode(['success' => true]); exit;
    }
    if ($_POST['action'] === 'remove_item' && isset($_POST['product_id'])) {
        $pid = intval($_POST['product_id']);
        $stmt = $pdo->prepare("DELETE FROM cart_product WHERE cartID=? AND productID=?");
        $stmt->execute([$cart_id, $pid]);
        // Update totalPrice in cart table
        $stmt = $pdo->prepare("SELECT SUM(cp.quantity * p.price) FROM cart_product cp JOIN product p ON cp.productID = p.productID WHERE cp.cartID=?");
        $stmt->execute([$cart_id]);
        $totalPrice = $stmt->fetchColumn() ?: 0;
        $stmt = $pdo->prepare("UPDATE cart SET totalPrice=? WHERE cartID=?");
        $stmt->execute([$totalPrice, $cart_id]);
        echo json_encode(['success' => true]); exit;
    }
    if ($_POST['action'] === 'clear_cart') {
        $stmt = $pdo->prepare("DELETE FROM cart_product WHERE cartID=?");
        $stmt->execute([$cart_id]);
        // Update totalPrice in cart table
        $stmt = $pdo->prepare("UPDATE cart SET totalPrice=0 WHERE cartID=?");
        $stmt->execute([$cart_id]);
        echo json_encode(['success' => true]); exit;
    }
    if ($_POST['action'] === 'get_cart') {
        echo json_encode(['cart' => get_cart_items($pdo, $customerID, $guestID)]); exit;
    }
    exit;
}

function get_cart_items($pdo, $customerID, $guestID) {
    $items = [];
    $cart_id = get_cart_id($pdo, $customerID, $guestID);
    $sql = "SELECT cp.productID, cp.quantity, p.name, p.brand, p.price, p.category, p.image FROM cart_product cp JOIN product p ON cp.productID = p.productID WHERE cp.cartID=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$cart_id]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row) {
        $row['product_id'] = $row['productID'];
        $items[] = $row;
    }
    return $items;
}

// --- Get cart items for initial page load ---
$cart_items = get_cart_items($pdo, $customerID, $guestID);
$cart_id = $customerID ? get_cart_id($pdo, $customerID, $guestID) : null;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart | ShopLahBakawali</title>
    <style>
         /* Base styles */
         body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #ffffff;
            color: #333;
            min-width: 100vw;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .container {
            width: 100%;
            max-width: 100%;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Header styles */
        header {
            background-color: #064e3b;
            color: white;
            padding: 10px 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 100vw;
            margin: 0;
            position: relative;
            left: 50%;
            right: 50%;
            margin-left: -50vw;
            margin-right: -50vw;
        }

        /* Top bar styles */
        .top-bar {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding: 0 20px 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            width: 100%;
            box-sizing: border-box;
        }

        .user-tools {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-tools a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
        
        .user-tools i {
            margin-right: 5px;
        }

        /* Navigation styles */
        nav {
            display: flex;
            align-items: center;
            padding: 15px 40px;
            gap: 30px;
            width: 100%;
            box-sizing: border-box;
        }

        .logo {
            height: 40px;
            margin-right: 40px;
        }

        .logo img {
            height: 100%;
        }
        .nav-history {
          display: inline-block;
          margin-left: 20px;
        }
        .back-forward-btn {
          background-color: #064e3b;
          color: white;
          border: none;
          border-radius: 6px;
          padding: 8px 16px;
          margin: 0 5px;
          cursor: pointer;
          font-size: 1rem;
          transition: background 0.2s;
        }
        .back-forward-btn:hover {
          background-color: #053a2c;
        }
        
        /* Breadcrumb styles */
        .breadcrumb {
            font-size: 0.8rem;
            color: #666;
            margin: 2rem 0 1rem 5rem;
        }

        .breadcrumb a {
            color: #064e3b;
            text-decoration: none;
            font-weight: 500;
        }

        .breadcrumb a:hover {
            text-decoration: underline;
        }
        
        /* Checkout steps styles */
        .checkout-steps {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        
        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            padding: 0 30px;
        }
        
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #ddd;
            color: #666;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-bottom: 10px;
            z-index: 1;
        }
        
        .step.active .step-number {
            background-color: #006400;
            color: white;
        }
        
        .step::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 0;
            right: 0;
            height: 3px;
            background-color: #ddd;
            z-index: 0;
        }
        
        .step:first-child::before {
            left: 50%;
        }
        
        .step:last-child::before {
            right: 50%;
        }
        
        /* Cart title styles */
        .cart-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 20px 80px;
        }
        
        .cart-title h1 {
            font-size: 28px;
            color: #006400;
        }
        
        .continue-shopping {
            color: #006400;
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
        }
        
        .continue-shopping i {
            margin-right: 5px;
        }
        
        /* Cart content layout */
        .cart-content {
            display: flex;
            gap: 30px;
            margin: 0 80px 40px 80px;
        }
        
        /* Cart items styles */
        .cart-items {
            flex: 2;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            padding: 20px;
        }
        
        /* Membership status in cart */
        .membership-cart-status {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .membership-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .membership-badge {
            background-color: #28a745;
            color: white;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: bold;
        }

        .non-member-badge {
            background-color: #6c757d;
            color: white;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: bold;
        }

        .points-info {
            color: #28a745;
            font-weight: bold;
        }

        .points-redemption-section {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .redemption-toggle {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }

        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .slider {
            background-color: #28a745;
        }

        input:checked + .slider:before {
            transform: translateX(26px);
        }

        .redemption-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 10px;
            margin-top: 15px;
        }

        .redemption-option {
            background: white;
            border: 2px solid #28a745;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 0.9rem;
        }

        .redemption-option:hover {
            background: #28a745;
            color: white;
        }

        .redemption-option.selected {
            background: #28a745;
            color: white;
        }

        .redemption-option.disabled {
            border-color: #ccc;
            color: #ccc;
            cursor: not-allowed;
        }

        .redemption-option.disabled:hover {
            background: white;
            color: #ccc;
        }

        .redemption-points {
            font-weight: bold;
            font-size: 1rem;
        }

        .redemption-value {
            color: #666;
            font-size: 0.8rem;
        }

        .redemption-option.selected .redemption-value,
        .redemption-option:hover .redemption-value {
            color: white;
        }
        
        .cart-header {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr 0.5fr;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
            font-weight: bold;
            color: #666;
        }
        
        .cart-item {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr 0.5fr;
            align-items: center;
            padding: 20px 0;
            border-bottom: 1px solid #eee;
            transition: background-color 0.3s;
        }
        
        .cart-item:hover {
            background-color: #f9f9f9;
        }
        
        /* Product info styles */
        .product-info {
            display: flex;
            align-items: center;
        }
        
        .product-image {
            width: 80px;
            height: 80px;
            border-radius: 5px;
            overflow: hidden;
            margin-right: 15px;
        }
        
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .product-details h3 {
            font-size: 16px;
            margin-bottom: 5px;
        }
        
        .product-details p {
            color: #666;
            font-size: 14px;
        }
        
        .product-price {
            color: #006400;
            font-weight: bold;
        }
        
        /* Quantity control styles */
        .quantity-control {
            display: flex;
            align-items: center;
        }
        
        .quantity-btn {
            width: 30px;
            height: 30px;
            background-color: #f0f0f0;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .quantity-btn:hover {
            background-color: #e0e0e0;
        }
        
        .quantity-input {
            width: 50px;
            height: 30px;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin: 0 5px;
            /* Hide spinner arrows for number input */
        }
        /* Chrome, Safari, Edge, Opera */
        .quantity-input::-webkit-outer-spin-button,
        .quantity-input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        /* Firefox */
        .quantity-input[type=number] {
            -moz-appearance: textfield;
            appearance: none;
        }
        
        /* Cart summary styles */
        .cart-summary {
            flex: 1;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            padding: 20px;
            height: fit-content;
            position: sticky;
            top: 100px;
        }
        
        .summary-title {
            font-size: 20px;
            margin-bottom: 20px;
            color: #006400;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 15px;
        }
        
        .summary-row.total {
            font-size: 18px;
            font-weight: bold;
            color: #006400;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        
        /* Checkout button styles */
        .checkout-btn {
            width: 100%;
            padding: 15px;
            background-color: #ffcc00;
            border: none;
            border-radius: 5px;
            color: #333;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .checkout-btn:hover {
            background-color: #e6b800;
        }
        
        .checkout-btn i {
            margin-right: 10px;
        }
        
        /* Remove button styles */
        .remove-btn {
            background: none;
            border: none;
            color: #ff4d4d;
            cursor: pointer;
            font-size: 1.2rem;
            padding: 5px;
            transition: color 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .remove-btn:hover {
            color: #cc0000;
        }

        .remove-btn i {
            font-size: 1.1rem;
        }
        
        /* Responsive styles */
        @media (max-width: 768px) {
            .cart-content {
                flex-direction: column;
                margin: 0 20px;
            }
            
            .cart-header, 
            .cart-item {
                grid-template-columns: 1.5fr 1fr 1fr 0.5fr;
            }
            
            .product-info {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .product-image {
                margin-bottom: 10px;
                margin-right: 0;
            }

            nav {
                flex-direction: column;
                padding: 15px 20px;
            }

            .main-menu {
                margin-top: 15px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="top-bar">
                <div class="user-tools">
                    <a href="../4.Accounts/Wishlist.php"><i class="far fa-heart"></i> Wishlist</a>
                    <a href="../4.Accounts/AccountCustomer.php"><i class="far fa-user"></i> Account</a>
                </div>
            </div>
            <nav>
                <a href="#" class="logo" id="bakawaliLogoLink">
                    <img src="bakawaliLogo.png" alt="SPEEDMART Logo" />
                </a>
                <div class="nav-history">
                    <button type="button" class="back-forward-btn" onclick="window.history.back();">
                        <i class="fas fa-arrow-left"></i> Back
                    </button>
                    <button type="button" class="back-forward-btn" onclick="window.history.forward();">
                        Forward <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </nav>
        </div>
    </header>
    <main class="container">
        <div class="breadcrumb">
            <a href="../2.Homes/MemberHome's.php">Home</a> / <span>cart</span>
        </div>
        <div class="checkout-steps">
            <div class="step active">
                <div class="step-number">1</div>
                <div class="step-name">Cart</div>
            </div>
            <div class="step">
                <div class="step-number">2</div>
                <div class="step-name">Information</div>
            </div>
            <div class="step">
                <div class="step-number">3</div>
                <div class="step-name">Complete</div>
            </div>
        </div>
        <div class="cart-title">
            <h1>Your Shopping Cart</h1>
            <a href="../3.Searches/SearchInterface.php" class="continue-shopping">
                <i class="fas fa-arrow-left"></i>
                Continue Shopping
            </a>
        </div>
        <div class="cart-content">
            <div class="cart-items" id="cartItemsContainer">
                <!-- Membership Status Display -->
                <div class="membership-cart-status" id="membershipStatus">
                    <?php if ($is_member): ?>
                        <div class="membership-info">
                            <span class="membership-badge">MEMBER</span>
                            <span>Member ID: <?php echo htmlspecialchars($membership_id); ?></span>
                        </div>
                        <div class="points-info">
                            Points Balance: <?php echo $points_balance; ?> pts<br>
                            <small style="color: #666;">100 pts = RM 0.50</small>
                        </div>
                    <?php else: ?>
                        <div class="membership-info">
                            <span class="non-member-badge">NON-MEMBER</span>
                            <span>Regular pricing</span>
                        </div>
                        <a href="../1.Login/Membership.php" style="color: #28a745; text-decoration: none; font-weight: bold;">Join Membership for Points</a>
                    <?php endif; ?>
                </div>
                <?php if ($is_member): ?>
                <div class="points-redemption-section" id="pointsRedemptionSection">
                    <div class="redemption-toggle">
                        <span><strong>Redeem Points</strong></span>
                        <label class="toggle-switch">
                            <input type="checkbox" id="redemptionToggle">
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div id="redemptionOptions" style="display: none;">
                        <p style="margin-bottom: 10px; font-size: 0.9rem;">Points Conversion Rate:</p>
                        <div class="redemption-options">
                            <div class="redemption-option" data-points="100" data-value="0.50">
                                <div class="redemption-points">100 pts</div>
                                <div class="redemption-value">RM 0.50</div>
                            </div>
                            <div class="redemption-option" data-points="200" data-value="1.00">
                                <div class="redemption-points">200 pts</div>
                                <div class="redemption-value">RM 1.00</div>
                            </div>
                            <div class="redemption-option" data-points="500" data-value="2.50">
                                <div class="redemption-points">500 pts</div>
                                <div class="redemption-value">RM 2.50</div>
                            </div>
                            <div class="redemption-option" data-points="1000" data-value="5.00">
                                <div class="redemption-points">1000 pts</div>
                                <div class="redemption-value">RM 5.00</div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="cart-header">
                    <div>Product</div>
                    <div>Price</div>
                    <div>Quantity</div>
                    <div>Total</div>
                    <div></div>
                </div>
                <div id="cartItemsList">
                <?php if (empty($cart_items)): ?>
                    <div style="text-align:center; padding:40px; color:#666; grid-column:1/-1;">
                        <i class="fas fa-shopping-cart" style="font-size:3rem; margin-bottom:20px; color:#ddd;"></i>
                        <h3>Your cart is empty</h3>
                        <p>Add some products to get started!</p>
                        <a href="../3.Searches/SearchInterface.php" style="display:inline-block; margin-top:20px; padding:12px 24px; background:#064e3b; color:white; text-decoration:none; border-radius:8px; font-weight:500;">Continue Shopping</a>
                    </div>
                <?php else: ?>
                    <?php foreach ($cart_items as $item): ?>
                    <div class="cart-item" data-product-id="<?php echo $item['product_id']; ?>">
                        <div class="product-info">
                            <div class="product-image">
                                <img src="../Images/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            </div>
                            <div class="product-details">
                                <h3><?php echo htmlspecialchars($item['brand'] . ' ' . $item['name']); ?></h3>
                                <p style="color: #666; font-size: 0.9rem;">Category: <?php echo htmlspecialchars($item['category']); ?></p>
                            </div>
                        </div>
                        <div class="product-price">RM <?php echo number_format($item['price'], 2); ?></div>
                        <div class="quantity-control">
                            <button class="quantity-btn minus-btn">-</button>
                            <input type="number" class="quantity-input" value="<?php echo $item['quantity']; ?>" min="1">
                            <button class="quantity-btn plus-btn">+</button>
                        </div>
                        <div class="product-price">RM <?php echo number_format($item['price'] * $item['quantity'], 2); ?></div>
                        <button class="remove-btn" title="Remove item"><i class="fas fa-trash-alt"></i></button>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                </div>
            </div>
            <div class="cart-summary">
                <h3 class="summary-title">Order Summary</h3>
                <div class="summary-row" id="summarySubtotal">
                    <!-- Subtotal will be filled by JS -->
                </div>
                <div class="summary-row total" id="summaryTotal">
                    <!-- Total will be filled by JS -->
                </div>
                <input type="hidden" id="pointsToRedeemInput" name="points_to_redeem" value="0">
                <button class="checkout-btn" id="proceedToCheckoutBtn">
                    <i class="fas fa-lock"></i> Proceed to Checkout
                </button>
                <button class="clear-cart-btn" style="margin-top: 10px; padding: 10px 20px; background: #dc3545; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 500; width: 100%;">
                    <i class="fas fa-trash"></i> Clear Cart
                </button>
                <!-- Modal for checkout confirmation -->
                <div id="checkoutModal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.4);z-index:9999;align-items:center;justify-content:center;">
                    <div style="background:#fff;padding:32px 24px;border-radius:10px;max-width:350px;margin:auto;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,0.15);">
                        <div style="font-size:1.1em;margin-bottom:18px;">Are you sure you want to proceed to checkout?</div>
                        <button id="modalYesBtn" style="margin:0 10px;padding:10px 24px;background:#006400;color:#fff;border:none;border-radius:5px;font-weight:bold;cursor:pointer;">Yes</button>
                        <button id="modalCancelBtn" style="margin:0 10px;padding:10px 24px;background:#ccc;color:#333;border:none;border-radius:5px;font-weight:bold;cursor:pointer;">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        // Helper: fetch cart data from backend
        function fetchCartAndRender() {
            fetch('', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: 'action=get_cart'})
                .then(r => r.json())
                .then(data => renderCartItems(data.cart));
        }

        // Points balance from PHP
        const pointsBalance = <?php echo json_encode((int)$points_balance); ?>;
        const isMember = <?php echo json_encode($is_member); ?>;
        let redeemToggle = null;
        let pointsToRedeem = 0;
        let redeemValue = 0;
        let subtotal = 0;
        let totalItems = 0;

        // Render cart items and summary
        function renderCartItems(cartItems) {
            const cartItemsList = document.getElementById('cartItemsList');
            cartItemsList.innerHTML = '';
            subtotal = 0;
            totalItems = 0;
            if (!cartItems || cartItems.length === 0) {
                cartItemsList.innerHTML = `<div style="text-align:center; padding:40px; color:#666; grid-column:1/-1;">
                    <i class='fas fa-shopping-cart' style='font-size:3rem; margin-bottom:20px; color:#ddd;'></i>
                    <h3>Your cart is empty</h3>
                    <p>Add some products to get started!</p>
                    <a href="../3.Searches/SearchInterface.php" style="display:inline-block; margin-top:20px; padding:12px 24px; background:#064e3b; color:white; text-decoration:none; border-radius:8px; font-weight:500;">Continue Shopping</a>
                </div>`;
                document.getElementById('summarySubtotal').innerHTML = `<span>Subtotal</span><span>RM 0.00</span>`;
                let pointsRow = document.getElementById('summaryPoints');
                if (pointsRow) pointsRow.remove();
                document.getElementById('summaryTotal').innerHTML = `<span>Total</span><span>RM 0.00</span>`;
                return;
            }
            cartItems.forEach(item => {
                item.price = parseFloat(item.price); // Ensure price is a number
                subtotal += item.price * item.quantity;
                totalItems += item.quantity;
                cartItemsList.innerHTML += `
                    <div class="cart-item" data-product-id="${item.product_id}">
                        <div class="product-info">
                            <div class="product-image">
                                <img src="../Images/${item.image}" alt="${item.name}">
                            </div>
                            <div class="product-details">
                                <h3>${item.brand} ${item.name}</h3>
                                <p style="color: #666; font-size: 0.9rem;">Category: ${item.category}</p>
                            </div>
                        </div>
                        <div class="product-price">RM ${item.price.toFixed(2)}</div>
                        <div class="quantity-control">
                            <button class="quantity-btn minus-btn">-</button>
                            <input type="number" class="quantity-input" value="${item.quantity}" min="1">
                            <button class="quantity-btn plus-btn">+</button>
                        </div>
                        <div class="product-price">RM ${(item.price * item.quantity).toFixed(2)}</div>
                        <button class="remove-btn" title="Remove item"><i class="fas fa-trash-alt"></i></button>
                    </div>
                `;
            });
            updateOrderSummary();
            attachCartEventListeners();
        }

        function updateOrderSummary() {
            // Calculate redemption
            let canRedeem = false;
            pointsToRedeem = 0;
            redeemValue = 0;
            if (document.getElementById('redemptionToggle') && document.getElementById('redemptionToggle').checked && pointsBalance > 0) {
                canRedeem = true;
                // Max points that can be redeemed (cannot exceed subtotal)
                let maxRedeemableValue = subtotal;
                let maxPoints = Math.floor(maxRedeemableValue / 0.005);
                pointsToRedeem = Math.min(pointsBalance, maxPoints);
                redeemValue = pointsToRedeem * 0.005;
                // Round to 2 decimals for display
                redeemValue = Math.floor(redeemValue * 100) / 100;
            }
            // Subtotal row
            document.getElementById('summarySubtotal').innerHTML = `<span>Subtotal</span><span>RM ${subtotal.toFixed(2)}</span>`;
            // Points row
            let pointsRow = document.getElementById('summaryPoints');
            if (canRedeem && pointsToRedeem > 0) {
                if (!pointsRow) {
                    pointsRow = document.createElement('div');
                    pointsRow.className = 'summary-row';
                    pointsRow.id = 'summaryPoints';
                    document.querySelector('.cart-summary').insertBefore(pointsRow, document.getElementById('summaryTotal'));
                }
                pointsRow.innerHTML = `<span>Redeem Points (${pointsToRedeem} pts)</span><span style="color:#ff6b00;font-weight:bold;">-RM ${redeemValue.toFixed(2)}</span>`;
            } else if (pointsRow) {
                pointsRow.remove();
            }
            // Total row
            let total = subtotal - redeemValue;
            if (total < 0) total = 0;
            document.getElementById('summaryTotal').innerHTML = `<span>Total</span><span>RM ${total.toFixed(2)}</span>`;
            // Set hidden inputs for next step
            document.getElementById('pointsToRedeemInput').value = canRedeem ? pointsToRedeem : 0;
            if (!document.getElementById('redeemValueInput')) {
                let input = document.createElement('input');
                input.type = 'hidden';
                input.id = 'redeemValueInput';
                input.name = 'redeem_value';
                document.querySelector('.cart-summary').appendChild(input);
            }
            document.getElementById('redeemValueInput').value = canRedeem ? redeemValue : 0;
            // Show points earned for this order (after redemption) ONLY for members
            let earnedRow = document.getElementById('summaryEarnedPoints');
            if (isMember) {
                let pointsEarned = Math.floor(total * 10);
                if (!earnedRow) {
                    earnedRow = document.createElement('div');
                    earnedRow.className = 'summary-row';
                    earnedRow.id = 'summaryEarnedPoints';
                }
                earnedRow.innerHTML = `<span>Points Earned</span><span style="color:#28a745;font-weight:bold;">+${pointsEarned} pts</span>`;
                // Insert earnedRow right after the total row
                let totalRow = document.getElementById('summaryTotal');
                if (totalRow && totalRow.nextSibling !== earnedRow) {
                    totalRow.parentNode.insertBefore(earnedRow, totalRow.nextSibling);
                }
            } else {
                if (earnedRow) earnedRow.remove();
            }
        }

        // Attach event listeners to cart item controls
        function attachCartEventListeners() {
            document.querySelectorAll('.cart-item').forEach(item => {
                const pid = item.getAttribute('data-product-id');
                const minusBtn = item.querySelector('.minus-btn');
                const plusBtn = item.querySelector('.plus-btn');
                const qtyInput = item.querySelector('.quantity-input');
                const removeBtn = item.querySelector('.remove-btn');
                minusBtn.addEventListener('click', function() {
                    let qty = parseInt(qtyInput.value);
                    if (qty > 1) {
                        updateQuantity(pid, qty - 1);
                    }
                });
                plusBtn.addEventListener('click', function() {
                    let qty = parseInt(qtyInput.value);
                    updateQuantity(pid, qty + 1);
                });
                qtyInput.addEventListener('change', function() {
                    let qty = parseInt(qtyInput.value);
                    if (isNaN(qty) || qty < 1) {
                        qty = 1;
                        qtyInput.value = 1;
                    }
                    updateQuantity(pid, qty);
                });
                removeBtn.addEventListener('click', function() {
                    if (confirm('Remove this item from your cart?')) {
                        removeItem(pid);
                    }
                });
            });
            // Redeem points toggle
            redeemToggle = document.getElementById('redemptionToggle');
            if (redeemToggle) {
                redeemToggle.addEventListener('change', updateOrderSummary);
            }
        }

        // AJAX: update quantity
        function updateQuantity(pid, qty) {
            fetch('', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=update_quantity&product_id=${pid}&quantity=${qty}`})
                .then(r => r.json())
                .then(() => fetchCartAndRender());
        }
        // AJAX: remove item
        function removeItem(pid) {
            fetch('', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: `action=remove_item&product_id=${pid}`})
                .then(r => r.json())
                .then(() => fetchCartAndRender());
        }
        // AJAX: clear cart
        document.querySelector('.clear-cart-btn').addEventListener('click', function() {
            if (confirm('Are you sure you want to clear your cart?')) {
                fetch('', {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: 'action=clear_cart'})
                    .then(r => r.json())
                    .then(() => fetchCartAndRender());
            }
        });
        // Add redirect for Proceed to Checkout with modal confirmation
        const proceedBtn = document.getElementById('proceedToCheckoutBtn');
        const checkoutModal = document.getElementById('checkoutModal');
        const modalYesBtn = document.getElementById('modalYesBtn');
        const modalCancelBtn = document.getElementById('modalCancelBtn');
        if (proceedBtn) {
            proceedBtn.addEventListener('click', function(e) {
                e.preventDefault();
                const cartItems = document.querySelectorAll('.cart-item');
                if (cartItems.length > 0) {
                    checkoutModal.style.display = 'flex';
                } else {
                    alert('Your cart is empty!');
                }
            });
        }
        if (modalYesBtn) {
            modalYesBtn.addEventListener('click', function() {
                // Pass pointsToRedeem and redeemValue to next step (ShippingInterface.php)
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'ShippingInterface.php';
                // Add hidden fields
                const pointsInput = document.createElement('input');
                pointsInput.type = 'hidden';
                pointsInput.name = 'points_to_redeem';
                pointsInput.value = pointsToRedeem;
                form.appendChild(pointsInput);
                const valueInput = document.createElement('input');
                valueInput.type = 'hidden';
                valueInput.name = 'redeem_value';
                valueInput.value = redeemValue;
                form.appendChild(valueInput);
                document.body.appendChild(form);
                form.submit();
            });
        }
        if (modalCancelBtn) {
            modalCancelBtn.addEventListener('click', function() {
                checkoutModal.style.display = 'none';
            });
        }
        if (checkoutModal) {
            checkoutModal.addEventListener('click', function(e) {
                if (e.target === checkoutModal) checkoutModal.style.display = 'none';
            });
        }
        // Initial render
        fetchCartAndRender();
    });

    document.addEventListener('DOMContentLoaded', function() {
        var logoLink = document.getElementById('bakawaliLogoLink');
        if (logoLink) {
            logoLink.addEventListener('click', function(e) {
                e.preventDefault();
                var isMember = sessionStorage.getItem('isMember') === 'true';
                if (isMember) {
                    window.location.href = '../2.Homes/MemberHome\'s.php';
                } else {
                    window.location.href = '../2.Homes/NonMemberHome\'s.php';
                }
            });
        }
    });
    </script>
</body>
</html> 