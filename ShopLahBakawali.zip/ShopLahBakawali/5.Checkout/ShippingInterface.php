<?php
session_start();
if (!isset($_SESSION['guestID'])) {
    $_SESSION['guestID'] = bin2hex(random_bytes(16));
}
$guestID = $_SESSION['guestID'];

// Database connection for ShippingInterface.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// --- User ID ---
$customerID = isset($_SESSION['customerID']) ? $_SESSION['customerID'] : null;
$is_member = isset($_SESSION['is_member']) && $_SESSION['is_member'];

// Fetch customer details for autofill
$customer_email = '';
$customer_phone = '';
$customer_fullname = '';
if ($customerID) {
    $stmt = $pdo->prepare("SELECT email, phoneNumber, fullname FROM customer WHERE customerID=?");
    $stmt->execute([$customerID]);
    $customer_data = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($customer_data) {
        $customer_email = $customer_data['email'];
        $customer_phone = $customer_data['phoneNumber'];
        $customer_fullname = $customer_data['fullname'];
    }
}

// --- Helper: get cart_id for user or guest ---
function get_cart_id($pdo, $customerID, $guestID) {
    if ($customerID) {
        $stmt = $pdo->prepare("SELECT cartID FROM cart WHERE customerID=?");
        $stmt->execute([$customerID]);
        $cart_id = $stmt->fetchColumn();
        if (!$cart_id) {
            $stmt = $pdo->prepare("INSERT INTO cart (customerID, totalPrice) VALUES (?, 0)");
            $stmt->execute([$customerID]);
            $cart_id = $pdo->lastInsertId();
        }
        return $cart_id;
    } else {
        $stmt = $pdo->prepare("SELECT cartID FROM cart WHERE guestID=?");
        $stmt->execute([$guestID]);
        $cart_id = $stmt->fetchColumn();
        if (!$cart_id) {
            $stmt = $pdo->prepare("INSERT INTO cart (guestID, totalPrice) VALUES (?, 0)");
            $stmt->execute([$guestID]);
            $cart_id = $pdo->lastInsertId();
        }
        return $cart_id;
    }
}

// --- Helper: get cart items ---
function get_cart_items($pdo, $customerID, $guestID) {
    $items = [];
    $cart_id = get_cart_id($pdo, $customerID, $guestID);
    $sql = "SELECT cp.productID, cp.quantity, p.name, p.brand, p.price, p.category, p.image FROM cart_product cp JOIN product p ON cp.productID = p.productID WHERE cp.cartID=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$cart_id]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row) {
        $row['product_id'] = $row['productID'];
        $items[] = $row;
    }
    return $items;
}

// --- Get cart items for initial page load ---
$cart_items = get_cart_items($pdo, $customerID, $guestID);
$cart_id = $customerID ? get_cart_id($pdo, $customerID, $guestID) : null;

// --- Points redemption for display ---
$points_to_redeem = isset($_POST['points_to_redeem']) ? intval($_POST['points_to_redeem']) : 0;
$points_discount = $points_to_redeem * 0.005;
$subtotal = 0;
$totalItems = 0;
foreach ($cart_items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
    $totalItems += $item['quantity'];
}
$subtotal_after_redemption = max(0, $subtotal - $points_discount);
$deliveryFee = 5.00; // Default, will update with JS if instant delivery is selected
$finalPrice = $subtotal_after_redemption + $deliveryFee;

// Handle form submission
if (
    $_SERVER['REQUEST_METHOD'] == 'POST' && count($cart_items) &&
    isset(
        $_POST['fullName'], $_POST['email'], $_POST['phone'], $_POST['address'],
        $_POST['city'], $_POST['postcode'], $_POST['state'], $_POST['country'],
        $_POST['payment'], $_POST['delivery']
    )
) {
    $fullName = $_POST['fullName'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $postcode = $_POST['postcode'] ?? '';
    $state = $_POST['state'] ?? '';
    $country = $_POST['country'] ?? '';
    $payment = $_POST['payment'] ?? '';
    $delivery = $_POST['delivery'] ?? '';
    $points_to_redeem = isset($_POST['points_to_redeem']) ? intval($_POST['points_to_redeem']) : 0;
    
    $finalPrice = 0;
    foreach ($cart_items as $item) {
        $finalPrice += $item['price'] * $item['quantity'];
    }
    $deliveryFee = ($delivery === 'Instant Delivery') ? 10.00 : 5.00;
    $subtotal = $finalPrice;
    // Deduct points value from subtotal if redeeming
    $points_discount = $points_to_redeem * 0.005;
    $subtotal_after_redemption = max(0, $subtotal - $points_discount);
    $finalPrice = $subtotal_after_redemption + $deliveryFee;

    $stmt = $pdo->prepare("INSERT INTO checkout (
        finalPrice, paymentMethod, cartID, customerID, fullName, email, phoneNumber, address, city, postcode, state, country, subtotal, deliveryFee, deliveryMethod, pointsRedeemed, pointsDiscount
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $finalPrice, $payment, $cart_id, $customerID, $fullName, $email, $phone, $address, $city, $postcode, $state, $country, $subtotal, $deliveryFee, $delivery, $points_to_redeem, $points_discount
    ]);
    $checkout_id = $pdo->lastInsertId();

    // Insert tracking row for this order
    $stmt = $pdo->prepare("INSERT INTO tracking (shippingStatus, adminID, customerID, checkoutID) VALUES (?, NULL, ?, ?)");
    $stmt->execute(['Pending', $customerID, $checkout_id]);

    // Points logic for membership customers
    if ($customerID) {
        $stmt = $pdo->prepare("SELECT c.membershipID, m.points FROM customer c LEFT JOIN membership m ON c.membershipID = m.membershipID WHERE c.customerID=?");
        $stmt->execute([$customerID]);
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($customer && !empty($customer['membershipID'])) {
            // Reset points to zero, then add new points earned
            $points_earned = floor($subtotal_after_redemption * 10);
            $stmt = $pdo->prepare("UPDATE membership SET points=? WHERE membershipID=?");
            $stmt->execute([$points_earned, $customer['membershipID']]);
        }
    }

    // Don't delete cart items here - they will be deleted after customer sees receipt
    header("Location: ReceiptInterface.php?checkout_id=$checkout_id");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | ShopLahBakawali</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #ffffff;
            color: #333;
            min-width: 100vw;
            min-height: 100vh;
            overflow-x: hidden;
        }
        .container {
            width: 100%;
            max-width: 100%;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        header {
            background-color: #064e3b;
            color: white;
            padding: 10px 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 100vw;
            margin: 0;
            position: relative;
            left: 50%;
            right: 50%;
            margin-left: -50vw;
            margin-right: -50vw;
        }
        .top-bar {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding: 0 20px 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            width: 100%;
            box-sizing: border-box;
        }
        .user-tools {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .user-tools a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
        .user-tools i {
            margin-right: 5px;
        }
        nav {
            display: flex;
            align-items: center;
            padding: 15px 40px;
            gap: 30px;
            width: 100%;
            box-sizing: border-box;
        }
        .logo {
            height: 40px;
            margin-right: 40px;
        }
        .logo img {
            height: 100%;
        }
        .nav-history {
          display: inline-block;
          margin-left: 20px;
        }
        .back-forward-btn {
          background-color: #064e3b;
          color: white;
          border: none;
          border-radius: 6px;
          padding: 8px 16px;
          margin: 0 5px;
          cursor: pointer;
          font-size: 1rem;
          transition: background 0.2s;
        }
        .back-forward-btn:hover {
          background-color: #053a2c;
        }
        .breadcrumb {
            font-size: 0.8rem;
            color: #666;
            margin-bottom: 1rem;
            margin-top: 2rem;
            margin-left: 5rem;
        }
        .breadcrumb a {
            color: #064e3b;
            text-decoration: none;
            font-weight: 500;
        }
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        .checkout-steps {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
        }
        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            padding: 0 30px;
        }
        .step-number {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #ddd;
            color: #666;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-bottom: 10px;
            z-index: 1;
        }
        .step.active .step-number {
            background-color: #006400;
            color: white;
        }
        .step.completed .step-number {
            background-color: #ffcc00;
            color: #333;
        }
        .step-name {
            color: #666;
            font-weight: 500;
        }
        .step.active .step-name {
            color: #006400;
            font-weight: bold;
        }
        .step.completed .step-name {
            color: #333;
        }
        .step::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 0;
            right: 0;
            height: 3px;
            background-color: #ddd;
            z-index: 0;
        }
        .step:first-child::before {
            left: 50%;
        }
        .step:last-child::before {
            right: 50%;
        }
        .step.completed::before {
            background-color: #ffcc00;
        }
        .checkout-content {
            display: flex;
            gap: 30px;
            margin-bottom: 40px;
            margin-left: 80px;
        }
        .checkout-form {
            flex: 1;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            padding: 20px;
            margin-right: 20px;
        }
        .form-section {
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 18px;
            color: #006400;
            margin-bottom: 15px;
            padding-bottom: 8px;
            border-bottom: 1px solid #eee;
        }
        .form-row {
            display: flex;
            gap: 15px;
            margin-bottom: 12px;
        }
        .form-group {
            flex: 1;
        }
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
        }
        .form-group input, 
        .form-group select, 
        .form-group textarea {
            width: 90%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .form-group input:focus, 
        .form-group select:focus, 
        .form-group textarea:focus {
            border-color: #006400;
            outline: none;
        }
        .form-group.full-width {
            flex: 0 0 100%;
        }
        .delivery-options {
            display: flex;
            gap: 12px;
            margin-top: 12px;
        }
        .delivery-option {
            flex: 1;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 12px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .delivery-option:hover {
            border-color: #006400;
        }
        .delivery-option input {
            display: none;
        }
        .delivery-option.active {
            border-color: #006400;
            background: #f6fff6;
        }
        .delivery-option .radio-custom {
            width: 16px;
            height: 16px;
            border: 2px solid #ddd;
            border-radius: 50%;
            display: inline-block;
            position: relative;
            margin-right: 8px;
            vertical-align: middle;
            background: #fff;
        }
        .delivery-option.active .radio-custom {
            border-color: #006400;
        }
        .delivery-option .radio-custom::after {
            content: '';
            display: block;
            width: 13px;
            height: 13px;
            border-radius: 50%;
            background: #006400;
            position: absolute;
            top: 1.5px;
            left: 1.5px;
            opacity: 0;
            transition: opacity 0.2s;
        }
        .delivery-option.active .radio-custom::after {
            opacity: 1;
        }
        .delivery-option .option-title {
            font-weight: 500;
            margin-bottom: 4px;
            display: flex;
            align-items: center;
        }
        .delivery-option .option-desc {
            color: #666;
            font-size: 12px;
        }
        .delivery-option .option-price {
            color: #006400;
            font-weight: bold;
            margin-top: 4px;
        }
        .payment-methods {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 12px;
        }
        .payment-method {
            flex: 1 0 calc(33.333% - 12px);
            min-width: 120px;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 12px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
        }
        .payment-method:hover {
            border-color: #006400;
        }
        .payment-method input {
            display: none;
        }
        .payment-method.active {
            border-color: #006400;
            background: #f6fff6;
            box-shadow: 0 0 0 2px #c6f7d0;
        }
        .payment-method .method-icon {
            font-size: 24px;
            margin-bottom: 8px;
            color: #006400;
        }
        .payment-method .method-name {
            font-weight: 500;
        }
        .order-summary {
            flex: 1;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            padding: 30px;
            height: fit-content;
            position: sticky;
            top: 100px;
            margin-right: 80px;
        }
        .summary-title {
            font-size: 20px;
            color: #006400;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .order-items {
            margin-bottom: 20px;
        }
        .order-item {
            display: flex;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .order-item-img {
            width: 60px;
            height: 60px;
            border-radius: 5px;
            overflow: hidden;
            margin-right: 15px;
        }
        .order-item-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .order-item-details {
            flex: 1;
        }
        .order-item-name {
            font-weight: 500;
            margin-bottom: 5px;
        }
        .order-item-price {
            color: #006400;
            font-weight: bold;
        }
        .order-item-qty {
            color: #666;
            font-size: 14px;
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .summary-row.total {
            font-size: 18px;
            font-weight: bold;
            color: #006400;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        .checkout-btn {
            width: 100%;
            padding: 15px;
            background-color: #ffcc00;
            border: none;
            border-radius: 5px;
            color: #333;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .checkout-btn:hover {
            background-color: #e6b800;
        }
        .checkout-btn i {
            margin-right: 10px;
        }
        .secure-checkout {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
            color: #666;
        }
        @media (max-width: 768px) {
            .header-container {
                flex-direction: column;
                gap: 15px;
            }
            nav ul {
                margin-top: 15px;
            }
            .checkout-content {
                flex-direction: column;
            }
            .form-row {
                flex-direction: column;
                gap: 15px;
            }
            .delivery-options {
                flex-direction: column;
            }
            .payment-method {
                flex: 1 0 calc(50% - 15px);
            }
            .order-summary {
                position: static;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="top-bar">
                <div class="user-tools">
                    <a href="#"><i class="far fa-heart"></i> Wishlist</a>
                    <a href="#"><i class="far fa-user"></i> Account</a>
                </div>
            </div>
            <nav>
                <a href="#" class="logo">
                    <img src="bakawaliLogo.png" alt="SPEEDMART Logo" />
                </a>
                <div class="nav-history">
                    <button type="button" class="back-forward-btn" onclick="window.history.back();">
                        <i class="fas fa-arrow-left"></i> Back
                    </button>
                    <button type="button" class="back-forward-btn" onclick="window.history.forward();">
                        Forward <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </nav>
        </div>
    </header>
    <main class="container">
        <div class="breadcrumb">
            <a href="#" id="breadcrumbHome">Home</a> / <span>Shipping</span>
        </div>
        <div class="checkout-steps">
            <div class="step completed">
                <div class="step-number">1</div>
                <div class="step-name">Cart</div>
            </div>
            <div class="step active">
                <div class="step-number">2</div>
                <div class="step-name">Information</div>
            </div>
            <div class="step">
                <div class="step-number">3</div>
                <div class="step-name">Complete</div>
            </div>
        </div>
        <div class="checkout-content">
            <div class="checkout-form">
                <form method="post" id="shippingForm">
                    <div class="form-section">
                        <h3 class="section-title">Contact Information</h3>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" name="email" placeholder="your@email.com" required value="<?php echo htmlspecialchars($customer_email); ?>">
                            </div>
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="tel" name="phone" placeholder="012-345 6789" required value="<?php echo htmlspecialchars($customer_phone); ?>">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group full-width">
                                <label>Full Name</label>
                                <input type="text" name="fullName" placeholder="John" required value="<?php echo htmlspecialchars($customer_fullname); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-section">
                        <h3 class="section-title">Shipping Address</h3>
                        <div class="form-row">
                            <div class="form-group full-width">
                                <label>Address</label>
                                <input type="text" name="address" placeholder="Street address" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>City</label>
                                <input type="text" name="city" placeholder="Kuala Lumpur" required>
                            </div>
                            <div class="form-group">
                                <label>Postcode</label>
                                <input type="text" name="postcode" placeholder="50000" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>State</label>
                                <select name="state" required>
                                    <option value="">Select State</option>
                                    <option value="johor">Johor</option>
                                    <option value="kedah">Kedah</option>
                                    <option value="kelantan">Kelantan</option>
                                    <option value="kl">Kuala Lumpur</option>
                                    <option value="melaka">Melaka</option>
                                    <option value="ns">Negeri Sembilan</option>
                                    <option value="pahang">Pahang</option>
                                    <option value="penang">Penang</option>
                                    <option value="perak">Perak</option>
                                    <option value="perlis">Perlis</option>
                                    <option value="sabah">Sabah</option>
                                    <option value="sarawak">Sarawak</option>
                                    <option value="selangor">Selangor</option>
                                    <option value="terengganu">Terengganu</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Country</label>
                                <select name="country" required>
                                    <option value="malaysia">Malaysia</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-section">
                        <h3 class="section-title">Delivery Method</h3>
                        <div class="delivery-options">
                            <label class="delivery-option">
                                <input type="radio" name="delivery" value="Standard Delivery" checked required>
                                <span class="radio-custom"></span>
                                <div class="option-content">
                                    <div class="option-title">Standard Delivery</div>
                                    <div class="option-desc">3 - 4 hours</div>
                                    <div class="option-price">RM 5.00</div>
                                </div>
                            </label>
                            <label class="delivery-option">
                                <input type="radio" name="delivery" value="Instant Delivery" required>
                                <span class="radio-custom"></span>
                                <div class="option-content">
                                    <div class="option-title">Instant Delivery</div>
                                    <div class="option-desc">30 - 45 minutes</div>
                                    <div class="option-price">RM 10.00</div>
                                </div>
                            </label>
                        </div>
                    </div>
                    <div class="form-section">
                        <h3 class="section-title">Payment Method</h3>
                        <div class="payment-methods" id="paymentMethods">
                            <label class="payment-method">
                                <input type="radio" name="payment" value="Credit Card" checked required>
                                <div class="method-icon">
                                    <i class="fab fa-cc-visa"></i>
                                </div>
                                <div class="method-name">Credit Card</div>
                            </label>
                            <label class="payment-method">
                                <input type="radio" name="payment" value="Cash on Delivery" required>
                                <div class="method-icon">
                                    <i class="fas fa-money-bill-wave"></i>
                                </div>
                                <div class="method-name">Cash on Delivery</div>
                            </label>
                            <label class="payment-method">
                                <input type="radio" name="payment" value="Touch 'n Go" required>
                                <div class="method-icon">
                                    <i class="fas fa-mobile-alt"></i>
                                </div>
                                <div class="method-name">Touch 'n Go</div>
                            </label>
                            <label class="payment-method">
                                <input type="radio" name="payment" value="DuitNow QR" required>
                                <div class="method-icon">
                                    <i class="fas fa-qrcode"></i>
                                </div>
                                <div class="method-name">DuitNow QR</div>
                            </label>
                        </div>
                    </div>
                    <input type="hidden" id="pointsToRedeemInput" name="points_to_redeem" value="<?php echo htmlspecialchars($points_to_redeem); ?>">
                </form>
            </div>
            <div class="order-summary">
                <h3 class="summary-title">Order Summary</h3>
                <div class="order-items" id="orderItems">
                <?php if (empty($cart_items)): ?>
                    <div style="color:#666;">Your cart is empty.</div>
                <?php else: ?>
                    <?php $subtotal = 0; $totalItems = 0; ?>
                    <?php foreach ($cart_items as $item): ?>
                        <?php $itemTotal = $item['price'] * $item['quantity']; $subtotal += $itemTotal; $totalItems += $item['quantity']; ?>
                        <div class="order-item">
                            <div class="order-item-img">
                                <img src="../Images/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            </div>
                            <div class="order-item-details">
                                <div class="order-item-name"><?php echo htmlspecialchars($item['brand'] . ' ' . $item['name']); ?></div>
                                <div class="order-item-price">RM <?php echo number_format($item['price'], 2); ?></div>
                                <div class="order-item-qty">Quantity: <?php echo $item['quantity']; ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                </div>
                <div class="summary-row" id="summarySubtotal">
                    <span>Subtotal</span><span>RM <?php echo number_format($subtotal, 2); ?></span>
                </div>
                <?php if ($points_to_redeem > 0): ?>
                <div class="summary-row" id="summaryPoints">
                    <span>Redeem Points (<?php echo $points_to_redeem; ?> pts)</span><span style="color:#ff6b00;font-weight:bold;">-RM <?php echo number_format($points_discount, 2); ?></span>
                </div>
                <?php endif; ?>
                <div class="summary-row" id="summaryDelivery">
                    <span>Delivery Fee</span><span>RM <span id="deliveryFeeValue"><?php echo number_format($deliveryFee, 2); ?></span></span>
                </div>
                <div class="summary-row total" id="summaryTotal">
                    <span>Total</span><span>RM <span id="totalValue"><?php echo number_format($finalPrice, 2); ?></span></span>
                </div>
                <button class="checkout-btn" id="completeOrderBtn" type="button">
                    <i class="fas fa-lock"></i>
                    Complete Order
                </button>
                <p class="secure-checkout">
                    <i class="fas fa-shield-alt"></i> Secure Checkout
                </p>
                <div id="orderModal" style="display:none;position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.4);z-index:9999;align-items:center;justify-content:center;">
                    <div style="background:#fff;padding:32px 24px;border-radius:10px;max-width:350px;margin:auto;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,0.15);">
                        <div id="modalContent"></div>
                        <button id="modalProceedBtn" style="margin-top:18px;padding:10px 24px;background:#006400;color:#fff;border:none;border-radius:5px;font-weight:bold;cursor:pointer;display:none;">Proceed</button>
                        <button id="modalOkayBtn" style="margin-top:18px;padding:10px 24px;background:#ccc;color:#333;border:none;border-radius:5px;font-weight:bold;cursor:pointer;">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>
    // Only keep JS for UI (not cart rendering)
    // Membership-based logo redirect, etc.
    const logo = document.querySelector('.logo');
    if (logo) {
        logo.addEventListener('click', function(e) {
            e.preventDefault();
            var isMember = sessionStorage.getItem('isMember') === 'true';
            if (isMember) {
                window.location.href = '../2.Homes/MemberHome\'s.php';
            } else {
                window.location.href = '../2.Homes/NonMemberHome\'s.php';
            }
        });
    }
    const breadcrumbHome = document.getElementById('breadcrumbHome');
    if (breadcrumbHome) {
        breadcrumbHome.addEventListener('click', function(e) {
            e.preventDefault();
            var isMember = sessionStorage.getItem('isMember') === 'true';
            if (isMember) {
                window.location.href = '../2.Homes/MemberHome\'s.php';
            } else {
                window.location.href = '../2.Homes/NonMemberHome\'s.php';
            }
        });
    }
    // Delivery and Payment Method Logic (UI only)
    const deliveryOptions = document.querySelectorAll('input[name="delivery"]');
    const deliveryLabels = document.querySelectorAll('.delivery-option');
    const paymentOptions = document.querySelectorAll('input[name="payment"]');
    const paymentLabels = document.querySelectorAll('.payment-method');
    let selectedDeliveryIndex = 0;
    function updateDeliveryActive() {
        deliveryLabels.forEach((label, idx) => {
            if (deliveryOptions[idx].checked) {
                label.classList.add('active');
                selectedDeliveryIndex = idx;
            } else {
                label.classList.remove('active');
            }
        });
    }
    function updatePaymentActive() {
        paymentLabels.forEach((label, idx) => {
            if (paymentOptions[idx].checked) {
                label.classList.add('active');
            } else {
                label.classList.remove('active');
            }
        });
    }
    Array.from(deliveryOptions).forEach((option, idx) => {
        option.addEventListener('change', function() {
            if (option.checked) {
                selectedDeliveryIndex = idx;
                updateDeliveryActive();
                let fee = idx === 1 ? 10.00 : 5.00;
                document.getElementById('deliveryFeeValue').textContent = fee.toFixed(2);
                let total = Math.max(0, <?php echo json_encode($subtotal); ?> - <?php echo json_encode($points_discount); ?>) + fee;
                document.getElementById('totalValue').textContent = total.toFixed(2);
                // Ensure the hidden input is updated to the correct value
                document.getElementById('pointsToRedeemInput').value = <?php echo json_encode($points_to_redeem); ?>;
            }
        });
    });
    Array.from(paymentOptions).forEach((option, idx) => {
        option.addEventListener('change', function() {
            updatePaymentActive();
        });
    });
    updateDeliveryActive();
    updatePaymentActive();
    // Wishlist and Account link handlers
    const wishlistLink = document.querySelector('.user-tools a[href="#"]:nth-child(1)');
    const accountLink = document.querySelector('.user-tools a[href="#"]:nth-child(2)');
    if (wishlistLink) {
        wishlistLink.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = '../4.Accounts/Wishlist.php';
        });
    }
    if (accountLink) {
        accountLink.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = '../4.Accounts/AccountCustomer.php';
        });
    }
    // Modal confirmation and form validation for Complete Order
    const completeOrderBtn = document.getElementById('completeOrderBtn');
    const orderModal = document.getElementById('orderModal');
    const modalContent = document.getElementById('modalContent');
    const modalProceedBtn = document.getElementById('modalProceedBtn');
    const modalOkayBtn = document.getElementById('modalOkayBtn');
    const shippingForm = document.getElementById('shippingForm');

    function validateForm() {
        // Get form fields
        const email = shippingForm.querySelector('input[name="email"]');
        const phone = shippingForm.querySelector('input[name="phone"]');
        const fullName = shippingForm.querySelector('input[name="fullName"]');
        const address = shippingForm.querySelector('input[name="address"]');
        const city = shippingForm.querySelector('input[name="city"]');
        const postcode = shippingForm.querySelector('input[name="postcode"]');
        const state = shippingForm.querySelector('select[name="state"]');
        const country = shippingForm.querySelector('select[name="country"]');
        const delivery = shippingForm.querySelector('input[name="delivery"]:checked');
        const payment = shippingForm.querySelector('input[name="payment"]:checked');
        if (!email.value || !phone.value || !fullName.value || !address.value || !city.value || !postcode.value || !state.value || !country.value || !delivery || !payment) {
            return false;
        }
        return true;
    }

    completeOrderBtn.addEventListener('click', function() {
        if (validateForm()) {
            modalContent.innerHTML = '<div style="color:#006400;font-weight:bold;font-size:1.1em;">Are you sure you want to place this order?</div>';
            modalProceedBtn.style.display = 'inline-block';
        } else {
            modalContent.innerHTML = '<div style="color:#c00;font-weight:bold;font-size:1.1em;">Please fill in all required fields and select delivery/payment method.</div>';
            modalProceedBtn.style.display = 'none';
        }
        orderModal.style.display = 'flex';
    });
    modalProceedBtn.addEventListener('click', function() {
        shippingForm.submit();
    });
    modalOkayBtn.addEventListener('click', function() {
        orderModal.style.display = 'none';
    });
    // Allow modal close on outside click
    orderModal.addEventListener('click', function(e) {
        if (e.target === orderModal) orderModal.style.display = 'none';
    });
    document.addEventListener('DOMContentLoaded', function() {
        var logoLink = document.getElementById('bakawaliLogoLink');
        if (logoLink) {
            logoLink.addEventListener('click', function(e) {
                e.preventDefault();
                var isMember = sessionStorage.getItem('isMember') === 'true';
                if (isMember) {
                    window.location.href = '../2.Homes/MemberHome\'s.php';
                } else {
                    window.location.href = '../2.Homes/NonMemberHome\'s.php';
                }
            });
        }
    });
    </script>
</body>
</html> 