<?php
session_start();

// Database connection for CustomerTrackOrder.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$customerID = $_SESSION['customerID'];
$stmt = $pdo->prepare("SELECT * FROM checkout WHERE customerID=? ORDER BY date DESC");
$stmt->execute([$customerID]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch purchased products for each order
$order_products = [];
foreach ($orders as $order) {
    $checkoutID = $order['checkoutID'];
    $stmt2 = $pdo->prepare("SELECT * FROM checkout_product WHERE checkoutID=?");
    $stmt2->execute([$checkoutID]);
    $order_products[$checkoutID] = $stmt2->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch shipping status for each order
$order_statuses = [];
foreach ($orders as $order) {
    $stmt3 = $pdo->prepare("SELECT shippingStatus FROM tracking WHERE checkoutID=?");
    $stmt3->execute([$order['checkoutID']]);
    $order_statuses[$order['checkoutID']] = $stmt3->fetchColumn();
}

// Add shippingStatus to each order
foreach ($orders as &$order) {
  $order['shippingStatus'] = $order_statuses[$order['checkoutID']] ?? 'Pending';
}
unset($order); // break reference
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Track My Orders | ShopLahBakawali</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #ffffff;
      color: #333;
      min-width: 100vw;
      min-height: 100vh;
      overflow-x: hidden;
    }
    .container {
      width: 100%;
      max-width: 100%;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    header {
      background-color: #064e3b;
      color: white;
      padding: 10px 0 0 0;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      width: 100vw;
      margin: 0;
      position: relative;
      left: 50%;
      right: 50%;
      margin-left: -50vw;
      margin-right: -50vw;
    }
    .top-bar {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding: 0 20px 10px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      width: 100%;
      box-sizing: border-box;
    }
    .user-tools {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    .user-tools a {
      color: white;
      text-decoration: none;
      margin-left: 15px;
      font-size: 14px;
      display: flex;
      align-items: center;
    }
    .user-tools i {
      margin-right: 5px;
    }
    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      padding: 15px 40px;
    }
    .nav-left {
      display: flex;
      align-items: center;
    }
    .logo {
      height: 40px;
      margin-right: 40px;
    }
    .logo img {
      height: 100%;
    }
    .dashboard-header {
      max-width: 900px;
      margin: 30px auto 0 auto;
      padding: 0 20px 20px 20px;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
    }
    .dashboard-header h1 {
      color: #064e3b;
      font-size: 2rem;
      margin-bottom: 8px;
      font-weight: 700;
    }

    /* Breadcrumb styles */
    .breadcrumb {
      font-size: 0.8rem;
      color: #666;
      margin: 2rem 0 1rem 5rem;
    }

    .breadcrumb a {
      color: #064e3b;
      text-decoration: none;
      font-weight: 500;
    }

    .breadcrumb a:hover {
      text-decoration: underline;
    }
    .orders-section {
      max-width: 900px;
      margin: 0 auto 0 auto;
      padding: 0 20px 40px 20px;
      display: flex;
      flex-direction: column;
      gap: 30px;
    }
    .order-card {
      background: #fff;
      border-radius: 8px;
      border: 1px solid #eee;
      box-shadow: none;
      padding: 24px 20px 18px 20px;
      position: relative;
      display: flex;
      flex-direction: column;
      gap: 8px;
      transition: border-color 0.2s;
    }
    .order-card:hover {
      border-color: #ccc;
      box-shadow: none;
    }
    .order-status-ribbon {
      position: absolute;
      top: 18px;
      right: 20px;
      padding: 3px 12px;
      border-radius: 12px;
      font-size: 0.95rem;
      font-weight: 500;
      background: #f6f6f6;
      color: #666;
      border: none;
      box-shadow: none;
      z-index: 2;
      letter-spacing: 0;
    }
    .status-delivered {
      color: #2E7D32;
      background: #f6f6f6;
      border: none;
    }
    .status-cancelled {
      color: #c00;
      background: #f6f6f6;
      border: none;
    }
    .status-inprogress {
      color: #ff9800;
      background: #f6f6f6;
      border: none;
    }
    .order-main {
      display: flex;
      align-items: flex-start;
      gap: 18px;
      flex-wrap: wrap;
    }
    .order-icon {
      font-size: 1.7rem;
      color: #bbb;
      background: none;
      border-radius: 0;
      padding: 0;
      margin-right: 0;
      border: none;
      min-width: 28px;
      text-align: center;
    }
    .order-info {
      flex: 1;
      min-width: 160px;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .order-info .order-id {
      font-size: 1rem;
      font-weight: 500;
      color: #222;
      margin-bottom: 2px;
    }
    .order-info .order-date {
      color: #aaa;
      font-size: 0.93rem;
      margin-bottom: 2px;
    }
    .order-info .order-total {
      font-size: 1rem;
      color: #222;
      font-weight: 500;
    }
    .order-progress {
      width: 100%;
      margin: 8px 0 0 0;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .progress-bar {
      flex: 1;
      height: 5px;
      background: #f2f2f2;
      border-radius: 3px;
      overflow: hidden;
      position: relative;
    }
    .progress-bar-inner {
      height: 100%;
      background: #bbb;
      border-radius: 3px;
      transition: width 0.5s;
    }
    .progress-label {
      font-size: 0.85rem;
      color: #aaa;
      margin-left: 6px;
    }
    .order-actions {
      margin-top: 8px;
      display: flex;
      gap: 10px;
    }
    .order-actions button, .order-actions a {
      background: #fff;
      color: #222;
      padding: 5px 14px;
      text-decoration: none;
      border-radius: 3px;
      font-size: 0.98rem;
      border: 1px solid #eee;
      cursor: pointer;
      transition: border-color 0.2s, color 0.2s;
      display: flex;
      align-items: center;
      gap: 4px;
      font-weight: 400;
    }
    .order-actions button:hover, .order-actions a:hover {
      border-color: #bbb;
      color: #064e3b;
      background: #fafafa;
    }
    .order-details-link {
      background: #fff;
      color: #222;
      border: 1px solid #eee;
      font-weight: 400;
      transition: border-color 0.2s, color 0.2s;
    }
    .order-details-link:hover {
      background: #fafafa;
      color: #064e3b;
      border-color: #bbb;
    }
    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0; top: 0; width: 100vw; height: 100vh;
      background: rgba(0,0,0,0.25);
      align-items: center;
      justify-content: center;
    }
    .modal.active {
      display: flex;
    }
    .modal-content {
      background: #fff;
      border-radius: 16px;
      max-width: 480px;
      width: 95vw;
      padding: 32px 24px 24px 24px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.18);
      position: relative;
      animation: fadeIn 0.3s;
    }
    .modal-close {
      position: absolute;
      top: 18px;
      right: 18px;
      font-size: 1.3rem;
      color: #888;
      background: none;
      border: none;
      cursor: pointer;
      transition: color 0.2s;
    }
    .modal-close:hover {
      color: #c00;
    }
    .modal-content h2 {
      color: #064e3b;
      font-size: 1.2rem;
      margin-bottom: 10px;
    }
    .order-details-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 10px;
    }
    .order-details-table th, .order-details-table td {
      padding: 7px 6px;
      border-bottom: 1px solid #eee;
      font-size: 0.98rem;
      text-align: left;
    }
    .order-details-table th {
      background: #f8f8f8;
      color: #333;
      font-weight: 500;
    }
    .order-details-table img {
      width: 38px;
      height: 38px;
      object-fit: cover;
      border-radius: 6px;
      margin-right: 8px;
      border: 1px solid #eee;
    }
    .order-details-meta {
      color: #666;
      font-size: 0.97rem;
      margin-bottom: 10px;
    }
    @media (max-width: 700px) {
      .dashboard-header, .orders-section {
        padding: 0 4px 20px 4px;
      }
      .order-card {
        padding: 18px 8px 16px 8px;
      }
      .order-status-ribbon {
        right: 10px;
        top: 10px;
        font-size: 0.95rem;
        padding: 4px 10px;
      }
      .order-main {
        flex-direction: column;
        gap: 10px;
      }
      .order-icon {
        font-size: 2rem;
        padding: 10px;
      }
    }
    .aboutus-btn {
      margin-left: 20px;
      font-weight: bold;
      color: #ffffff;
      padding: 8px 20px;
      border-radius: 20px;
      text-decoration: none;
      transition: background 0.2s;
      display: inline-block;
    }
    .aboutus-btn:hover {
      background: #e6b800;
      color: #333;
    }
    .nav-history {
      display: inline-block;
      margin-left: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }
  </style>
</head>
<body>
  <header>
    <div class="container">
      <div class="top-bar">
        <div class="user-tools">
          <a href="#"><i class="far fa-heart"></i> Wishlist</a>
          <a href="#"><i class="far fa-user"></i> Account</a>
        </div>
      </div>
      <nav>
        <div class="nav-left">
          <a href="#" class="logo" id="bakawaliLogoLink">
            <img src="bakawaliLogo.png" alt="bakawali Logo" />
          </a>
          <div class="nav-history">
            <button type="button" class="back-forward-btn" onclick="window.history.back();">
              <i class="fas fa-arrow-left"></i> Back
            </button>
            <button type="button" class="back-forward-btn" onclick="window.history.forward();">
              Forward <i class="fas fa-arrow-right"></i>
            </button>
          </div>
          <a href="../2.Homes/AboutUs.php" class="aboutus-btn">About Us</a>
        </div>
      </nav>
    </div>
  </header>
  <main class="container">
    <div class="breadcrumb">
      <?php
        $homeHref = '../2.Homes/NonMemberHome\'s.php';
        if (isset($_SESSION['is_member']) && $_SESSION['is_member']) {
          $homeHref = "../2.Homes/MemberHome's.php";
        }
      ?>
      <a href="<?php echo $homeHref; ?>" id="breadcrumbHome">Home</a> / <span>Track Orders</span>
    </div>
    <div class="dashboard-header">
        <h1><i class="fas fa-box"></i> My Orders</h1>
    </div>
    <section class="orders-section" id="ordersSection">
      <!-- Order cards will be injected here -->
    </section>
    <!-- Modal for order details -->
    <div class="modal" id="orderModal">
      <div class="modal-content" id="modalContent">
        <button class="modal-close" id="modalCloseBtn"><i class="fas fa-times"></i></button>
        <!-- Details will be injected here -->
      </div>
    </div>
  </main>
  <script>
  // Pass PHP orders and products to JS
  var ordersFromPHP = <?php echo json_encode($orders); ?>;
  var orderProductsFromPHP = <?php echo json_encode($order_products); ?>;


  function renderOrders() {
    const orders = ordersFromPHP;
    const section = document.getElementById('ordersSection');
    section.innerHTML = '';
    orders.forEach(order => {
      const card = document.createElement('div');
      card.className = 'order-card';
      // Status ribbon
      let status = order.shippingStatus;
      if (!status) status = 'Pending';
      let statusClass = '';
      if (status === 'Delivered') statusClass = 'status-delivered';
      else if (status === 'Cancelled') statusClass = 'status-cancelled';
      else if (status === 'Pending') statusClass = 'status-inprogress';
      else if (status === 'Processing') statusClass = 'status-processing';
      else if (status === 'Shipped') statusClass = 'status-shipped';
      else statusClass = 'status-inprogress';
      const ribbon = document.createElement('div');
      ribbon.className = 'order-status-ribbon ' + statusClass;
      ribbon.innerHTML = `<i class="fas fa-circle"></i> ${status}`;
      card.appendChild(ribbon);
      // Main info
      const main = document.createElement('div');
      main.className = 'order-main';
      const icon = document.createElement('div');
      icon.className = 'order-icon';
      icon.innerHTML = '<i class="fas fa-box"></i>';
      main.appendChild(icon);
      const info = document.createElement('div');
      info.className = 'order-info';
      info.innerHTML = `
        <div class="order-id">Order #${order.checkoutID}</div>
        <div class="order-date"><i class="far fa-calendar-alt"></i> ${order.date}</div>
        <div class="order-total">Total: RM ${parseFloat(order.finalPrice).toFixed(2)}</div>
      `;
      main.appendChild(info);
      card.appendChild(main);
      // Actions
      const actions = document.createElement('div');
      actions.className = 'order-actions';
      const detailsBtn = document.createElement('button');
      detailsBtn.className = 'order-details-link';
      detailsBtn.innerHTML = '<i class="fas fa-info-circle"></i> Details';
      detailsBtn.onclick = () => showOrderModal(order);
      actions.appendChild(detailsBtn);
      card.appendChild(actions);
      section.appendChild(card);
    });
  }

  function showOrderModal(order) {
    const modal = document.getElementById('orderModal');
    const modalContent = document.getElementById('modalContent');
    modalContent.querySelectorAll('.modal-details').forEach(e => e.remove());
    const detailsDiv = document.createElement('div');
    detailsDiv.className = 'modal-details';
    // Get purchased products for this order
    const products = orderProductsFromPHP[order.checkoutID] || [];
    let itemsRows = '';
    products.forEach(item => {
      itemsRows += `<tr><td><img src="../Images/${item.image || 'bakawaliLogo.png'}" alt="${item.name}"> ${item.name}</td><td>${item.quantity}</td><td>RM ${parseFloat(item.price).toFixed(2)}</td><td>RM ${(parseFloat(item.price)*parseInt(item.quantity)).toFixed(2)}</td></tr>`;
    });
    detailsDiv.innerHTML = `
      <h2>Order #${order.checkoutID} Details</h2>
      <div class="order-details-meta">
        <strong>Recipient:</strong> ${order.fullName || '-'}<br>
        <strong>Address:</strong> ${order.address || '-'}, ${order.city || ''}, ${order.postcode || ''}, ${order.state || ''}, ${order.country || ''}<br>
        <strong>Contact:</strong> ${order.email || '-'} | ${order.phoneNumber || '-'}<br>
        <strong>Delivery:</strong> ${order.deliveryMethod || '-'}<br>
        <strong>Payment:</strong> ${order.paymentMethod || '-'}
      </div>
      <table class="order-details-table">
        <tr><th>Item</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr>
        ${itemsRows}
        <tr><td colspan="3" style="text-align:right;">Subtotal</td><td>RM ${parseFloat(order.subtotal).toFixed(2)}</td></tr>
        <tr><td colspan="3" style="text-align:right;">Delivery Fee</td><td>RM ${parseFloat(order.deliveryFee).toFixed(2)}</td></tr>
        <tr><td colspan="3" style="text-align:right;font-weight:bold;">Total Paid</td><td style="font-weight:bold; color:#2E7D32;">RM ${parseFloat(order.finalPrice).toFixed(2)}</td></tr>
      </table>
    `;
    modalContent.appendChild(detailsDiv);
    modal.classList.add('active');
  }

  const modal = document.getElementById('orderModal');
  const modalContent = document.getElementById('modalContent');
  const modalCloseBtn = document.getElementById('modalCloseBtn');
  modalCloseBtn.onclick = function() {
    modal.classList.remove('active');
    modalContent.querySelectorAll('.modal-details').forEach(e => e.remove());
  };
  window.onclick = function(event) {
    if (event.target === modal) {
      modal.classList.remove('active');
      modalContent.querySelectorAll('.modal-details').forEach(e => e.remove());
    }
  };

  renderOrders();
  </script>
 <script>
document.addEventListener('DOMContentLoaded', function() {
  // Logo click: go to home (member or non-member)
  var logoLink = document.getElementById('bakawaliLogoLink');
  if (logoLink) {
    logoLink.addEventListener('click', function(e) {
      e.preventDefault();
      var isMember = sessionStorage.getItem('isMember') === 'true';
      if (isMember) {
        window.location.href = '../2.Homes/MemberHome\'s.php';
      } else {
        window.location.href = '../2.Homes/NonMemberHome\'s.php';
      }
    });
  }
  // Wishlist link
  const wishlistLink = document.querySelector('.user-tools a[href="#"]:nth-child(1)');
  if (wishlistLink) {
    wishlistLink.addEventListener('click', function(e) {
      e.preventDefault();
      window.location.href = '../4.Accounts/Wishlist.php';
    });
  }
  // Account link
  const accountLink = document.querySelector('.user-tools a[href="#"]:nth-child(2)');
  if (accountLink) {
    accountLink.addEventListener('click', function(e) {
      e.preventDefault();
      window.location.href = '../4.Accounts/AccountCustomer.php';
    });
  }
});
</script>
</body>
</html>