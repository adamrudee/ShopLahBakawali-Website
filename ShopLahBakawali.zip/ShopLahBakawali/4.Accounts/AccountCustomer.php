<?php
// Database connection for AccountCustomer.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
// Now you can use $pdo to query the 'customer' table

session_start();

// Debug: Show POST data if any
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $new_fullname = $_POST['fullname'];
}

$customer_id = $_SESSION['customerID']; // should be customerID

// Fetch current user info and points
$stmt = $pdo->prepare("SELECT c.fullname, c.email, c.phoneNumber, c.password, c.membershipID, m.points FROM customer c LEFT JOIN membership m ON c.membershipID = m.membershipID WHERE c.customerID=?");
$stmt->execute([$customer_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$fullname = $user['fullname'] ?? '';
$email = $user['email'] ?? '';
$phoneNumber = $user['phoneNumber'] ?? '';
$hashed_password = $user['password'] ?? '';
$membership_id = $user['membershipID'] ?? '';
$points_balance = $user['points'] ?? 0;

$success = $error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $new_fullname = $_POST['fullname'];
    $new_email = $_POST['email'];
    $new_phone = $_POST['phone'];
    $new_password = $_POST['password'];
    try {
        if (!empty($new_password)) {
            $hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE customer SET fullname=?, email=?, phoneNumber=?, password=? WHERE customerID=?");
            $stmt->execute([$new_fullname, $new_email, $new_phone, $hashed, $customer_id]);
            $hashed_password = $hashed;
        } else {
            $stmt = $pdo->prepare("UPDATE customer SET fullname=?, email=?, phoneNumber=? WHERE customerID=?");
            $stmt->execute([$new_fullname, $new_email, $new_phone, $customer_id]);
        }
        $success = "Account updated successfully!";
        $fullname = $new_fullname;
        $email = $new_email;
        $phoneNumber = $new_phone;
    } catch (PDOException $e) {
        $error = "Error updating account: " . $e->getMessage();
    }
}

// Handle signout
if (isset($_POST['signout'])) {
    session_destroy();
    echo '<script>setTimeout(function(){ window.location.href = "../1.Login/LoginForm.php"; }, 1200);</script>';
    echo '<div id="signout-loading" style="display:flex;align-items:center;justify-content:center;height:100vh;"><div style="text-align:center;"><div class="spinner" style="margin:auto;margin-bottom:10px;"></div><div>Signing out...</div></div></div>';
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Account Settings | ShopLahBakawali</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #ffffff;
      color: #333;
      min-width: 100vw;
      min-height: 100vh;
      overflow-x: hidden;
    }

    header {
      background-color: #064e3b;
      color: white;
      padding: 10px 0;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      width: 100vw;
      margin: 0;
      position: relative;
      left: 50%;
      right: 50%;
      margin-left: -50vw;
      margin-right: -50vw;
    }

    .container {
      width: 100%;
      max-width: 100%;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    .top-bar {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding: 0 20px 10px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }

    .user-tools {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .user-tools a {
      color: white;
      text-decoration: none;
      font-size: 14px;
      display: flex;
      align-items: center;
    }

    .user-tools i {
      margin-right: 5px;
    }

    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      padding: 15px 40px;
    }

    .logo {
      height: 40px;
      margin-right: 40px;
    }

    .logo img {
      height: 100%;
    }

    .cart {
      margin-right: 20px;
      margin-left: auto;
    }

    .cart-icon {
      position: relative;
      color: white;
    }

    .cart-count {
      position: absolute;
      top: -8px;
      right: -8px;
      background-color: #ffcc00;
      color: #333;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      font-weight: bold;
    }

    .account-section {
      max-width: 800px;
      margin: 30px auto;
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.05);
      box-sizing: border-box;
    }

    h2 {
      font-size: 2rem;
      font-weight: 700;
      color: #064e3b;
      border-bottom: 3px solid #ffcc00;
      display: inline-block;
      padding-bottom: 5px;
      margin-bottom: 1.5rem;
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      display: block;
      font-weight: 600;
      margin-bottom: 8px;
    }

    input, select {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 1rem;
    }

    .btn {
      background-color: #054836;
      color: white;
      padding: 12px 24px;
      font-size: 1rem;
      font-weight: 600;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      margin-top: 10px;
    }

    .btn:hover {
      background-color: #053a2c;
    }

    .button-group {
      text-align: center;
      margin-top: 20px;
    }

    .btn-secondary {
      background-color: #dc1b1b;
      margin-left: 10px;
    }

    .btn-secondary:hover {
      background-color: #690707;
    }

    /* Modal Styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.5);
    }
    .modal-content {
      background-color: #fefefe;
      margin: 15% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 80%;
      max-width: 400px;
      border-radius: 8px;
      text-align: center;
    }
    .modal-buttons {
      margin-top: 20px;
    }

    .points-section {
      background: linear-gradient(135deg, #28a745, #20c997);
      color: white;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 30px;
      text-align: center;
    }

    .points-balance {
      font-size: 2.5rem;
      font-weight: bold;
      margin: 10px 0;
    }

    .points-label {
      font-size: 1.1rem;
      opacity: 0.9;
    }

    .track-orders-section {
      background: linear-gradient(135deg, #f8f9fa, #e9ecef);
      border: 1px solid #dee2e6;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 30px;
      text-align: center;
    }

    .track-orders-section h3 {
      color: #064e3b;
      font-size: 1.3rem;
      margin-bottom: 8px;
      font-weight: 600;
    }

    .track-orders-section p {
      color: #666;
      margin-bottom: 15px;
      font-size: 0.95rem;
    }

    .btn-track-orders {
      background: linear-gradient(135deg, #064e3b, #054836);
      color: white;
      padding: 12px 24px;
      font-size: 1rem;
      font-weight: 600;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.3s ease;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }

    .btn-track-orders:hover {
      background: linear-gradient(135deg, #054836, #043a2c);
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(6, 78, 59, 0.3);
    }

    .password-wrapper {
      position: relative;
      width: 100%;
    }
    .toggle-password {
      position: absolute;
      top: 50%;
      right: 16px;
      transform: translateY(-50%);
      cursor: pointer;
      color: #888;
      font-size: 18px;
      z-index: 2;
    }

    @media (max-width: 768px) {
      nav {
        flex-direction: column;
        padding: 15px 20px;
      }
      .account-section {
        margin: 20px;
        padding: 20px;
      }
    }

    /* Ensure modals stack above everything */
    .modal { z-index: 2000; }

    .nav-left {
      display: flex;
      align-items: center;
    }
    .aboutus-btn {
      margin-left: 20px;
      font-weight: bold;
      color: #ffffff;
      padding: 8px 20px;
      border-radius: 20px;
      text-decoration: none;
      transition: background 0.2s;
      display: inline-block;
    }
    .aboutus-btn:hover {
      background: #e6b800;
      color: #333;
    }
    .nav-history {
      display: inline-block;
      margin-left: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }
  </style>
</head>
<body>
  <!-- Header -->
  <header>
    <div class="container">
      <div class="top-bar">
        <div class="user-tools">
          <a href="../4.Accounts/Wishlist.php"><i class="far fa-heart"></i> Wishlist</a>
          <a href="../4.Accounts/AccountCustomer.php"><i class="fas fa-user"></i> Account</a>
        </div>
      </div>
      <nav>
        <div class="nav-left">
          <a href="#" class="logo" id="bakawaliLogoLink">
            <img src="bakawaliLogo.png" alt="bakawali Logo" />
          </a>
          <div class="nav-history">
            <button type="button" class="back-forward-btn" onclick="window.history.back();">
              <i class="fas fa-arrow-left"></i> Back
            </button>
            <button type="button" class="back-forward-btn" onclick="window.history.forward();">
              Forward <i class="fas fa-arrow-right"></i>
            </button>
          </div>
          <a href="../2.Homes/AboutUs.php" class="aboutus-btn">About Us</a>
        </div>
        <div class="cart">
          <a href="../5.Checkout/CartInterface.php" class="cart-icon">
            <i class="fas fa-shopping-cart"></i>
            <span class="cart-count">0</span>
          </a>
        </div>
      </nav>
    </div>
  </header>
  <section class="account-section">
    <h2>Account Settings</h2>
    <?php if ($success): ?>
      <div style="color: green; margin-bottom: 10px; text-align:center;"> <?php echo $success; ?> </div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div style="color: red; margin-bottom: 10px; text-align:center;"> <?php echo $error; ?> </div>
    <?php endif; ?>
    <div class="points-section" id="pointsSection" style="display: <?php echo $membership_id ? 'block' : 'none'; ?>;">
      <div class="points-label">Points Balance</div>
      <div class="points-balance" id="pointsBalance"><?php echo $points_balance; ?></div>
    </div>
    
    <!-- Track Orders Section -->
    <div class="track-orders-section">
      <h3><i class="fas fa-box"></i> Order Management</h3>
      <p>Track your order status and view order history</p>
      <button type="button" class="btn btn-track-orders" id="trackOrdersBtn">
        <i class="fas fa-truck"></i> Track My Orders
      </button>
    </div>
    
    <form method="POST">
      <div class="form-group">
        <label for="fullname">New Full Name</label>
        <input type="text" id="fullname" name="fullname" value="<?php echo htmlspecialchars($fullname); ?>" required />
      </div>
      <div class="form-group">
        <label for="phone">New Phone Number</label>
        <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($phoneNumber); ?>" required />
      </div>
      <div class="form-group">
        <label for="email">New Email</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required />
      </div>
      <div class="form-group">
        <label for="password">New Password</label>
        <div class="password-wrapper">
          <input type="password" id="password" name="password" value="" />
          <span class="toggle-password" id="togglePassword">
            <i class="fa-regular fa-eye-slash" id="eyeIcon"></i>
          </span>
        </div>
      </div>
      <div class="button-group">
        <button type="submit" class="btn" name="update" value="1">Save Changes</button>
        <button type="button" class="btn btn-secondary" id="logoutBtn">Logout</button>
      </div>
    </form>
  </section>

  <!-- Logout Confirmation Modal -->
  <div id="logoutModal" class="modal">
    <div class="modal-content">
      <p>Are you sure you want to logout?</p>
      <div class="modal-buttons">
        <button class="btn" id="confirmLogout">Yes, Logout</button>
        <button class="btn btn-secondary" id="cancelLogout">Cancel</button>
      </div>
    </div>
  </div>

  <!-- Save Changes Confirmation Modal -->
  <div id="saveModal" class="modal">
    <div class="modal-content">
      <p>Are you sure you want to save these changes?</p>
      <div class="modal-buttons">
        <button class="btn" id="confirmSave">Yes, Save</button>
        <button class="btn btn-secondary" id="cancelSave">Cancel</button>
      </div>
    </div>
  </div>

  <script>
    function updateCartCount() {
        // For members, fetch cart count from server
        fetch('../3.Searches/SearchInterface.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=get_counts'
        })
        .then(r => r.json())
        .then(data => {
            var cartCountElement = document.querySelector('.cart-count');
            if (cartCountElement && typeof data.cart_count !== 'undefined') {
                cartCountElement.textContent = data.cart_count;
            }
        });
    }
    document.addEventListener('DOMContentLoaded', function() {
      // Check membership status
      const isMember = sessionStorage.getItem('isMember') === 'true';
      const membershipId = sessionStorage.getItem('membershipId');
      
      if (isMember) {
        // Show points section for members
        document.getElementById('pointsSection').style.display = 'block';
      }
      // Add logo click handler for membership-based redirect
      var logoLink = document.getElementById('bakawaliLogoLink');
      if (logoLink) {
        logoLink.addEventListener('click', function(e) {
          e.preventDefault();
          var isMember = sessionStorage.getItem('isMember') === 'true';
          if (isMember) {
            window.location.href = '../2.Homes/MemberHome\'s.php';
          } else {
            window.location.href = '../2.Homes/NonMemberHome\'s.php';
          }
        });
      }
      updateCartCount();

      // Track Orders button functionality
      const trackOrdersBtn = document.getElementById('trackOrdersBtn');
      if (trackOrdersBtn) {
        trackOrdersBtn.addEventListener('click', function() {
          window.location.href = '../5.Checkout/CustomerTrackOrder.php';
        });
      }

      const logoutBtn = document.getElementById('logoutBtn');
      const logoutModal = document.getElementById('logoutModal');
      const confirmLogoutBtn = document.getElementById('confirmLogout');
      const cancelLogoutBtn = document.getElementById('cancelLogout');

      logoutBtn.addEventListener('click', function() {
        logoutModal.style.display = 'block';
      });

      cancelLogoutBtn.addEventListener('click', function() {
        logoutModal.style.display = 'none';
      });

      confirmLogoutBtn.addEventListener('click', function() {
        // Show loading spinner and message
        document.body.innerHTML = '<div id="signout-loading" style="display:flex;align-items:center;justify-content:center;height:100vh;"><div style="text-align:center;"><div class="spinner" style="margin:auto;margin-bottom:10px;width:40px;height:40px;border:4px solid #ccc;border-top:4px solid #054836;border-radius:50%;animation:spin 1s linear infinite;"></div><div>Signing out...</div></div></div>';
        sessionStorage.clear();
        setTimeout(function() {
          window.location.href = '../1.Login/LoginForm.php';
        }, 1200);
      });

      // Close modal if user clicks outside of it
      window.addEventListener('click', function(event) {
        if (event.target == logoutModal) {
          logoutModal.style.display = 'none';
        }
      });

      // Toggle password visibility for account settings
      const passwordInput = document.getElementById('password');
      const togglePassword = document.getElementById('togglePassword');
      const eyeIcon = document.getElementById('eyeIcon');
      if (togglePassword && passwordInput && eyeIcon) {
        togglePassword.addEventListener('click', () => {
          const isPassword = passwordInput.type === 'password';
          passwordInput.type = isPassword ? 'text' : 'password';
          eyeIcon.classList.toggle('fa-eye');
          eyeIcon.classList.toggle('fa-eye-slash');
        });
      }

      // Save Changes confirmation modal logic
      const saveModal = document.getElementById('saveModal');
      const confirmSaveBtn = document.getElementById('confirmSave');
      const cancelSaveBtn = document.getElementById('cancelSave');
      const form = document.querySelector('form');
      let pendingSubmit = false;

      form.addEventListener('submit', function(e) {
        if (!pendingSubmit) {
          e.preventDefault();
          saveModal.style.display = 'block';
        } else {
          pendingSubmit = false; // reset for next submit
        }
      });

      confirmSaveBtn.addEventListener('click', function() {
        saveModal.style.display = 'none';
        pendingSubmit = true;
        // Find the submit button and pass it to requestSubmit
        const submitBtn = form.querySelector('button[type="submit"][name="update"]');
        if (submitBtn) {
          form.requestSubmit(submitBtn);
        } else {
          form.requestSubmit();
        }
      });

      cancelSaveBtn.addEventListener('click', function() {
        saveModal.style.display = 'none';
      });

      // Close modal if user clicks outside of it
      window.addEventListener('click', function(event) {
        if (event.target == saveModal) {
          saveModal.style.display = 'none';
        }
      });

      // Add spinner animation CSS if not present
      var style = document.createElement('style');
      style.innerHTML = '@keyframes spin {0% {transform: rotate(0deg);}100% {transform: rotate(360deg);}}';
      document.head.appendChild(style);
    });
  </script>
</body>
</html> 