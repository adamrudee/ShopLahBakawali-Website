<?php
session_start();
// PDO connection for Wishlist.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
// Session check
if (!isset($_SESSION['customerID'])) {
    header('Location: ../1.Login/LoginForm.php');
    exit();
}

// Get the logged-in user's customerID
$user_id = $_SESSION['customerID'];

// Fetch membershipID for the user to determine home link
$stmt = $pdo->prepare('SELECT membershipID FROM customer WHERE customerID = ?');
$stmt->execute([$user_id]);
$membershipID = $stmt->fetchColumn();
$homeLink = ($membershipID) ? "../2.Homes/MemberHome's.php" : "../2.Homes/NonMemberHome's.php";

// 1. Get the user's wishlistID
$wishlistID = null;
$stmt = $pdo->prepare('SELECT wishlistID FROM customer WHERE customerID = ?');
$stmt->execute([$user_id]);
$wishlistID = $stmt->fetchColumn();

if (!$wishlistID) {
    echo "<p>No wishlist found for this user.</p>";
    exit();
}

// 2. Handle remove from wishlist
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['remove_product_id'])) {
    $remove_pid = intval($_POST['remove_product_id']);
    $stmt = $pdo->prepare('DELETE FROM wishlist_product WHERE wishlistID = ? AND productID = ?');
    $stmt->execute([$wishlistID, $remove_pid]);
    exit();
}

// Handle add back to wishlist
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product_id'])) {
    $add_pid = intval($_POST['add_product_id']);
    $stmt = $pdo->prepare('INSERT IGNORE INTO wishlist_product (wishlistID, productID) VALUES (?, ?)');
    $stmt->execute([$wishlistID, $add_pid]);
    exit();
}

// 3. Get all products in the user's wishlist
$sql = 'SELECT p.productID, p.name, p.brand, p.price, p.image FROM wishlist_product wp JOIN product p ON wp.productID = p.productID WHERE wp.wishlistID = ?';
$stmt = $pdo->prepare($sql);
$stmt->execute([$wishlistID]);
$wishlistProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Wishlist | ShopLahBakawali</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
  <style>
    /* Base styles */
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #ffffff;
      color: #333;
      min-width: 100vw;
      min-height: 100vh;
      overflow-x: hidden;
    }

    .container {
      width: 100%;
      max-width: 100%;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Header styles */
    header {
      background-color: #064e3b;
      color: white;
      padding: 10px 0;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      width: 100vw;
      margin: 0;
      position: relative;
      left: 50%;
      right: 50%;
      margin-left: -50vw;
      margin-right: -50vw;
    }

    /* Top bar styles */
    .top-bar {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding: 0 20px 10px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }

    .user-tools {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .user-tools a {
      color: white;
      text-decoration: none;
      font-size: 14px;
      display: flex;
      align-items: center;
    }

    .user-tools i {
      margin-right: 5px;
    }

    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      padding: 15px 40px;
    }
    .nav-left {
      display: flex;
      align-items: center;
    }
    .logo {
      height: 40px;
      margin-right: 40px;
    }

    .logo img {
      height: 100%;
    }

    .cart {
      margin-right: 20px;
      margin-left: auto;
    }

    .cart-icon {
      position: relative;
      color: white;
    }

    .cart-count {
      position: absolute;
      top: -8px;
      right: -8px;
      background-color: #ffcc00;
      color: #333;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      font-weight: bold;
    }
	
    /* Product section styles */
    .product-section {
      padding: 1rem 2rem;
      margin-top: 1rem;
      width: 100%;
      max-width: 1200px;
      margin-left: auto;
      margin-right: auto;
      box-sizing: border-box;
    }

    .product-section h1 {
      font-size: 2.5rem;
      font-weight: 700;
      color: #064e3b;
      text-transform: uppercase;
      letter-spacing: 1px;
      border-bottom: 3px solid #ffcc00;
      display: inline-block;
      padding-bottom: 5px;
      margin-bottom: 1.5rem;
      margin-top: 0;
      text-align: left;
    }
    .products-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      margin: 0 auto;
      padding: 0 20px;
    }
    .product-card {
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 3px 10px rgba(0,0,0,0.15);
      transition: transform 0.3s;
      height: 380px; /* Set a fixed height for all cards */
      display: flex;
      flex-direction: column;
      max-width: 260px;
      width: 100%;
      margin: 0 auto;
    }
    .product-card:hover {
      transform: translateY(-5px);
    }
    .product-image {
      height: 180px;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 15px;
      background: #f8f9fa;
      position: relative;
    }
    .product-image img {
      max-width: 100%;
      max-height: 100%;
      object-fit: contain;
    }
    .product-bottom {
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      flex: 1;
      background: #fff;
      padding: 20px;
      border-top: 1px solid #f0f0f0;
    }
    .product-title {
      display: block;
      font-weight: 600;
      margin-bottom: 12px;
      font-size: 1.1rem;
      color: #333;
    }
    .product-brand, .product-name {
      display: inline;
      color: #333;
    }
    .price-wishlist {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0;
    }
    .product-price {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .regular-price {
      color: #064e3b;
      font-weight: bold;
      font-size: 1.3rem;
    }
    .wishlist-remove-btn {
      background: none;
      border: none;
      cursor: pointer;
      margin-left: 10px;
      padding: 0;
    }
    .wishlist-remove-btn i {
      color: #ff4d4d;
      font-size: 1.2rem;
      transition: color 0.3s;
    }
    .wishlist-remove-btn i:hover {
      color: #064e3b;
    }
    @media (max-width: 768px) {
      .products-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 10px;
        padding: 0 10px;
      }
    }
    .breadcrumb a {
      color: #064e3b;
      text-decoration: none;
      font-weight: 600;
      transition: text-decoration 0.2s;
    }
    .breadcrumb a:hover {
      text-decoration: underline;
    }
    .aboutus-btn {
      margin-left: 20px;
      font-weight: bold;
      color: #ffffff;
      padding: 8px 20px;
      border-radius: 20px;
      text-decoration: none;
      transition: background 0.2s;
      display: inline-block;
    }
    .aboutus-btn:hover {
      background: #e6b800;
      color: #333;
    }
    .nav-history {
      display: inline-block;
      margin-left: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }
  </style>
</head>
<body>
  <header>
    <div class="top-bar">
      <div class="user-tools">
        <a href="Wishlist.php"><i class="fas fa-heart"></i> Wishlist</a>
        <a href="AccountCustomer.php"><i class="far fa-user"></i> Account</a>
      </div>
    </div>
    <nav>
      <div class="nav-left">
        <a href="#" class="logo" id="bakawaliLogoLink">
          <img src="bakawaliLogo.png" alt="bakawali Logo" />
        </a>
        <div class="nav-history">
          <button type="button" class="back-forward-btn" onclick="window.history.back();">
            <i class="fas fa-arrow-left"></i> Back
          </button>
          <button type="button" class="back-forward-btn" onclick="window.history.forward();">
            Forward <i class="fas fa-arrow-right"></i>
          </button>
        </div>
        <a href="../2.Homes/AboutUs.php" class="aboutus-btn">About Us</a>
      </div>
      <div class="cart">
        <a href="../5.Checkout/CartInterface.php" class="cart-icon">
          <i class="fas fa-shopping-cart"></i>
          <span class="cart-count">0</span>
        </a>
      </div>
    </nav>
  </header>
  <main class="container">
    <div class="product-section">
      <p class="breadcrumb"><a href="<?php echo $homeLink; ?>">Home</a> &gt; Wishlist</p>
      <h1>My Wishlist</h1>
      <div class="products">
        <div class="products-grid">
          <?php if (empty($wishlistProducts)): ?>
            <p>Your wishlist is empty.</p>
          <?php else: ?>
            <?php foreach ($wishlistProducts as $product): ?>
              <div class="product-card">
                <div class="product-image">
                  <img src="../Images/<?php echo isset($product['image']) ? htmlspecialchars($product['image']) : 'https://via.placeholder.com/150'; ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                </div>
                <div class="product-bottom">
                  <div>
                    <div class="product-title">
                      <span class="product-brand"><?php echo htmlspecialchars($product['brand']); ?></span>
                      <span class="product-name"> <?php echo htmlspecialchars($product['name']); ?></span>
                    </div>
                    <div class="price-wishlist">
                      <div class="product-price">
                        <span class="regular-price">RM <?php echo number_format($product['price'], 2); ?></span>
                      </div>
                      <button type="button" class="wishlist-remove-btn" data-product-id="<?php echo $product['productID']; ?>">
                        <i class="fas fa-heart"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </main>
  <script>
    var logoLink = document.getElementById('bakawaliLogoLink');
    if (logoLink) {
      logoLink.addEventListener('click', function(e) {
        e.preventDefault();
        var isMember = sessionStorage.getItem('isMember') === 'true';
        if (isMember) {
          window.location.href = '../2.Homes/MemberHome\'s.php';
        } else {
          window.location.href = '../2.Homes/NonMemberHome\'s.php';
        }
      });
    }

    document.querySelectorAll('.wishlist-remove-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const productId = btn.dataset.productId;
        const icon = btn.querySelector('i');
        if (icon.classList.contains('fas')) {
          // Remove from wishlist
          icon.classList.remove('fas');
          icon.classList.add('far');
          icon.style.color = '#064e3b';
          fetch('Wishlist.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `remove_product_id=${productId}`
          });
        } else {
          // Add back to wishlist
          icon.classList.remove('far');
          icon.classList.add('fas');
          icon.style.color = '#ff4d4d';
          fetch('Wishlist.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `add_product_id=${productId}`
          });
        }
      });
    });

    function updateCartCount() {
        // For members, fetch cart count from server
        fetch('../3.Searches/SearchInterface.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=get_counts'
        })
        .then(r => r.json())
        .then(data => {
            var cartCountElement = document.querySelector('.cart-count');
            if (cartCountElement && typeof data.cart_count !== 'undefined') {
                cartCountElement.textContent = data.cart_count;
            }
        });
    }
    document.addEventListener('DOMContentLoaded', updateCartCount);
  </script>
</body>
</html>