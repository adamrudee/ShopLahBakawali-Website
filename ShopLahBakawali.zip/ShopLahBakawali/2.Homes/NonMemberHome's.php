<?php
session_start();

// Database connection for NonMemberHome's.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Fetch products
$stmt = $pdo->prepare("SELECT * FROM product");
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Non Membership Interface | ShopLahBakawali</title>
  <!-- Font imports -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
  <style>
   /* Base body styles */
   body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #ffffff;
      color: #333;
      min-width: 100vw;
      min-height: 100vh;
      overflow-x: hidden;
    }

    /* Background overlay */
    body::before {
      content: '';
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-image: url(bakawaliBuilding.png);
      opacity: 0.4;
      z-index: -1;
    }

    /* Header styles */
    header {
      background-color: #064e3b;
      color: white;
      padding: 10px 0;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      width: 100vw;
      margin: 0;
      position: relative;
      left: 50%;
      right: 50%;
      margin-left: -50vw;
      margin-right: -50vw;
    }

    /* Container layout */
    .container {
      width: 100%;
      max-width: 100%;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Top bar styling */
    .top-bar {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding: 0 20px 10px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }

    .user-tools {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    

    .user-tools a {
      color: white;
      text-decoration: none;
      margin-left: 15px;
      font-size: 14px;
      display: flex;
      align-items: center;
    }

    .user-tools i {
      margin-right: 5px;
    }

    /* Navigation styles */
    nav {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      padding: 15px 40px;
      justify-content: flex-start;
    }

    .logo {
      height: 40px;
      margin-right: 40px;
    }

    .logo img {
      height: 100%;
    }

    .nav-left {
      display: flex;
      align-items: center;
      gap: 20px;
    }

    /* Hero section */
    .hero {
      background: url('https://images.unsplash.com/photo-1586201375773-8a0b56c1635b') no-repeat center center/cover;
      height: 90vh;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      text-align: center;
      color: white;
      position: relative;
      overflow: hidden;
    }

    .hero::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.4);
    }

    .hero-content {
      position: relative;
      z-index: 1;
      max-width: 800px;
      width: 90%;
      animation: fadeInUp 1s ease-out;
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .hero h1 {
      font-size: clamp(2.5rem, 5vw, 4rem);
      margin-bottom: 20px;
      font-weight: 700;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
      letter-spacing: -0.02em;
    }

    .hero p {
      font-size: clamp(1.2rem, 2.5vw, 1.8rem);
      margin-bottom: 40px;
      font-weight: 400;
      text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
      opacity: 0.95;
    }

    /* Search bar */
    .search-bar {
      display: flex;
      justify-content: center;
      margin-bottom: 40px;
      position: relative;
      max-width: 500px;
      margin-left: auto;
      margin-right: auto;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      overflow: hidden;
      transition: all 0.3s ease;
    }

    .search-bar:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
    }

    .search-bar input {
      padding: 16px 20px;
      font-size: 1rem;
      width: 100%;
      border: none;
      outline: none;
      background: white;
      color: #333;
      font-weight: 400;
    }

    .search-bar input::placeholder {
      color: #999;
      font-weight: 400;
    }

    .search-bar button {
      padding: 16px 24px;
      background: #064e3b;
      color: white;
      border: none;
      font-size: 1rem;
      cursor: pointer;
      border-radius: 0 8px 8px 0;
      transition: background 0.2s;
    }

    .search-bar button:hover {
      background: #043927;
    }

    .shop-button {
      display: inline-block;
      margin-top: 30px;
      padding: 16px 40px;
      background: #ffcc00;
      color: #333;
      border-radius: 30px;
      font-weight: bold;
      font-size: 1.2rem;
      text-decoration: none;
      transition: background 0.2s, color 0.2s;
    }

    .shop-button:hover {
      background: #e6b800;
      color: #222;
    }

    /* Membership CTA Section */
    .membership-cta {
      background: #f8f9fa;
      padding: 40px 0;
      text-align: center;
    }

    .membership-cta h2 {
      color: #064e3b;
      font-size: 2rem;
      margin-bottom: 10px;
    }

    .membership-cta p {
      color: #666;
      font-size: 1.1rem;
      margin-bottom: 25px;
    }

    .cta-buttons {
      display: flex;
      justify-content: center;
      gap: 20px;
      flex-wrap: wrap;
    }

    .cta-btn {
      padding: 12px 30px;
      border-radius: 30px;
      font-size: 1rem;
      font-weight: bold;
      text-decoration: none;
      transition: background 0.2s, color 0.2s;
      border: none;
      cursor: pointer;
    }

    .cta-btn.primary {
      background: #064e3b;
      color: white;
    }

    .cta-btn.primary:hover {
      background: #043927;
    }

    .cta-btn.secondary {
      background: #ffcc00;
      color: #333;
    }

    .cta-btn.secondary:hover {
      background: #e6b800;
      color: #222;
    }

    @media (max-width: 900px) {
      .hero {
        height: auto;
        padding: 40px 0;
      }
      .membership-cta {
        padding: 20px 0;
      }
    }
    @media (max-width: 600px) {
      nav, .top-bar {
        padding: 0 10px 10px;
      }
      .search-bar input {
        font-size: 0.9rem;
        padding: 12px 10px;
      }
      .shop-button {
        padding: 12px 20px;
        font-size: 1rem;
      }
      .cta-buttons {
        flex-direction: column;
        gap: 10px;
      }
    }

    .aboutus-btn {
      margin-left: 20px;
      font-weight: bold;
      color: #ffffff;
      padding: 8px 20px;
      border-radius: 20px;
      text-decoration: none;
      transition: background 0.2s;
      display: inline-block;
    }
    .aboutus-btn:hover {
      background: #e6b800;
      color: #333;
    }
    .nav-history {
      display: inline-block;
      margin-left: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }
  </style>
</head>
<body>
  <!-- Header section -->
  <header>
    <div class="container">
      <div class="top-bar">
        <div class="user-tools">
          <a href="../4.Accounts/Wishlist.php"><i class="far fa-heart"></i> Wishlist</a>
          <a href="../4.Accounts/AccountCustomer.php"><i class="far fa-user"></i> Account</a>
        </div>
      </div>
      <nav>
        <div class="nav-left">
          <a href="#" class="logo" id="bakawaliLogoLink">
            <img src="bakawaliLogo.png" alt="bakawali Logo" />
          </a>
          <div class="nav-history">
            <button type="button" class="back-forward-btn" onclick="window.history.back();">
              <i class="fas fa-arrow-left"></i> Back
            </button>
            <button type="button" class="back-forward-btn" onclick="window.history.forward();">
              Forward <i class="fas fa-arrow-right"></i>
            </button>
          </div>
          <a href="AboutUs.php" class="aboutus-btn">About Us</a>
        </div>
      </nav>
    </div>
  </header>

    <!-- Hero section -->
    <section class="hero">
    <div class="hero-content">
      <h1>Welcome to ShopLahBakawali</h1>
      <p>Your trusted neighborhood store, now online!</p>
      
      <div class="search-bar">
        <form method="get" action="../3.Searches/SearchInterface.php" style="display:flex;width:100%;position:relative;">
          <input type="text" name="q" placeholder="Search for products..." style="flex:1;">
          <button type="submit" style="position:absolute; right:0; top:0; background:none; border:none; cursor:pointer; height:100%; padding:0 20px; color:#064e3b;"><i class="fas fa-search"></i></button>
        </form>
      </div>

      <a class="shop-button" href="../3.Searches/SearchInterface.php">Start Shopping</a>
    </div>
  </section>

  <!-- Membership CTA Section -->
  <section class="membership-cta">
    <div class="container">
      <h2>Unlock Exclusive Benefits!</h2>
      <p>Join our membership program and enjoy special discounts, early access to promotions, and exclusive rewards on every purchase.</p>
      <div class="cta-buttons">
        <a href="../1.Login/RegistrationMembership.php" class="cta-btn primary">Register for Membership</a>
        <a href="../1.Login/Membership.php" class="cta-btn secondary">Already Have ID?</a>
      </div>
    </div>
  </section>
  <script>
    var logoLink = document.getElementById('bakawaliLogoLink');
    if (logoLink) {
      logoLink.addEventListener('click', function(e) {
        e.preventDefault();
        var isMember = sessionStorage.getItem('isMember') === 'true';
        if (isMember) {
          window.location.href = '../2.Homes/MemberHome\'s.php';
        } else {
          window.location.href = '../2.Homes/NonMemberHome\'s.php';
        }
      });
    }
    sessionStorage.setItem('isMember', 'false');

    function updateCartCount() {
        // Try to get cart from sessionStorage (for non-members or fallback)
        let cart = JSON.parse(sessionStorage.getItem('cart') || '{}');
        let count = 0;
        if (Array.isArray(cart)) {
            count = cart.length;
        } else if (typeof cart === 'object') {
            count = Object.keys(cart).length;
        }
        // Update the cart count in the DOM
        var cartCountElement = document.querySelector('.cart-count');
        if (cartCountElement) {
            cartCountElement.textContent = count;
        }
    }
    document.addEventListener('DOMContentLoaded', updateCartCount);
  </script>
</body>
</html> 