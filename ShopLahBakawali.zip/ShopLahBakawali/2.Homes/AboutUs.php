<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>About Us | ShopLahBakawali</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
  <style>
    /* Global Styles - Basic reset and container */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Arial', sans-serif;
    }

    body {
      background-color: #f5f5f5;
      color: #333;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 15px;
    }

    /* Header and Navigation */
    header {
      background-color: #064E3B;
      color: white;
      padding: 10px 0;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      width: 100%;
    }

    .top-bar {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding: 0 40px 10px;
      border-bottom: 1px solid rgba(255,255,255,0.2);
      width: 100%;
    }

    .user-tools {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .user-tools a {
      color: white;
      text-decoration: none;
      font-size: 14px;
      display: flex;
      align-items: center;
    }

    .user-tools i {
      margin-right: 5px;
    }

    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      padding: 15px 40px;
    }
    .nav-left {
      display: flex;
      align-items: center;
    }
    .logo img {
      height: 40px;
    }

    /* Search and Cart Section */
    .search-cart {
      display: flex;
      align-items: center;
      gap: 20px;
    }

    .search-box {
      position: relative;
    }

    .search-box input {
      padding: 8px 15px;
      border-radius: 20px;
      border: none;
      width: 200px;
    }

    .search-box i {
      position: absolute;
      right: 10px;
      top: 8px;
      color: #777;
    }

    .cart-icon {
      position: relative;
      color: white;
    }

    .cart-count {
      position: absolute;
      top: -8px;
      right: -8px;
      background-color: #ffcc00;
      color: #333;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      font-weight: bold;
    }

    /* Hero Section */
    .hero {
      background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80');
      background-size: cover;
      background-position: center;
      color: white;
      padding: 80px 0;
      text-align: center;
    }

    .hero h1 {
      font-size: 3rem;
      margin-bottom: 20px;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
    }

    .hero p {
      font-size: 1.3rem;
      margin-bottom: 30px;
      max-width: 800px;
      margin-left: auto;
      margin-right: auto;
      line-height: 1.6;
    }

    /* About Content Sections */
    .about-section {
      padding: 60px 0;
      background: white;
    }

    .about-section:nth-child(even) {
      background: #f8f9fa;
    }

    .section-title {
      text-align: center;
      margin-bottom: 50px;
      position: relative;
    }

    .section-title h2 {
      display: inline-block;
      background-color: white;
      padding: 0 30px;
      position: relative;
      z-index: 1;
      font-size: 2.5rem;
      color: #064E3B;
    }

    .section-title::after {
      content: '';
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      height: 3px;
      background: linear-gradient(90deg, #064E3B, #ffcc00);
      z-index: 0;
    }

    .about-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 40px;
      margin-top: 40px;
    }

    .about-card {
      background: white;
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
      text-align: center;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .about-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }

    .about-card i {
      font-size: 3rem;
      color: #064E3B;
      margin-bottom: 20px;
    }

    .about-card h3 {
      font-size: 1.5rem;
      color: #064E3B;
      margin-bottom: 15px;
    }

    .about-card p {
      color: #666;
      line-height: 1.6;
    }

    /* Story Section */
    .story-section {
      padding: 80px 0;
      background: linear-gradient(135deg, #064E3B 0%, #0f766e 100%);
      color: white;
    }

    .story-content {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 60px;
      align-items: center;
    }

    .story-text h2 {
      font-size: 2.5rem;
      margin-bottom: 30px;
      color: #ffcc00;
    }

    .story-text p {
      font-size: 1.1rem;
      line-height: 1.8;
      margin-bottom: 20px;
    }

    .story-image {
      text-align: center;
    }

    .story-image img {
      max-width: 100%;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    }

    /* Values Section */
    .values-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 30px;
      margin-top: 40px;
    }

    .value-item {
      background: white;
      border-radius: 15px;
      padding: 25px;
      text-align: center;
      box-shadow: 0 3px 15px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }

    .value-item:hover {
      transform: translateY(-3px);
    }

    .value-item i {
      font-size: 2.5rem;
      color: #ffcc00;
      margin-bottom: 15px;
    }

    .value-item h4 {
      font-size: 1.3rem;
      color: #064E3B;
      margin-bottom: 10px;
    }

    .value-item p {
      color: #666;
      line-height: 1.5;
    }

    /* Team Section */
    .team-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 30px;
      margin-top: 40px;
    }

    .team-member {
      background: white;
      border-radius: 15px;
      overflow: hidden;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }

    .team-member:hover {
      transform: translateY(-5px);
    }

    .team-photo {
      height: 200px;
      background: linear-gradient(45deg, #064E3B, #0f766e);
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .team-photo img {
      width: 100%;
      height: 200px;
      object-fit: contain;
      background: #e6f2f1;
      max-width: 100%;
      max-height: 100%;
      border-radius: 15px 15px 0 0;
      display: block;
      margin: 0 auto;
    }

    .team-photo i {
      font-size: 4rem;
      color: white;
    }

    .team-info {
      padding: 20px;
      text-align: justify;
    }

    .team-info h4 {
      font-size: 1.2rem;
      color: #064E3B;
      margin-bottom: 5px;
    }

    .team-info p {
      color: #666;
      font-style: italic;
    }

    /* Contact Section */
    .contact-info {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 30px;
      margin-top: 40px;
    }

    .contact-item {
      background: white;
      border-radius: 15px;
      padding: 25px;
      text-align: center;
      box-shadow: 0 3px 15px rgba(0,0,0,0.1);
    }

    .contact-item i {
      font-size: 2rem;
      color: #064E3B;
      margin-bottom: 15px;
    }

    .contact-item h4 {
      font-size: 1.2rem;
      color: #064E3B;
      margin-bottom: 10px;
    }

    .contact-item p {
      color: #666;
      line-height: 1.5;
    }

    /* Footer */
    footer {
      background-color: #064E3B;
      color: white;
      padding: 40px 0 20px;
      text-align: center;
    }

    .footer-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
    }

    .footer-logo img {
      height: 30px;
    }

    .footer-links {
      display: flex;
      gap: 20px;
    }

    .footer-links a {
      color: white;
      text-decoration: none;
      transition: color 0.3s ease;
    }

    .footer-links a:hover {
      color: #ffcc00;
    }

    .footer-bottom {
      margin-top: 20px;
      padding-top: 20px;
      border-top: 1px solid rgba(255,255,255,0.2);
      color: #ccc;
    }

    .aboutus-btn {
      margin-left: 20px;
      font-weight: bold;
      color: #ffffff;
      padding: 8px 20px;
      border-radius: 20px;
      text-decoration: none;
      transition: background 0.2s;
      display: inline-block;
    }
    .aboutus-btn:hover {
      background: #e6b800;
      color: #333;
    }
    .nav-history {
      display: inline-block;
      margin-left: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }

    /* Responsive Styles */
    @media (max-width: 900px) {
      .story-content {
        grid-template-columns: 1fr;
        gap: 40px;
      }
      
      .about-grid {
        grid-template-columns: 1fr;
      }
      
      .values-grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      }
      
      .team-grid {
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      }
      
      .contact-info {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 600px) {
      .top-bar, nav {
        padding: 0 15px 10px;
      }
      
      .search-box input {
        width: 150px;
      }
      
      .hero h1 {
        font-size: 2rem;
      }
      
      .hero p {
        font-size: 1rem;
      }
      
      .section-title h2 {
        font-size: 2rem;
      }
      
      .story-text h2 {
        font-size: 2rem;
      }
      
      .footer-content {
        flex-direction: column;
        text-align: center;
      }
    }
  </style>
</head>
<body>
  <!-- Header with User Tools -->
  <header>
    <div class="top-bar">
      <div class="user-tools">
        <a href="#" id="wishlistLink"><i class="far fa-heart"></i> Wishlist</a>
        <a href="#" id="accountLink"><i class="far fa-user"></i> Account</a>
      </div>
    </div>
    <!-- Navigation with Search and Cart -->
    <nav>
      <div class="nav-left">
        <a href="#" class="logo" id="bakawaliLogoLink">
          <img src="bakawaliLogo.png" alt="ShopLahBakawali Logo" />
        </a>
        <div class="nav-history">
          <button type="button" class="back-forward-btn" onclick="window.history.back();">
            <i class="fas fa-arrow-left"></i> Back
          </button>
          <button type="button" class="back-forward-btn" onclick="window.history.forward();">
            Forward <i class="fas fa-arrow-right"></i>
          </button>
        </div>
        <a href="AboutUs.php" class="aboutus-btn">About Us</a>
      </div>
      <div class="search-cart">
        <a href="../5.Checkout/CartInterface.php" class="cart-icon">
          <i class="fas fa-shopping-cart"></i>
          <span class="cart-count">0</span>
        </a>
      </div>
    </nav>
  </header>

  <!-- Hero Section -->
  <section class="hero">
    <div class="container">
      <h1>About ShopLahBakawali</h1>
      <p>Your trusted neighborhood store providing quality household essentials and groceries since 2010. We're committed to serving our community with excellence, convenience, and the best value for your money.</p>
    </div>
  </section>

  <!-- Our Story Section -->
  <section class="story-section">
    <div class="container">
      <div class="story-content">
        <div class="story-text">
          <h2>Our Story</h2>
          <p>Founded in 2010, ShopLahBakawali began as a small family-owned convenience store in the heart of our community. What started as a simple dream to provide quality household essentials has grown into a beloved neighborhood institution.</p>
          <p>Over the years, we've expanded our offerings to include a comprehensive range of groceries, personal care products, and household items, all while maintaining the personal touch and community spirit that made us successful.</p>
          <p>Today, we're proud to serve thousands of families with our commitment to quality, affordability, and exceptional customer service.</p>
        </div>
        <div class="story-image">
          <img src="bakawaliBuilding.png" alt="ShopLahBakawali Store" />
        </div>
      </div>
    </div>
  </section>

  <!-- What We Offer Section -->
  <section class="about-section">
    <div class="container">
      <div class="section-title">
        <h2>What We Offer</h2>
      </div>
      <div class="about-grid">
        <div class="about-card">
          <i class="fas fa-shopping-basket"></i>
          <h3>Quality Products</h3>
          <p>We carefully select each product in our inventory, ensuring only the best quality items reach our customers. From trusted brands to local favorites, we've got you covered.</p>
        </div>
        <div class="about-card">
          <i class="fas fa-tags"></i>
          <h3>Competitive Prices</h3>
          <p>We believe quality shouldn't break the bank. Our competitive pricing ensures you get the best value for your money on every purchase.</p>
        </div>
        <div class="about-card">
          <i class="fas fa-star"></i>
          <h3>Loyalty Program</h3>
          <p>Join our membership program and earn points on every purchase. Redeem your points for discounts and exclusive offers on future shopping trips.</p>
        </div>
        <div class="about-card">
          <i class="fas fa-truck"></i>
          <h3>Convenient Shopping</h3>
          <p>Whether you prefer to shop in-store or online, we provide multiple convenient options to meet your shopping needs and lifestyle.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Our Values Section -->
  <section class="about-section">
    <div class="container">
      <div class="section-title">
        <h2>Our Values</h2>
      </div>
      <div class="values-grid">
        <div class="value-item">
          <i class="fas fa-handshake"></i>
          <h4>Trust & Reliability</h4>
          <p>Building lasting relationships with our customers through consistent quality and reliable service.</p>
        </div>
        <div class="value-item">
          <i class="fas fa-heart"></i>
          <h4>Community First</h4>
          <p>Supporting and giving back to the community that has supported us throughout our journey.</p>
        </div>
        <div class="value-item">
          <i class="fas fa-leaf"></i>
          <h4>Sustainability</h4>
          <p>Committed to environmentally responsible practices and offering eco-friendly product options.</p>
        </div>
        <div class="value-item">
          <i class="fas fa-users"></i>
          <h4>Customer Focus</h4>
          <p>Your satisfaction is our priority. We listen, adapt, and continuously improve to serve you better.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Our Team Section -->
  <section class="about-section">
    <div class="container">
      <div class="section-title">
        <h2>Meet Our Team</h2>
      </div>
      <div class="team-grid">
        <div class="team-member">
          <div class="team-photo">
            <img src="adam.jpg">
          </div>
          <div class="team-info">
            <h4>Adam bin Ibrahim</h4>
            <p>Student Number: 2023866466</p>
            <p>Program code: JCDCS110</p>
            <p>Program name: Diploma in Computer Science</p>
            <p>Group/Class: 4F</p>
            <p>Email: 2023866466@student.uitm.edu.my</p>
          </div>
        </div>
        <div class="team-member">
          <div class="team-photo">
            <img src="ziyad.jpg">
          </div>
          <div class="team-info">
            <h4>Wan Ziyad Durrani bin Wan Faizal</h4>
            <p>Student Number: 2023801428</p>
            <p>Program code: JCDCS110</p>
            <p>Program name: Diploma in Computer Science</p>
            <p>Group/Class: 4F</p>
            <p>Email: 2023801428@student.uitm.edu.my</p>
          </div>
        </div>
        <div class="team-member">
          <div class="team-photo">
            <img src="bear.png">
          </div>
          <div class="team-info">
            <h4>Irfan Hakimi bin Md Parizal</h4>
            <p>Student Number: 2023848864</p>
            <p>Program code: JCDCS110</p>
            <p>Program name: Diploma in Computer Science</p>
            <p>Group/Class: 4F</p>
            <p>Email: 2023848864@student.uitm.edu.my</p>
          </div>
        </div>
        <div class="team-member">
          <div class="team-photo">
            <img src="apek.jpg">
          </div>
          <div class="team-info">
            <h4>Iskandar Irfan bin Gazali</h4>
            <p>Student Number: 2023677478</p>
            <p>Program code: JCDCS110</p>
            <p>Program name: Diploma in Computer Science</p>
            <p>Group/Class: 4F</p>
            <p>Email: 2023677478@student.uitm.edu.my</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Contact Information Section -->
  <section class="about-section">
    <div class="container">
      <div class="section-title">
        <h2>Get In Touch</h2>
      </div>
      <div class="contact-info">
        <div class="contact-item">
          <i class="fas fa-map-marker-alt"></i>
          <h4>Visit Us</h4>
          <p>123 Bakawali Street<br>Kuala Lumpur, Malaysia<br>50000</p>
        </div>
        <div class="contact-item">
          <i class="fas fa-phone"></i>
          <h4>Call Us</h4>
          <p>+60 3-1234 5678<br>Mon-Sat: 8AM-10PM<br>Sunday: 9AM-9PM</p>
        </div>
        <div class="contact-item">
          <i class="fas fa-envelope"></i>
          <h4>Email Us</h4>
          <p>info@shoplahbakawali.com<br>support@shoplahbakawali.com<br>We reply within 24 hours</p>
        </div>
        <div class="contact-item">
          <i class="fas fa-clock"></i>
          <h4>Business Hours</h4>
          <p>Monday - Saturday<br>8:00 AM - 10:00 PM<br>Sunday: 9:00 AM - 9:00 PM</p>
        </div>
      </div>
    </div>
  </section>


  <script>
    // Cart count (updated to fetch from server like Wishlist.php)
    function updateCartCount() {
      fetch('../3.Searches/SearchInterface.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=get_counts'
      })
      .then(r => r.json())
      .then(data => {
        var cartCountElement = document.querySelector('.cart-count');
        if (cartCountElement && typeof data.cart_count !== 'undefined') {
          cartCountElement.textContent = data.cart_count;
        }
      });
    }
    // Call updateCartCount on DOMContentLoaded
    document.addEventListener('DOMContentLoaded', function() {
      // Membership status
      const isMember = sessionStorage.getItem('isMember') === 'true';

      // Account and Wishlist redirect
      document.getElementById('accountLink').addEventListener('click', function(e) {
        e.preventDefault();
        window.location.href = '../4.Accounts/AccountCustomer.php';
      });
      document.getElementById('wishlistLink').addEventListener('click', function(e) {
        e.preventDefault();
        window.location.href = '../4.Accounts/Wishlist.php';
      });

      // Logo redirect
      const logoLink = document.getElementById('bakawaliLogoLink');
      if (logoLink) {
        logoLink.addEventListener('click', function(e) {
          e.preventDefault();
          if (isMember) {
            window.location.href = 'MemberHome\'s.php';
          } else {
            window.location.href = 'NonMemberHome\'s.php';
          }
        });
      }

      // Update cart count from server
      updateCartCount();
    });
  </script>
</body>
</html> 