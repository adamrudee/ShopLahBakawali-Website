<?php
session_start();
if (!isset($_SESSION['is_member']) || !$_SESSION['is_member']) {
    header("Location: ../1.Login/Membership.php");
    exit();
}
$membershipId = isset($_SESSION['membership_id']) ? $_SESSION['membership_id'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Membership Interface | ShopLahBakawali</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Arial', sans-serif;
    }
    body {
      background-color: #f5f5f5;
      color: #333;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 15px;
    }
    header {
      background-color: #064E3B;
      color: white;
      padding: 10px 0;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      width: 100%;
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 40px 10px;
      border-bottom: 1px solid rgba(255,255,255,0.2);
      width: 100%;
    }
    .membership-status {
      display: flex;
      align-items: center;
      gap: 10px;
      background-color: rgba(255, 255, 255, 0.1);
      padding: 5px 12px;
      border-radius: 20px;
      font-size: 14px;
    }
    .membership-status i {
      color: #ffcc00;
    }
    .user-tools {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    .user-tools a {
      color: white;
      text-decoration: none;
      font-size: 14px;
      display: flex;
      align-items: center;
    }
    .user-tools i {
      margin-right: 5px;
    }
    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      padding: 15px 40px;
    }
    .nav-left {
      display: flex;
      align-items: center;
    }
    .logo img {
      height: 40px;
    }
    .search-cart {
      display: flex;
      align-items: center;
      gap: 20px;
    }
    .search-box {
      position: relative;
    }
    .search-box input {
      padding: 8px 15px;
      border-radius: 20px;
      border: none;
      width: 200px;
    }
    .search-box i {
      position: absolute;
      right: 10px;
      top: 8px;
      color: #777;
    }
    .cart-icon {
      position: relative;
      color: white;
    }
    .cart-count {
      position: absolute;
      top: -8px;
      right: -8px; 
      background-color: #ffcc00;
      color: #333;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      font-weight: bold;
    }
    .hero {
      background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da');
      background-size: cover;
      background-position: center;
      color: white;
      padding: 60px 0;
      text-align: center;
    }
    .hero h1 {
      font-size: 2.5rem;
      margin-bottom: 15px;
    }
    .hero p {
      font-size: 1.2rem;
      margin-bottom: 25px;
      max-width: 700px;
      margin-left: auto;
      margin-right: auto;
    }
    .btn {
      display: inline-block;
      background-color: #ffcc00;
      color: #333;
      padding: 12px 30px;
      border-radius: 30px;
      text-decoration: none;
      font-weight: bold;
      transition: all 0.3s ease;
    }
    .btn:hover {
      background-color: #e6b800;
      transform: translateY(-2px);
    }
    .promo-section {
      padding: 40px 0;
    }
    .section-title {
      text-align: center;
      margin-bottom: 30px;
      position: relative;
    }
    .section-title h2 {
      display: inline-block;
      background-color: #f5f5f5;
      padding: 0 20px;
      position: relative;
      z-index: 1;
    }
    .section-title::after {
      content: '';
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      height: 2px;
      background: #eee;
      z-index: 0;
    }
    .promo-cards {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      justify-content: center;
    }
    .promo-card {
      background: white;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.08);
      padding: 20px;
      width: 250px;
      display: flex;
      flex-direction: column;
      align-items: center;
      cursor: pointer;
      transition: box-shadow 0.2s, transform 0.2s;
    }
    .promo-card:hover {
      box-shadow: 0 6px 20px rgba(0,0,0,0.15);
      transform: translateY(-3px);
    }
    .promo-img img {
      width: 100px;
      height: 100px;
      object-fit: contain;
      margin-bottom: 10px;
    }
    .promo-title {
      font-size: 1.1rem;
      font-weight: bold;
      margin-bottom: 8px;
      color: #064e3b;
    }
    .promo-price {
      color: #ff6b00;
      font-weight: bold;
      margin-bottom: 5px;
    }
    .promo-meta {
      display: flex;
      gap: 8px;
      font-size: 0.9rem;
      color: #666;
      align-items: center;
    }
    .promo-badge {
      background: #ffcc00;
      color: #333;
      border-radius: 8px;
      padding: 2px 8px;
      font-size: 0.8rem;
      font-weight: bold;
      margin-left: 5px;
    }
    @media (max-width: 900px) {
      .promo-cards {
        flex-direction: column;
        align-items: center;
      }
      .promo-card {
        width: 90%;
        margin-bottom: 20px;
      }
    }
    @media (max-width: 600px) {
      .top-bar, nav {
        padding: 0 10px 10px;
      }
      .search-box input {
        width: 100%;
      }
      .hero h1 {
        font-size: 2rem;
      }
      .hero p {
        font-size: 1rem;
      }
    }
    .aboutus-btn {
      margin-left: 20px;
      font-weight: bold;
      color: #ffffff;
      padding: 8px 20px;
      border-radius: 20px;
      text-decoration: none;
      transition: background 0.2s;
      display: inline-block;
    }
    .aboutus-btn:hover {
      background: #e6b800;
      color: #333;
    }
    .nav-history {
      display: inline-block;
      margin-left: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }
  </style>
</head>
<body>
  <!-- Header with User Tools -->
  <header>
    <div class="top-bar">
      <div class="membership-status">
        <i class="fas fa-star"></i>
        <span>Member ID: <?php echo htmlspecialchars($membershipId); ?></span>
      </div>
      <div class="user-tools">
        <a href="../4.Accounts/Wishlist.php"><i class="far fa-heart"></i> Wishlist</a>
        <a href="../4.Accounts/AccountCustomer.php"><i class="far fa-user"></i> Account</a>
      </div>
    </div>
    <!-- Navigation with Search and Cart -->
    <nav>
      <div class="nav-left">
        <a href="#" class="logo" id="bakawaliLogoLink">
          <img src="bakawaliLogo.png" alt="bakawaliLogo Logo" />
        </a>
        <div class="nav-history">
          <button type="button" class="back-forward-btn" onclick="window.history.back();">
            <i class="fas fa-arrow-left"></i> Back
          </button>
          <button type="button" class="back-forward-btn" onclick="window.history.forward();">
            Forward <i class="fas fa-arrow-right"></i>
          </button>
        </div>
        <a href="AboutUs.php" class="aboutus-btn">About Us</a>
      </div>
      <div class="search-cart">
        <form class="search-box" action="../3.Searches/SearchInterface.php" method="get">
          <input type="text" name="q" placeholder="Search products..." />
          <button type="submit" style="position:absolute; right:0; top:0; background:none; border:none; cursor:pointer; height:100%;"><i class="fas fa-search"></i></button>
        </form>
        <a href="../5.Checkout/CartInterface.php" class="cart-icon">
          <i class="fas fa-shopping-cart"></i>
          <span class="cart-count">0</span>
        </a>
      </div>
    </nav>
  </header>
  <!-- Hero Section -->
  <section class="hero">
    <div class="container">
      <h1>Earn Points on Every Purchase!</h1>
      <p>The household choice for the everyday people. Earn 10x your purchase value as points and redeem them for future rewards.</p>
      <a href="#" class="btn" id="shopNowBtn">SHOP NOW</a>
    </div>
  </section>
  <!-- Promotional Section -->
  <section class="promo-section">
    <div class="container">
      <div class="section-title">
        <h2>Exclusive Member Update!</h2>
      </div>
      <div class="promo-cards">
        <div class="promo-card">
          <div class="promo-img">
            <img src="colgate.png" alt="colgate toothbrush" />
          </div>
          <div class="promo-details">
            <div class="promo-title">Colgate toothbrush</div>
            <div class="promo-price">RM 9.99</div>
            <div class="promo-meta">
              <div class="promo-badge">Back in Stock!</div>
            </div>
          </div>
        </div>
        <div class="promo-card">
          <div class="promo-img">
            <img src="sensodyne.png" alt="sensodyne toothpaste" />
          </div>
          <div class="promo-details">
            <div class="promo-title">Sensodyne toothpaste</div>
            <div class="promo-price">RM 3.99</div>
            <div class="promo-meta">
              <div class="promo-badge">Back in Stock!</div>
            </div>
          </div>
        </div>
        <div class="promo-card">
          <div class="promo-img">
            <img src="darlie.png" alt="darlie toothpaste" />
          </div>
          <div class="promo-details">
            <div class="promo-title">Darlie toothpaste</div>
            <div class="promo-price">RM 5.50</div>
            <div class="promo-meta">
              <div class="promo-badge">Back in Stock!</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script>
    // Add click handlers for navigation
    document.addEventListener('DOMContentLoaded', function() {
      const shopNowBtn = document.getElementById('shopNowBtn');
      if (shopNowBtn) {
        shopNowBtn.addEventListener('click', function(e) {
          e.preventDefault();
          window.location.href = '../3.Searches/SearchInterface.php';
        });
      }
      // Add click handlers for promo cards
      const promoCards = document.querySelectorAll('.promo-card');
      promoCards.forEach(card => {
        card.addEventListener('click', function() {
          window.location.href = '../3.Searches/SearchInterface.php';
        });
      });
      var logoLink = document.getElementById('bakawaliLogoLink');
      if (logoLink) {
        logoLink.addEventListener('click', function(e) {
          e.preventDefault();
          var isMember = sessionStorage.getItem('isMember') === 'true';
          if (isMember) {
            window.location.href = '../2.Homes/MemberHome\'s.php';
          } else {
            window.location.href = '../2.Homes/NonMemberHome\'s.php';
          }
        });
      }
    });
    sessionStorage.setItem('isMember', 'true');
    function updateCartCount() {
        // For members, fetch cart count from server
        fetch('../3.Searches/SearchInterface.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=get_counts'
        })
        .then(r => r.json())
        .then(data => {
            var cartCountElement = document.querySelector('.cart-count');
            if (cartCountElement && typeof data.cart_count !== 'undefined') {
                cartCountElement.textContent = data.cart_count;
            }
        });
    }
    document.addEventListener('DOMContentLoaded', updateCartCount);
  </script>
</body>
</html> 