<?php
session_start();

// Database connection for RegistrationAccount.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$error = '';
$success = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullName'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    if ($fullname && $email && $phone && $password && $confirmPassword) {
        if ($password !== $confirmPassword) {
            $error = 'Passwords do not match!';
        } else {
            // Check for duplicate email
            $stmt = $pdo->prepare('SELECT * FROM customer WHERE email = ?');
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'Email already registered!';
            } else {
                // Generate unique membershipID
                function generateMembershipID($pdo) {
                    do {
                        $membershipId = '2023' . str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
                        $stmt = $pdo->prepare('SELECT 1 FROM customer WHERE membershipID = ?');
                        $stmt->execute([$membershipId]);
                    } while ($stmt->fetch());
                    return $membershipId;
                }
                $membershipId = generateMembershipID($pdo);
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare('INSERT INTO customer (email, password, fullname, phoneNumber, membershipID) VALUES (?, ?, ?, ?, ?)');
                if ($stmt->execute([$email, $hashed, $fullname, $phone, null])) {
                    // Get the last inserted customerID and set session
                    $_SESSION['customerID'] = $pdo->lastInsertId();
                    echo "<script>
                        alert('Registration successful! Redirecting to membership page.');
                        window.location.href = 'membership.php';
                    </script>";
                    exit;
                } else {
                    $error = 'Registration failed. Please try again.';
                }
            }
        }
    } else {
        $error = 'Please fill in all fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Register | ShopLahBakawali</title>
  <!-- Font Awesome CDN for eye icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body::before {
      content: "";
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-image: url('bakawaliBuilding.png');
      background-size: cover;
      background-position: center;
      opacity: 0.4;
      z-index: -1;
    }
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #fcf8ed;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
    }
    .container {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      display: flex;
      overflow: hidden;
      max-width: 500px;
      width: 90%;
      margin: 30px 0;
      flex-direction: column;
    }
    .form-container {
      flex: 1;
      padding: 25px 30px;
    }
    .form-logo {
      display: block;
      margin: 0 auto 15px auto;
      max-width: 250px;
      height: auto;
    }
    .form-container h2 {
      color: #0d6b34;
      margin-bottom: 15px;
      text-align: center;
      font-size: 22px;
    }
    .form-container form {
      display: flex;
      flex-direction: column;
    }
    .form-container input {
      padding: 10px;
      margin-bottom: 12px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 14px;
    }
    .form-container label {

      font-weight: 500;
      display: block;
    }
    .form-container button {
      padding: 10px 30px;
      background-color: #cccccc;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: not-allowed;
      margin-top: 16px;
      transition: background-color 0.3s ease;
    }
    .form-container button:enabled {
      background-color: #ff6b00;
      cursor: pointer;
    }
    .form-container button:enabled:hover {
      background-color: #e65c00;
    }
    .password-wrapper {
      position: relative;
      width: 100%;
      display: flex;
      align-items: center;
    }
    .password-wrapper input[type="password"],
    .password-wrapper input[type="text"] {
      width: 100%;
      box-sizing: border-box;
    }
    .toggle-password {
      margin-left: -35px;
      cursor: pointer;
      color: #888;
      font-size: 18px;
      z-index: 2;
      display: flex;
      align-items: center;
      margin-bottom: 12px;
    }
    .nav-history {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }
  </style>
</head>
<body>
<div class="container">
  <div class="nav-history" style="margin-bottom: 20px;">
    <button type="button" class="back-forward-btn" onclick="window.history.back();">
      <i class="fa fa-arrow-left"></i> Back
    </button>
    <button type="button" class="back-forward-btn" onclick="window.history.forward();">
      Forward <i class="fa fa-arrow-right"></i>
    </button>
  </div>
  <div class="form-container">
    <h2>Create Your Account</h2>
    <?php if ($success) echo "<div style='color:green;'>$success</div>"; ?>
    <?php if ($error) echo "<div style='color:red;'>$error</div>"; ?>
    <form method="post">
        <label for="fullName">Full Name:</label>
        <input type="text" id="fullName" name="fullName" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <label for="phone">Phone:</label>
        <input type="tel" id="phone" name="phone" required>
        <label for="password">Password:</label>
        <div class="password-wrapper">
          <input type="password" id="password" name="password" required>
          <span class="toggle-password" id="togglePassword">
            <i class="fa-regular fa-eye-slash" id="eyeIcon"></i>
          </span>
        </div>
        <label for="confirmPassword">Confirm Password:</label>
        <div class="password-wrapper">
          <input type="password" id="confirmPassword" name="confirmPassword" required>
          <span class="toggle-password" id="toggleConfirmPassword">
            <i class="fa-regular fa-eye-slash" id="eyeIconConfirm"></i>
          </span>
        </div>
        <button type="submit">Register</button>
    </form>
  </div>
</div>
<script>
// Password toggle for registration form
const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirmPassword');
const togglePassword = document.getElementById('togglePassword');
const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
const eyeIcon = document.getElementById('eyeIcon');
const eyeIconConfirm = document.getElementById('eyeIconConfirm');

togglePassword.addEventListener('click', () => {
  const isPassword = passwordInput.type === 'password';
  passwordInput.type = isPassword ? 'text' : 'password';
  eyeIcon.classList.toggle('fa-eye');
  eyeIcon.classList.toggle('fa-eye-slash');
});

toggleConfirmPassword.addEventListener('click', () => {
  const isPassword = confirmPasswordInput.type === 'password';
  confirmPasswordInput.type = isPassword ? 'text' : 'password';
  eyeIconConfirm.classList.toggle('fa-eye');
  eyeIconConfirm.classList.toggle('fa-eye-slash');
});
</script>
</body>
</html> 