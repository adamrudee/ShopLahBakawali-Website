<?php
// Database connection for AdminManageproduct.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

session_start();
if (!isset($_SESSION['adminID'])) {
    header('Location: LoginForm.php');
    exit;
}
$adminID = $_SESSION['adminID'];
$error = '';
$success = '';

// Handle Add Product
if (isset($_POST['addProduct'])) {
    $name = trim($_POST['name'] ?? '');
    $brand = trim($_POST['brand'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $image = '';
    
    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../Images/';
        $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_extension, $allowed_extensions)) {
            // Create a unique filename
            $image = $brand . '_' . $name . '.' . $file_extension;
            $image = str_replace(' ', '_', $image); // Replace spaces with underscores
            $upload_path = $upload_dir . $image;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                $success = 'Image uploaded successfully!';
            } else {
                $error = 'Failed to upload image.';
            }
        } else {
            $error = 'Invalid file type. Only JPG, PNG, and GIF are allowed.';
        }
    }
    
    if ($name && $brand && $category && $price > 0 && !$error) {
        $stmt = $pdo->prepare('INSERT INTO product (name, brand, category, price, image, adminID) VALUES (?, ?, ?, ?, ?, ?)');
        if ($stmt->execute([$name, $brand, $category, $price, $image, $adminID])) {
            $success = 'Product added successfully!';
            // Clear form
            $_POST = array();
        } else {
            $error = 'Failed to add product.';
        }
    } elseif (!$error) {
        $error = 'Please fill all required product fields.';
    }
}

// Handle Delete Product
if (isset($_POST['deleteProduct'])) {
    $productID = intval($_POST['productID']);
    
    // Get image filename before deleting
    $stmt = $pdo->prepare('SELECT image FROM product WHERE productID = ? AND adminID = ?');
    $stmt->execute([$productID, $adminID]);
    $product = $stmt->fetch();
    
    if ($product && $product['image']) {
        $image_path = '../Images/' . $product['image'];
        if (file_exists($image_path)) {
            unlink($image_path); // Delete image file
        }
    }
    
    $stmt = $pdo->prepare('DELETE FROM product WHERE productID = ? AND adminID = ?');
    $stmt->execute([$productID, $adminID]);
    $success = 'Product deleted successfully!';
}

// Handle Edit Product
if (isset($_POST['editProduct'])) {
    $productID = intval($_POST['productID']);
    $name = trim($_POST['name'] ?? '');
    $brand = trim($_POST['brand'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $current_image = trim($_POST['current_image'] ?? '');
    $image = $current_image; // Keep current image by default
    
    // Handle new image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../Images/';
        $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (in_array($file_extension, $allowed_extensions)) {
            // Delete old image if exists
            if ($current_image) {
                $old_image_path = $upload_dir . $current_image;
                if (file_exists($old_image_path)) {
                    unlink($old_image_path);
                }
            }
            
            // Create new image filename
            $image = $brand . '_' . $name . '.' . $file_extension;
            $image = str_replace(' ', '_', $image);
            $upload_path = $upload_dir . $image;
            
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                $success = 'Product updated with new image!';
            } else {
                $error = 'Failed to upload new image.';
            }
        } else {
            $error = 'Invalid file type. Only JPG, PNG, and GIF are allowed.';
        }
    }
    
    if ($name && $brand && $category && $price > 0 && !$error) {
        $stmt = $pdo->prepare('UPDATE product SET name = ?, brand = ?, category = ?, price = ?, image = ? WHERE productID = ? AND adminID = ?');
        if ($stmt->execute([$name, $brand, $category, $price, $image, $productID, $adminID])) {
            $success = 'Product updated successfully!';
        } else {
            $error = 'Failed to update product.';
        }
    } elseif (!$error) {
        $error = 'Please fill all required product fields.';
    }
}

// Fetch Products
$stmt = $pdo->prepare('SELECT * FROM product WHERE adminID = ? ORDER BY productID DESC');
$stmt->execute([$adminID]);
$products = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Product Management | ShopLahBakawali</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #fcf8ed;
    }
    header {
      background-color: #064E3B;
      color: white;
      padding: 15px 30px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      position: relative;
      z-index: 1001;
    }
    .logo-container {
      display: flex;
      align-items: center;
      margin-right: auto;
    }
    .logo-container img {
      height: 50px;
      margin-right: 15px;
    }
    .logo-container h1 {
      font-size: 22px;
      margin: 0;
    }
    .sidebar {
      position: fixed;
      left: -250px;
      top: 0;
      height: 100%;
      width: 250px;
      background-color: #064E3B;
      color: white;
      padding-top: 80px;
      transition: left 0.3s ease;
      z-index: 1000;
    }
    .sidebar.open {
      left: 0;
    }
    .sidebar-menu {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    .sidebar-menu li {
      margin: 0;
    }
    .sidebar-menu a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: white;
      text-decoration: none;
      transition: background-color 0.3s ease;
      border-left: 4px solid transparent;
    }
    .sidebar-menu a:hover {
      background-color: #0d6b4a;
    }
    .sidebar-menu a.active {
      background-color: #0d6b4a;
      border-left-color: #ff6b00;
    }
    .sidebar-menu i {
      margin-right: 15px;
      font-size: 18px;
      width: 20px;
      text-align: center;
    }
    .sidebar-menu span {
      font-weight: 500;
    }
    .main-content {
      margin-left: 0;
      padding: 20px;
      transition: margin-left 0.3s ease;
    }
    .main-content.sidebar-open {
      margin-left: 250px;
    }
    .menu-toggle {
      background: none;
      border: none;
      color: white;
      font-size: 24px;
      cursor: pointer;
      padding: 10px;
      margin-right: 20px;
    }
    .menu-toggle:hover {
      background: none;
      color: white;
    }
    .container {
      max-width: 1000px;
      margin: 40px auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    h2 {
      margin-top: 0;
      color: #333;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
    }
    table, th, td {
      border: 1px solid #ddd;
    }
    th, td {
      padding: 12px;
      text-align: left;
    }
    th {
      background-color: #f4f4f4;
    }
    button {
      padding: 8px 14px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      margin-right: 6px;
    }
    .btn-edit {
      background-color: #4caf50;
      color: white;
    }
    .btn-delete {
      background-color: #e53935;
      color: white;
    }
    .product-form {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      margin-bottom: 30px;
    }
    .form-section {
      margin-bottom: 30px;
    }
    .form-section h3 {
      color: #064E3B;
      font-size: 18px;
      font-weight: 600;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 2px solid #e5e7eb;
    }
    .form-row {
      display: flex;
      gap: 20px;
      margin-bottom: 20px;
    }
    .form-group {
      flex: 1;
      display: flex;
      flex-direction: column;
    }
    .form-group label {
      font-weight: 500;
      margin-bottom: 6px;
    }
    .form-group input, .form-group select {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 15px;
    }
    .image-upload-container {
      border: 2px dashed #ccc;
      border-radius: 8px;
      padding: 20px;
      text-align: center;
      cursor: pointer;
      background: #f8fafc;
      margin-bottom: 10px;
    }
    .upload-icon {
      color: #888;
      font-size: 1.2rem;
      margin-bottom: 5px;
    }
    .form-actions {
      text-align: right;
    }
    .btn-add {
      background-color: #ff6b00;
      color: white;
      border-radius: 8px;
      font-size: 15px;
      padding: 10px 20px;
      font-weight: 600;
      margin-top: 10px;
    }
    .btn-add:hover {
      background-color: #e65c00;
    }
    .table-container h3 {
      margin-top: 0;
    }
    @media (max-width: 768px) {
      .form-row {
        flex-direction: column;
      }
      .container {
        padding: 15px;
      }
    }
    /* Modal overlay styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 2000;
      left: 0;
      top: 0;
      width: 100vw;
      height: 100vh;
      background-color: rgba(0,0,0,0.5);
      overflow-y: auto;
    }
    .modal-content {
      background-color: white;
      margin: 8% auto;
      padding: 0;
      border-radius: 16px;
      width: 95%;
      max-width: 600px;
      box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3);
      animation: modalSlideIn 0.3s ease;
    }
    @keyframes modalSlideIn {
      from {
        opacity: 0;
        transform: translateY(-50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    .modal-header {
      background-color: #064E3B;
      color: white;
      padding: 20px;
      border-radius: 12px 12px 0 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .modal-header h3 {
      margin: 0;
      font-size: 18px;
    }
    .close {
      color: white;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
      line-height: 1;
    }
    .close:hover {
      opacity: 0.7;
    }
    .modal-body {
      padding: 40px 40px 32px 40px;
      text-align: center;
    }
    .modal-body p {
      margin: 0 0 25px 0;
      font-size: 16px;
      color: #333;
    }
    .modal-buttons {
      display: flex;
      gap: 15px;
      justify-content: center;
      margin-top: 20px;
      width: 100%;
    }
    .btn-cancel, .btn-confirm {
      padding: 12px 25px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      transition: all 0.3s ease;
    }
    .btn-cancel {
      background-color: #6c757d;
      color: white;
    }
    .btn-cancel:hover {
      background-color: #5a6268;
    }
    .btn-confirm {
      background-color: #dc3545;
      color: white;
    }
    .btn-confirm:hover {
      background-color: #c82333;
    }
    /* Modal input form styling and centering */
    #editProductForm {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 100%;
    }
    #editProductForm .form-section {
      background: #f8fafc;
      border-radius: 12px;
      padding: 20px 18px 12px 18px;
      margin-bottom: 22px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.04);
      width: 100%;
      max-width: 520px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    #editProductForm .form-section h3 {
      margin-top: 0;
      font-size: 1.1rem;
      color: #064E3B;
      letter-spacing: 0.5px;
      margin-bottom: 16px;
      text-align: center;
    }
    #editProductForm .form-row {
      display: flex;
      flex-direction: row;
      gap: 18px;
      width: 100%;
      margin-bottom: 10px;
    }
    #editProductForm .form-group {
      display: flex;
      flex-direction: column;
      margin-bottom: 0;
      width: 100%;
    }
    #editProductForm .form-group label {
      font-weight: 500;
      margin-bottom: 6px;
      color: #222;
    }
    #editProductForm .form-group input,
    #editProductForm .form-group select {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 15px;
      background: #fff;
      width: 100%;
      box-sizing: border-box;
    }
    #editProductForm .form-group input:focus,
    #editProductForm .form-group select:focus {
      border-color: #ff6b00;
      outline: none;
      box-shadow: 0 0 0 2px rgba(255, 107, 0, 0.08);
    }
    /* Remove number input spinners for all browsers */
    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    input[type=number] {
      appearance: textfield;
      -moz-appearance: textfield;
    }
    
    /* Image modal specific styles */
    #imageModal .modal-content {
      background: white;
      border-radius: 12px;
      overflow: hidden;
    }
    
    #imageModal .modal-header {
      background: #064e3b;
      color: white;
      padding: 15px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    #imageModal .modal-header h3 {
      margin: 0;
      font-size: 18px;
    }
    
    #imageModal .close {
      color: white;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
      background: none;
      border: none;
    }
    
    #imageModal .close:hover {
      color: #ff6b00;
    }
    
    /* Product image hover effect */
    .product-image-thumbnail {
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    .product-image-thumbnail:hover {
      transform: scale(1.05);
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
  </style>
</head>
<body>
  <header>
    <button class="menu-toggle" onclick="toggleSidebar()">
      <i class="fas fa-bars"></i>
    </button>
    <div class="logo-container">
      <a href="AdminHome.php">
        <img src="bakawaliLogo.png" alt="ShopLahBakawali Logo" />
      </a>
      <h1>Admin Dashboard - Manage Product</h1>
    </div>
  </header>
  <nav class="sidebar" id="sidebar">
    <ul class="sidebar-menu">
      <li><a href="AdminHome.php">
        <i class="fas fa-home"></i>
        <span>Dashboard</span>
      </a></li>
      <li><a href="AdminManageAccount.php">
        <i class="fas fa-users"></i>
        <span>Manage Account</span>
      </a></li>
      <li><a href="AdminManageproduct.php" class="active">
        <i class="fas fa-box"></i>
        <span>Manage Product</span>
      </a></li>
      <li><a href="AdminTrackorder.php">
        <i class="fas fa-truck"></i>
        <span>Track Order</span>
      </a></li>
      <li><a href="AdminGenerateSales.php">
        <i class="fas fa-chart-bar"></i>
        <span>Generate Sales</span>
      </a></li>
      <li><a href="#" onclick="showLogoutConfirmation()">
        <i class="fas fa-sign-out-alt"></i>
        <span>Logout</span>
      </a></li>
    </ul>
  </nav>
  <div class="main-content" id="mainContent">
    <div class="container">
      <h2>Product Management</h2>
      
      <?php if ($error): ?>
        <div style="background: #ffebee; color: #c62828; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #ffcdd2;">
          <?php echo htmlspecialchars($error); ?>
        </div>
      <?php endif; ?>
      
      <?php if ($success): ?>
        <div style="background: #e8f5e8; color: #2e7d32; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #c8e6c9;">
          <?php echo htmlspecialchars($success); ?>
        </div>
      <?php endif; ?>
      
      <div class="form-section">
        <h3>Add New Product</h3>
        <form method="POST" enctype="multipart/form-data">
          <div class="form-row">
            <div class="form-group">
              <label for="productBrand">Product Brand *</label>
              <input type="text" name="brand" id="productBrand" placeholder="Enter product brand" required value="<?php echo htmlspecialchars($_POST['brand'] ?? ''); ?>" />
            </div>
            <div class="form-group">
              <label for="productName">Product Name *</label>
              <input type="text" name="name" id="productName" placeholder="Enter product name" required value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" />
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label for="productCategory">Product Category *</label>
              <select name="category" id="productCategory" required>
                <option value="">Select category</option>
                <option value="Personal Care" <?php echo ($_POST['category'] ?? '') === 'Personal Care' ? 'selected' : ''; ?>>Personal Care</option>
                <option value="Beverages" <?php echo ($_POST['category'] ?? '') === 'Beverages' ? 'selected' : ''; ?>>Beverages</option>
                <option value="Dairy" <?php echo ($_POST['category'] ?? '') === 'Dairy' ? 'selected' : ''; ?>>Dairy</option>
                <option value="Snacks" <?php echo ($_POST['category'] ?? '') === 'Snacks' ? 'selected' : ''; ?>>Snacks</option>
                <option value="Household" <?php echo ($_POST['category'] ?? '') === 'Household' ? 'selected' : ''; ?>>Household</option>
                <option value="Stationery" <?php echo ($_POST['category'] ?? '') === 'Stationery' ? 'selected' : ''; ?>>Stationery</option>
              </select>
            </div>
            <div class="form-group">
              <label for="productPrice">Price (RM) *</label>
              <input type="number" name="price" id="productPrice" placeholder="0.00" step="0.01" min="0" required value="<?php echo htmlspecialchars($_POST['price'] ?? ''); ?>" />
            </div>
          </div>
          <div class="form-section">
            <h3>Product Image</h3>
            <div class="image-upload-container" onclick="document.getElementById('productImage').click()">
              <input type="file" name="image" id="productImage" accept="image/*" style="display:none;" />
              <div class="upload-icon">
                <i class="fas fa-cloud-upload-alt"></i>
                <span>Click to upload product image</span>
                <small>Supports: JPG, PNG, and GIF</small>
              </div>
              <span id="addProductImageFileName" style="display:block;margin-top:8px;color:#444;font-size:0.97rem;"></span>
            </div>
          </div>
          <div class="form-actions">
            <button type="submit" name="addProduct" class="btn-add">Add Product</button>
          </div>
        </form>
      </div>
      <div class="table-container">
        <h3>Product List</h3>
        <table id="productTable">
          <thead>
            <tr>
              <th>Product Brand</th>
              <th>Product Name</th>
              <th>Product Category</th>
              <th>Price (RM)</th>
              <th>Image</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products as $product): ?>
              <tr>
                <td><?php echo htmlspecialchars($product['brand']); ?></td>
                <td><?php echo htmlspecialchars($product['name']); ?></td>
                <td><?php echo htmlspecialchars($product['category']); ?></td>
                <td>RM <?php echo number_format($product['price'], 2); ?></td>
                <td>
                  <?php if ($product['image']): ?>
                    <img src="../Images/<?php echo htmlspecialchars($product['image']); ?>" 
                         alt="<?php echo htmlspecialchars($product['name']); ?>" 
                         class="product-image-thumbnail"
                         style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px; cursor: pointer;"
                         title="Click to view full image"
                         onclick="showImageModal('<?php echo htmlspecialchars($product['image']); ?>', '<?php echo htmlspecialchars($product['name']); ?>')">
                    <br>
                    <a href="#" onclick="showImageModal('<?php echo htmlspecialchars($product['image']); ?>', '<?php echo htmlspecialchars($product['name']); ?>'); return false;" 
                       style="color: #064e3b; text-decoration: underline; font-size: 12px;"
                       title="Click to view full image">
                      <i class="fas fa-eye" style="margin-right: 3px;"></i><?php echo htmlspecialchars($product['image']); ?>
                    </a>
                  <?php else: ?>
                    <span style="color: #999;">No image</span>
                  <?php endif; ?>
                </td>
                <td>
                  <form method="POST" style="display: inline;">
                    <button
                      type="button"
                      class="btn-edit"
                      onclick="openEditModal(this)"
                      data-product-id="<?php echo $product['productID']; ?>"
                      data-brand="<?php echo htmlspecialchars($product['brand']); ?>"
                      data-name="<?php echo htmlspecialchars($product['name']); ?>"
                      data-category="<?php echo htmlspecialchars($product['category']); ?>"
                      data-price="<?php echo htmlspecialchars($product['price']); ?>"
                      data-image="<?php echo htmlspecialchars($product['image']); ?>"
                    >
                      Edit
                    </button>
                  </form>
                  <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this product?');">
                    <input type="hidden" name="productID" value="<?php echo $product['productID']; ?>">
                    <button type="submit" name="deleteProduct" class="btn-delete">Delete</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <!-- Modals -->
  <div id="logoutModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Confirm Logout</h3>
        <span class="close" onclick="closeLogoutModal()">&times;</span>
      </div>
      <div class="modal-body">
        <p>Are you sure you want to logout from your admin account?</p>
        <div class="modal-buttons">
          <button class="btn-cancel" onclick="closeLogoutModal()">Cancel</button>
          <button class="btn-confirm" onclick="logout()">Logout</button>
        </div>
      </div>
    </div>
  </div>
  <div id="deleteProductModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Delete Product</h3>
        <span class="close" onclick="closeDeleteProductModal()">&times;</span>
      </div>
      <div class="modal-body">
        <p>Are you sure you want to delete this product? This action cannot be undone.</p>
        <div class="modal-buttons">
          <button class="btn-cancel" onclick="closeDeleteProductModal()">Cancel</button>
          <button class="btn-confirm" onclick="confirmDeleteProduct()">Delete</button>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Image Modal -->
  <div id="imageModal" class="modal">
    <div class="modal-content" style="max-width: 80%; max-height: 80%; text-align: center;">
      <div class="modal-header">
        <h3 id="imageModalTitle">Product Image</h3>
        <span class="close" onclick="closeImageModal()">&times;</span>
      </div>
      <div class="modal-body" style="padding: 20px;">
        <img id="modalImage" src="" alt="" style="max-width: 100%; max-height: 60vh; object-fit: contain; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
        <div style="margin-top: 15px;">
          <p id="imageFileName" style="color: #666; font-size: 14px; margin: 0;"></p>
        </div>
      </div>
    </div>
  </div>
  
  <script>
    // Sidebar functionality
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      const mainContent = document.getElementById('mainContent');
      sidebar.classList.toggle('open');
      mainContent.classList.toggle('sidebar-open');
    }
    // Logout functionality
    function showLogoutConfirmation() {
      const modal = document.getElementById('logoutModal');
      modal.style.display = 'block';
    }
    function closeLogoutModal() {
      const modal = document.getElementById('logoutModal');
      modal.style.display = 'none';
    }
    function logout() {
      window.location.href = 'LoginForm.php';
    }
    // Product management logic
    function openEditModal(btn) {
      document.getElementById('editProductID').value = btn.getAttribute('data-product-id');
      document.getElementById('editProductBrand').value = btn.getAttribute('data-brand');
      document.getElementById('editProductName').value = btn.getAttribute('data-name');
      document.getElementById('editProductCategory').value = btn.getAttribute('data-category');
      document.getElementById('editProductPrice').value = btn.getAttribute('data-price');
      document.getElementById('editCurrentImage').value = btn.getAttribute('data-image');
      var imgDiv = document.getElementById('currentImageDisplay');
      if (btn.getAttribute('data-image')) {
        imgDiv.innerHTML = '<img src="../Images/' + btn.getAttribute('data-image') + '" style="width:80px;height:80px;object-fit:cover;border-radius:4px;"><p>Current image: ' + btn.getAttribute('data-image') + '</p>';
      } else {
        imgDiv.innerHTML = '<p>No current image</p>';
      }
      document.getElementById('editProductModal').style.display = 'block';
    }
    
    function closeEditProductModal() {
      document.getElementById('editProductModal').style.display = 'none';
      document.getElementById('editProductForm').reset();
      document.getElementById('currentImageDisplay').innerHTML = '';
    }
    
    // Image Modal functions
    function showImageModal(imageFilename, productName) {
      const modal = document.getElementById('imageModal');
      const modalImage = document.getElementById('modalImage');
      const modalTitle = document.getElementById('imageModalTitle');
      const imageFileName = document.getElementById('imageFileName');
      
      // Set the image source
      modalImage.src = '../Images/' + imageFilename;
      modalImage.alt = productName;
      
      // Set the modal title and filename
      modalTitle.textContent = productName;
      imageFileName.textContent = 'Filename: ' + imageFilename;
      
      // Show the modal
      modal.style.display = 'block';
    }
    
    function closeImageModal() {
      document.getElementById('imageModal').style.display = 'none';
    }
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
      const logoutModal = document.getElementById('logoutModal');
      const editModal = document.getElementById('editProductModal');
      const imageModal = document.getElementById('imageModal');
      if (event.target === logoutModal) closeLogoutModal();
      if (event.target === editModal) closeEditProductModal();
      if (event.target === imageModal) closeImageModal();
    });
    
    // Add Product Image File Name Display
    document.getElementById('productImage').addEventListener('change', function() {
      const fileNameSpan = document.getElementById('addProductImageFileName');
      if (this.files && this.files[0]) {
        fileNameSpan.textContent = this.files[0].name;
      } else {
        fileNameSpan.textContent = '';
      }
    });
    
    // Edit Product Image File Name Display
    document.getElementById('editProductImageFile').addEventListener('change', function() {
      const fileNameSpan = document.getElementById('editProductImageFileName');
      if (this.files && this.files[0]) {
        fileNameSpan.textContent = this.files[0].name;
      } else {
        fileNameSpan.textContent = '';
      }
    });
    
    // Keyboard shortcuts for modals
    document.addEventListener('keydown', function(event) {
      if (event.key === 'Escape') {
        const imageModal = document.getElementById('imageModal');
        const editModal = document.getElementById('editProductModal');
        const logoutModal = document.getElementById('logoutModal');
        
        if (imageModal.style.display === 'block') {
          closeImageModal();
        } else if (editModal.style.display === 'block') {
          closeEditProductModal();
        } else if (logoutModal.style.display === 'block') {
          closeLogoutModal();
        }
      }
    });
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(event) {
      const sidebar = document.getElementById('sidebar');
      const menuToggle = document.querySelector('.menu-toggle');
      if (window.innerWidth <= 768) {
        if (!sidebar.contains(event.target) && !menuToggle.contains(event.target)) {
          sidebar.classList.remove('open');
          document.getElementById('mainContent').classList.remove('sidebar-open');
        }
      }
    });
    // Logo redirect functionality
    document.addEventListener('DOMContentLoaded', function() {
      const logoContainer = document.querySelector('.logo-container');
      if (logoContainer) {
        logoContainer.addEventListener('click', function(e) {
          e.preventDefault();
          window.location.href = 'AdminHome.php';
        });
        logoContainer.style.cursor = 'pointer';
      }
    });
  </script>
  <div id="editProductModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h3>Edit Product</h3>
        <span class="close" onclick="closeEditProductModal()">&times;</span>
      </div>
      <div class="modal-body">
        <form id="editProductForm" method="POST" enctype="multipart/form-data">
          <input type="hidden" name="productID" id="editProductID">
          <input type="hidden" name="current_image" id="editCurrentImage">
          <div class="form-row">
            <div class="form-group">
              <label>Product Brand *</label>
              <input type="text" name="brand" id="editProductBrand" required />
            </div>
            <div class="form-group">
              <label>Product Name *</label>
              <input type="text" name="name" id="editProductName" required />
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Product Category *</label>
              <select name="category" id="editProductCategory" required>
                <option value="">Select category</option>
                <option value="Personal Care">Personal Care</option>
                <option value="Beverages">Beverages</option>
                <option value="Dairy">Dairy</option>
                <option value="Snacks">Snacks</option>
                <option value="Household">Household</option>
                <option value="Stationery">Stationery</option>
              </select>
            </div>
            <div class="form-group">
              <label>Price (RM) *</label>
              <input type="number" name="price" id="editProductPrice" step="0.01" min="0" required />
            </div>
          </div>
          <div class="form-section">
            <h3>Product Image</h3>
            <div id="currentImageDisplay" style="margin-bottom: 15px; text-align: center;"></div>
            <input type="file" name="image" id="editProductImageFile" accept="image/*" />
          </div>
          <div class="form-actions">
            <button type="button" class="btn-cancel" onclick="closeEditProductModal()">Cancel</button>
            <button type="submit" name="editProduct" class="btn-add">Update Product</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <style>
    .modal { display: none; position: fixed; z-index: 2000; left: 0; top: 0; width: 100vw; height: 100vh; background-color: rgba(0,0,0,0.5); overflow-y: auto; }
    .modal-content { background-color: white; margin: 8% auto; padding: 0; border-radius: 16px; width: 95%; max-width: 600px; box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3); }
    .modal-header { background-color: #064E3B; color: white; padding: 20px; border-radius: 12px 12px 0 0; display: flex; justify-content: space-between; align-items: center; }
    .modal-header h3 { margin: 0; font-size: 18px; }
    .close { color: white; font-size: 28px; font-weight: bold; cursor: pointer; line-height: 1; }
    .close:hover { opacity: 0.7; }
    .modal-body { padding: 40px 40px 32px 40px; text-align: center; }
    .form-actions { text-align: right; margin-top: 20px; }
    .btn-cancel { background-color: #6c757d; color: white; padding: 10px 20px; border-radius: 8px; font-size: 15px; font-weight: 600; margin-right: 10px; border: none; }
    .btn-add { background-color: #ff6b00; color: white; border-radius: 8px; font-size: 15px; padding: 10px 20px; font-weight: 600; border: none; }
    .btn-add:hover { background-color: #e65c00; }
  </style>
  <script>
    function openEditModal(btn) {
      document.getElementById('editProductID').value = btn.getAttribute('data-product-id');
      document.getElementById('editProductBrand').value = btn.getAttribute('data-brand');
      document.getElementById('editProductName').value = btn.getAttribute('data-name');
      document.getElementById('editProductCategory').value = btn.getAttribute('data-category');
      document.getElementById('editProductPrice').value = btn.getAttribute('data-price');
      document.getElementById('editCurrentImage').value = btn.getAttribute('data-image');
      var imgDiv = document.getElementById('currentImageDisplay');
      if (btn.getAttribute('data-image')) {
        imgDiv.innerHTML = '<img src="../Images/' + btn.getAttribute('data-image') + '" style="width:80px;height:80px;object-fit:cover;border-radius:4px;"><p>Current image: ' + btn.getAttribute('data-image') + '</p>';
      } else {
        imgDiv.innerHTML = '<p>No current image</p>';
      }
      document.getElementById('editProductModal').style.display = 'block';
    }
    function closeEditProductModal() {
      document.getElementById('editProductModal').style.display = 'none';
      document.getElementById('editProductForm').reset();
      document.getElementById('currentImageDisplay').innerHTML = '';
    }
  </script>
</body>
</html> 