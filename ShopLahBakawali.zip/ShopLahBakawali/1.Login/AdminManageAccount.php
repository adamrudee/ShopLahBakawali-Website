<?php
session_start();

// Prevent browser caching (very important!)
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

// Check if admin is logged in
if (!isset($_SESSION['adminID'])) {
    header("Location: LoginForm.php");
    exit();
}

// Database connection
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Handle deletion
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
        $deleteId = intval($_POST['delete_id']);
        $stmt = $pdo->prepare("DELETE FROM customer WHERE customerID = ?");
        $stmt->execute([$deleteId]);

        // Redirect to prevent form resubmission and force refresh
        header("Location: AdminManageAccount.php");
        exit();
    }

    // Fetch all customers
    $stmt = $pdo->query("SELECT * FROM customer ORDER BY customerID ASC");
    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . htmlspecialchars($e->getMessage()));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Admin Dashboard | ShopLahBakawali</title>
<style>
body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #fcf8ed;
    }

    header {
      background-color: #064E3B;
      color: white;
      padding: 15px 30px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      position: relative;
      z-index: 1001;
    }

    .logo-container {
      display: flex;
      align-items: center;
      margin-right: auto;
    }

    .logo-container img {
      height: 50px;
      margin-right: 15px;
    }

    .logo-container h1 {
      font-size: 22px;
      margin: 0;
    }

    /* Sidebar styles */
    .sidebar {
      position: fixed;
      left: -250px;
      top: 0;
      height: 100%;
      width: 250px;
      background-color: #064E3B;
      color: white;
      padding-top: 80px;
      transition: left 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      left: 0;
    }

    .sidebar-menu {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .sidebar-menu li {
      margin: 0;
    }

    .sidebar-menu a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: white;
      text-decoration: none;
      transition: background-color 0.3s ease;
      border-left: 4px solid transparent;
    }

    .sidebar-menu a:hover {
      background-color: #0d6b4a;
    }

    .sidebar-menu a.active {
      background-color: #0d6b4a;
      border-left-color: #ff6b00;
    }

    .sidebar-menu i {
      margin-right: 15px;
      font-size: 18px;
      width: 20px;
      text-align: center;
    }

    .sidebar-menu span {
      font-weight: 500;
    }

    /* Main content */
    .main-content {
      margin-left: 0;
      padding: 20px;
      transition: margin-left 0.3s ease;
    }

    .main-content.sidebar-open {
      margin-left: 250px;
    }

    /* Menu toggle */
    .menu-toggle {
      background: none;
      border: none;
      color: white;
      font-size: 24px;
      cursor: pointer;
      padding: 10px;
      margin-right: 20px;
    }

    .menu-toggle:hover {
      background: none;
      color: white;
    }

    .container {
      max-width: 1000px;
      margin: 40px auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    h2 {
      margin-top: 0;
      color: #333;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
    }

    table, th, td {
      border: 1px solid #ddd;
    }

    th, td {
      padding: 12px;
      text-align: left;
    }

    th {
      background-color: #f4f4f4;
    }

    button {
      padding: 8px 14px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      margin-right: 6px;
    }

    .btn-edit {
      background-color: #4caf50;
      color: white;
    }

    .btn-delete {
      background-color: #e53935;
      color: white;
    }

    form {
      display: flex;
      flex-wrap: wrap;
      gap: 15px;
      margin-bottom: 20px;
    }

    input[type="text"],
    input[type="email"] {
      flex: 1;
      padding: 10px;
      font-size: 15px;
      border: 1px solid #ccc;
      border-radius: 8px;
    }

    .btn-add {
      background-color: #ff6b00;
      color: white;
      border-radius: 8px;
      font-size: 15px;
      padding: 10px 20px;
    }

    /* Form styling */
    .form-row {
      display: flex;
      gap: 20px;
      margin-bottom: 15px;
    }

    .form-group {
      flex: 1;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: 600;
      color: #333;
    }

    .form-group input {
      width: 100%;
      padding: 10px;
      font-size: 15px;
      border: 1px solid #ccc;
      border-radius: 8px;
      box-sizing: border-box;
    }

    .form-group input:focus {
      border-color: #ff6b00;
      outline: none;
      box-shadow: 0 0 0 2px rgba(255, 107, 0, 0.2);
    }

    .table-container {
      margin-top: 30px;
    }

    .table-container h3 {
      margin-bottom: 15px;
      color: #333;
    }

    /* Overlay for mobile */
    .sidebar-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 999;
    }

    .sidebar-overlay.open {
      display: block;
    }

    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 2000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }

    .modal-content {
      background-color: white;
      margin: 8% auto;
      padding: 0;
      border-radius: 16px;
      width: 95%;
      max-width: 600px;
      box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3);
      animation: modalSlideIn 0.3s ease;
    }

    @keyframes modalSlideIn {
      from {
        opacity: 0;
        transform: translateY(-50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .modal-header {
      background-color: #064E3B;
      color: white;
      padding: 20px;
      border-radius: 12px 12px 0 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .modal-header h3 {
      margin: 0;
      font-size: 18px;
    }

    .close {
      color: white;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
      line-height: 1;
    }

    .close:hover {
      opacity: 0.7;
    }

    .modal-body {
      padding: 40px 40px 32px 40px;
      text-align: center;
    }

    .modal-body p {
      margin: 0 0 25px 0;
      font-size: 16px;
      color: #333;
    }

    .modal-buttons {
      display: flex;
      gap: 15px;
      justify-content: center;
      margin-top: 20px;
      width: 100%;
    }

    .btn-cancel, .btn-confirm {
      padding: 12px 25px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      transition: all 0.3s ease;
    }

    .btn-cancel {
      background-color: #6c757d;
      color: white;
    }

    .btn-cancel:hover {
      background-color: #5a6268;
    }

    .btn-confirm {
      background-color: #dc3545;
      color: white;
    }

    .btn-confirm:hover {
      background-color: #c82333;
    }

    /* Hide number input spinners for all browsers */
    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    input[type=number] {
      appearance: textfield;
      -moz-appearance: textfield;
    }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<header>
  <button class="menu-toggle" onclick="toggleSidebar()">
    <i class="fas fa-bars"></i>
  </button>
  <div class="logo-container">
    <a href="AdminHome.php">
      <img src="bakawaliLogo.png" alt="ShopLahBakawali Logo" />
    </a>
    <h1>Admin Dashboard - Manage Account</h1>
  </div>
</header>

<nav class="sidebar" id="sidebar">
  <ul class="sidebar-menu">
    <li><a href="AdminHome.php"><i class="fas fa-home"></i><span>Dashboard</span></a></li>
    <li><a href="AdminManageAccount.php" class="active"><i class="fas fa-users"></i><span>Manage Account</span></a></li>
    <li><a href="AdminManageproduct.php"><i class="fas fa-box"></i><span>Manage Product</span></a></li>
    <li><a href="AdminTrackorder.php"><i class="fas fa-truck"></i><span>Track Order</span></a></li>
    <li><a href="AdminGenerateSales.php"><i class="fas fa-chart-bar"></i><span>Generate Sales</span></a></li>
    <li><a href="#" onclick="showLogoutConfirmation()"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
  </ul>
</nav>

<div id="logoutModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Confirm Logout</h3>
      <span class="close" onclick="closeLogoutModal()">&times;</span>
    </div>
    <div class="modal-body">
      <p>Are you sure you want to logout?</p>
      <div class="modal-buttons">
        <button class="btn-cancel" onclick="closeLogoutModal()">Cancel</button>
        <button class="btn-confirm" onclick="logout()">Logout</button>
      </div>
    </div>
  </div>
</div>

<div class="main-content" id="mainContent">
  <div class="container">
    <h2>Customer Management</h2>
    <p style="color: #666; margin-bottom: 20px;">View and manage existing customer accounts.</p>
    <div class="table-container">
      <h3>Customer List</h3>
      <table>
        <thead>
          <tr>
            <th>Full Name</th>
            <th>Email</th>
            <th>Password</th>
            <th>Membership ID</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php if (empty($customers)): ?>
          <tr><td colspan="5" style="text-align:center;">No customers found.</td></tr>
        <?php else: ?>
          <?php foreach ($customers as $cust): ?>
          <tr>
            <td><?php echo htmlspecialchars($cust['fullname']); ?></td>
            <td><?php echo htmlspecialchars($cust['email']); ?></td>
            <td><?php echo str_repeat('*', 8); ?></td>
            <td><?php echo htmlspecialchars($cust['membershipID']); ?></td>
            <td>
              <form method="post" onsubmit="return confirm('Delete this customer?');" style="display:inline;">
                <input type="hidden" name="delete_id" value="<?php echo $cust['customerID']; ?>">
                <button type="submit" class="btn-delete">Delete</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
// Sidebar
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('mainContent').classList.toggle('sidebar-open');
}

// Logout Modal
function showLogoutConfirmation() {
  document.getElementById('logoutModal').style.display = 'block';
}
function closeLogoutModal() {
  document.getElementById('logoutModal').style.display = 'none';
}
function logout() {
  window.location.href = 'LoginForm.html';
}

// Close modal when clicking outside
window.onclick = function(event) {
  const modal = document.getElementById('logoutModal');
  if (event.target === modal) {
    closeLogoutModal();
  }
};
</script>
</body>
</html>
