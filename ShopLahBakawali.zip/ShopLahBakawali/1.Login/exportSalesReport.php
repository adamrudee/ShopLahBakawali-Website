<?php
require_once __DIR__ . '/TCPDF/tcpdf.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shoplahbakawali";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : '';
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : '';

$orders = [];
$totalSales = 0;
$totalCustomers = 0;

if (!empty($startDate) && !empty($endDate)) {
    $stmt = $conn->prepare("SELECT c.checkoutID, c.fullName, c.email, c.finalPrice, c.date, t.shippingStatus 
                            FROM checkout c
                            JOIN tracking t ON t.checkoutID = c.checkoutID
                            WHERE c.date BETWEEN ? AND ?");
    $stmt->bind_param("ss", $startDate, $endDate);
    $stmt->execute();
    $result = $stmt->get_result();
    $emails = [];
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
        if (!empty(trim($row['email']))) {
            $emails[] = strtolower(trim($row['email']));
        }
        $totalSales += $row['finalPrice'];
    }
    $totalCustomers = count(array_unique($emails));
}

// Create new PDF document
$pdf = new TCPDF('L', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('ShopLahBakawali');
$pdf->SetTitle('Sales Report');
$pdf->SetHeaderData('', 0, 'Sales Report', "From: $startDate To: $endDate");
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
$pdf->SetMargins(10, 20, 10);
$pdf->SetHeaderMargin(10);
$pdf->SetFooterMargin(10);
$pdf->SetAutoPageBreak(TRUE, 15);
$pdf->SetFont('dejavusans', '', 10);
$pdf->AddPage();

// Summary
$html = '<h2>Sales Summary</h2>';
$html .= '<table border="1" cellpadding="5"><tr><th>Total Customers</th><th>Total Sales (RM)</th></tr>';
$html .= '<tr><td>' . $totalCustomers . '</td><td>RM ' . number_format($totalSales, 2) . '</td></tr></table><br><br>';

// Detailed Report Table
$html .= '<h2>Detailed Report</h2>';
$html .= '<table border="1" cellpadding="4"><thead><tr>';
$html .= '<th>Order No</th><th>Customer Name</th><th>Customer Email</th><th>Total Price (RM)</th><th>Order Date</th><th>Status</th>';
$html .= '</tr></thead><tbody>';
if (!empty($orders)) {
    foreach ($orders as $order) {
        $html .= '<tr>';
        $html .= '<td>' . htmlspecialchars($order['checkoutID']) . '</td>';
        $html .= '<td>' . htmlspecialchars($order['fullName']) . '</td>';
        $html .= '<td>' . htmlspecialchars($order['email']) . '</td>';
        $html .= '<td>RM ' . number_format($order['finalPrice'], 2) . '</td>';
        $html .= '<td>' . htmlspecialchars($order['date']) . '</td>';
        $html .= '<td>' . htmlspecialchars($order['shippingStatus']) . '</td>';
        $html .= '</tr>';
    }
} else {
    $html .= '<tr><td colspan="6">No orders found for this date range.</td></tr>';
}
$html .= '</tbody></table>';

$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Output('sales_report.pdf', 'I');
exit; 