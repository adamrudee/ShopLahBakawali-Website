<?php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
// Now you can use $pdo to query the 'customer' table

session_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $membershipId = $_POST['membershipId'];
    // Check membershipID in membership table
    $stmt = $pdo->prepare('SELECT membershipID FROM membership WHERE membershipID = ?');
    $stmt->bindParam(1, $membershipId);
    $stmt->execute();
    $membership = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($membership) {
        // Find customer with this membershipID
        $stmt2 = $pdo->prepare('SELECT * FROM customer WHERE membershipID = ?');
        $stmt2->execute([$membershipId]);
        $customer = $stmt2->fetch(PDO::FETCH_ASSOC);
        if ($customer) {
            $_SESSION['user_type'] = 'customer';
            $_SESSION['customerID'] = $customer['customerID'];
            $_SESSION['is_member'] = true;
            $_SESSION['membership_id'] = $membershipId;
            header("Location: ../2.Homes/MemberHome's.php");
            exit();
        } else {
            $error = "No customer found for this Membership ID.";
        }
    } else {
        $error = "Membership ID not found. Please check your ID or register.";
    }
}

// Logic to skip membership
if (isset($_GET['action']) && $_GET['action'] == 'skip') {
    $_SESSION['is_member'] = false;
    header("Location: ../2.Homes/NonMemberHome's.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Membership | ShopLahBakawali</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body::before {
      content: "";
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-image: url('bakawaliBuilding.png');
      background-size: cover;
      background-position: center;
      opacity: 0.4;
      z-index: -1;
    }
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #fcf8ed;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
    }
    .container {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
      width: 350px;
      padding: 30px;
      text-align: center;
      margin-top: 60px;
    }
    .form-logo {
      display: block;
      margin: 0 auto 15px auto;
      max-width: 250px;
      height: auto;
    }
    .title {
      color: #2E7D32;
      font-size: 20px;
      margin-bottom: 25px;
      font-weight: bold;
    }
    .input-group {
      margin-bottom: 25px;
    }
    .membership-input {
      width: 100%;
      padding: 12px 15px;
      border: 2px solid #ddd;
      border-radius: 5px;
      font-size: 16px;
      box-sizing: border-box;
    }
    .membership-input:focus {
      border-color: #FF6B00;
      outline: none;
    }
    .membership-input.error {
      border-color: #ff4444;
    }
    .error-message {
      color: #ff4444;
      font-size: 14px;
      margin-top: 5px;
    }
    .button-group {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
    }
    .btn {
      padding: 12px 0;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      flex: 1;
      margin: 0 5px;
      transition: all 0.3s;
    }
    .btn-enter {
      background-color: #FF6B00;
      color: white;
    }
    .btn-enter:hover {
      background-color: #1B5E20;
    }
    .btn-skip {
      background-color: #f8f8f8;
      color: #555;
      border: 1px solid #ccc;
    }
    .btn-skip:hover {
      background-color: #e0e0e0;
    }
    .membership-note {
      margin-top: 20px;
      font-size: 14px;
    }
    .nav-history {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="nav-history" style="margin-bottom: 20px;">
      <button type="button" class="back-forward-btn" onclick="window.history.back();">
        <i class="fa fa-arrow-left"></i> Back
      </button>
      <button type="button" class="back-forward-btn" onclick="window.history.forward();">
        Forward <i class="fa fa-arrow-right"></i>
      </button>
    </div>
    <img src="bakawaliLogo.png" alt="Shoplah Bakawali Logo" class="form-logo" />
    <div class="title">MEMBERSHIP</div>
    <form method="POST" action="Membership.php">
        <div class="input-group">
        <input type="text" name="membershipId" class="membership-input <?php if($error) echo 'error'; ?>" id="membershipId" placeholder="Enter Membership ID" required>
        <?php if ($error): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        </div>
        <div class="button-group">
            <button type="submit" class="btn btn-enter" id="enterBtn">ENTER</button>
            <a href="Membership.php?action=skip" class="btn btn-skip">SKIP</a>
        </div>
    </form>
    <div class="membership-note">
      Earn points and enjoy exclusive rewards with ShopLahBakawali! membership
    </div>
    <p style="text-align: center; margin-top: 20px; font-size: 14px;">
      Don't have an account? 
      <a href="RegistrationMembership.php" style="color: #0d6b34; text-decoration: underline;">Register here</a>
    </p>
  </div>
</body>
</html> 