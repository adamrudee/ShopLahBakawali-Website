<?php
session_start();

// Database connection for RegistrationMembership.php
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$error = '';
$success = '';
$customerID = isset($_SESSION['customerID']) ? $_SESSION['customerID'] : null;

// Fetch customer data for autofill
$customerData = ['fullname' => '', 'phoneNumber' => ''];
if ($customerID) {
    $stmt = $pdo->prepare("SELECT fullname, phoneNumber FROM customer WHERE customerID = ?");
    $stmt->execute([$customerID]);
    $customerData = $stmt->fetch(PDO::FETCH_ASSOC) ?: $customerData;
}

// POST/REDIRECT/GET pattern implementation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $customerID) {
    $fullname = $_POST['full_name'];
    $phone = $_POST['phone'];

    // Check if submitted values match database
    if ($fullname !== $customerData['fullname'] || $phone !== $customerData['phoneNumber']) {
        $error = "Name and phone number must match your original registration details.";
    } else {
    // 1. Create membership row
    $stmt = $pdo->prepare("INSERT INTO membership () VALUES ()");
    $stmt->execute();
    $membershipID = $pdo->lastInsertId();

    // 2. Update existing customer row
    $stmt = $pdo->prepare("UPDATE customer SET fullname=?, phoneNumber=?, membershipID=? WHERE customerID=?");
    $stmt->execute([$fullname, $phone, $membershipID, $customerID]);

    // Store membershipID in session and redirect
    $_SESSION['new_membership_id'] = $membershipID;
    header("Location: RegistrationMembership.php?success=1");
    exit();
    }
}

// On GET, check for session membershipID
$membershipID = '';
if (isset($_GET['success']) && isset($_SESSION['new_membership_id'])) {
    $membershipID = $_SESSION['new_membership_id'];
    unset($_SESSION['new_membership_id']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membership Registration | ShopLahBakawalit</title>
    <style>
        /* Reset default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        /* Background overlay */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('bakawaliBuilding.png');
            opacity: 0.4;
            z-index: -1;
        }
        
        /* Main body styles */
        body {
            background-color: #f8f8f8;
            color: #333;
        }
        
        /* Container styles */
        .container {
            max-width: 1000px;
            margin: 0 auto;
        }
        
        /* Logo styles */
        .form-logo {
            display: block;
            margin: 0 auto 70px auto;
            max-width: 250px;
            height: auto;
        }
        
        /* Registration section layout */
        .registration-section {
            display: flex;
            min-height: calc(100vh - 150px);
            align-items: center;
            padding: 50px 10px;
        }
        
        /* Registration container styles */
        .registration-container {
            display: flex;
            width: 100%;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        /* Left side benefits panel */
        .registration-image {
            flex: 1;
            background: linear-gradient(rgba(0,100,0,0.7), rgba(0,100,0,0.7)), 
                        url('https://images.unsplash.com/photo-1550583724-b2692b85b150');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .registration-image h2 {
            font-size: 32px;
            margin-bottom: 20px;
        }
        
        .registration-image p {
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        /* Benefits list styles */
        .benefits-list {
            list-style: none;
        }
        
        .benefits-list li {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
        }
        
        .benefits-list i {
            margin-right: 10px;
            color: #ffcc00;
            font-size: 20px;
        }
        
        /* Registration form styles */
        .registration-form {
            flex: 1;
            padding: 50px;
        }
        
        .form-header {
            margin-bottom: 30px;
        }
        
        .form-header h2 {
            font-size: 28px;
            color: #006400;
            margin-bottom: 10px;
        }
        
        .form-header p {
            color: #666;
        }
        
        /* Form input styles */
        .form-group {
            margin-bottom: 1px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 1px;
            font-weight: 500;
            color: #444;
        }
        
        .form-group input {
            width: 100%;
            padding: 8px 15px;
            border: 1px solid #ddd;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .form-group input:focus {
            border-color: #006400;
            outline: none;
            box-shadow: 0 0 0 3px rgba(0,100,0,0.1);
        }
        
        /* Form layout */
        .form-row {
            display: flex;
            gap: 15px;
        }
        
        .form-row .form-group {
            flex: 1;
        }
        
        /* Terms checkbox styles */
        .terms-check {
            display: flex;
            align-items: flex-start;
            margin-bottom: 25px;
        }
        
        .terms-check input {
            margin-right: 10px;
            margin-top: 3px;
        }
        
        .terms-check label {
            font-size: 14px;
            color: #666;
        }
        
        .terms-check label a {
            color: #006400;
            text-decoration: none;
        }
        
        .terms-check label a:hover {
            text-decoration: underline;
        }
        
        /* Register button styles */
        .register-btn {
            width: 100%;
            padding: 15px;
            background-color: #ffcc00;
            border: none;
            border-radius: 5px;
            color: #333;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .register-btn:hover {
            background-color: #e6b800;
        }

        .register-btn:disabled {
            background-color: #cccccc;
            color: #666666;
            cursor: not-allowed;
        }
        
        /* Responsive styles */
        @media (max-width: 768px) {
            .registration-container {
                flex-direction: column;
            }
            
            .registration-image {
                order: 2;
                padding: 30px;
            }
            
            .registration-form {
                order: 1;
                padding: 30px;
            }
            
            .form-row {
                flex-direction: column;
                gap: 0;
            }
        }
        /* Modal styles */
        .modal {
            display: none; /* Hidden by default */
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            justify-content: center;
            align-items: center;
            animation: modal-fadein 0.3s;
            /* Flexbox centering */
            display: flex;
        }
        @keyframes modal-fadein {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        .modal-content {
            background-color: #fff;
            margin: auto;
            padding: 40px 50px 30px 50px;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.2);
            text-align: center;
            min-width: 320px;
            max-width: 95vw;
            position: relative;
            /* Remove top/transform/scale/animation for flex centering */
        }
        /* Remove .modal-close styles */
        .modal-content button {
            margin-top: 20px;
            padding: 12px 32px;
            background-color: #ffcc00;
            border: none;
            border-radius: 6px;
            color: #333;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.2s, color 0.2s, transform 0.2s;
        }
        .modal-content button:hover {
            background-color: #e6b800;
            color: #222;
            transform: scale(1.05);
        }
        @media (max-width: 500px) {
            .modal-content {
                padding: 20px 10px 15px 10px;
                min-width: 0;
            }
        }
        .nav-history {
          display: flex;
          justify-content: center;
          gap: 10px;
          margin-bottom: 20px;
        }
        .back-forward-btn {
          background-color: #064e3b;
          color: white;
          border: none;
          border-radius: 6px;
          padding: 8px 16px;
          margin: 0 5px;
          cursor: pointer;
          font-size: 1rem;
          transition: background 0.2s;
        }
        .back-forward-btn:hover {
          background-color: #053a2c;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Registration Section -->
    <section class="registration-section">
      <div class="nav-history" style="margin-bottom: 20px;">
        <button type="button" class="back-forward-btn" onclick="window.history.back();">
          <i class="fa fa-arrow-left"></i> Back
        </button>
        <button type="button" class="back-forward-btn" onclick="window.history.forward();">
          Forward <i class="fa fa-arrow-right"></i>
        </button>
      </div>
        <div class="container">
            <div class="registration-container">
                <!-- Benefits Panel -->
                <div class="registration-image">
                    <img src="bakawaliLogo.png" alt="99 Speedmart Logo" class="form-logo" />
                    <h2>Join ShopLahBakawali Today!</h2>
                    <p>Become a member and enjoy exclusive benefits for your grocery shopping needs.</p>
                    
                    <ul class="benefits-list">
                        <li>
                            <i class="fas fa-percentage"></i>
                            <span>Enjoy exclusive 10% discounts for membership</span>
                        </li>
                        <li>
                            <i class="fas fa-star"></i>
                            <span>Enjoy discounts on every purchase</span>
                        </li>
                        <li>
                            <i class="fas fa-bolt"></i>
                            <span>Faster checkout process</span>
                        </li>
                        <li>
                            <i class="fas fa-bell"></i>
                            <span>Early access to promotions and new products</span>
                        </li>
                    </ul>
                </div>
                
                <!-- Registration Form -->
                <div class="registration-form">
                    <div class="form-header">
                        <h2>Create Your Account</h2>
                        <p>Fill in your details to register as a ShopLahBakawali membership</p>
                        <?php if ($error): ?>
                            <div style="color:red; margin-bottom:15px; font-weight:bold;">
                                <?php echo htmlspecialchars($error); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <form action="RegistrationMembership.php" method="POST" id="registrationForm">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="full-name">Full Name</label>
                                <input type="text" id="full-name" name="full_name" placeholder="John Doe" required value="<?php echo htmlspecialchars($customerData['fullname'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" placeholder="0123456789" required value="<?php echo htmlspecialchars($customerData['phoneNumber'] ?? ''); ?>">
                        </div>
                        <div class="terms-check">
                            <input type="checkbox" id="terms" required>
                            <label for="terms">I agree to the <a href="#">Terms of Service and Privacy Policy</a></label>
                        </div>
                        <button type="submit" class="register-btn" id="registerBtn" disabled>Register Now</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <div id="membershipModal" class="modal" style="display:<?php echo !empty($membershipID) ? 'flex' : 'none'; ?>;">
        <div class="modal-content">
            <h2>Registration Successful!</h2>
            <p>Your Membership ID is: <strong><?php echo $membershipID; ?></strong></p>
            <button onclick="window.location.href='Membership.php'">Okay</button>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const termsCheckbox = document.getElementById('terms');
            const registerBtn = document.getElementById('registerBtn');
            const form = document.getElementById('registrationForm');

            function updateButtonState() {
                registerBtn.disabled = !termsCheckbox.checked;
            }
            termsCheckbox.addEventListener('change', updateButtonState);
            updateButtonState();
        });
    </script>
</body>
</html>