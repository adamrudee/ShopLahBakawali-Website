<?php
// Inline database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shoplahbakawali";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$orders = [];
$totalCustomers = 0;
$totalSales = 0;
$startDate = '';
$endDate = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['generate_report'])) {
  $startDate = $_POST['start_date'];
  $endDate = $_POST['end_date'];

  if (!empty($startDate) && !empty($endDate)) {
    $stmt = $conn->prepare("SELECT c.checkoutID, c.fullName, c.email, c.finalPrice, c.date, t.shippingStatus 
                            FROM checkout c
                            JOIN tracking t ON t.checkoutID = c.checkoutID
                            WHERE c.date BETWEEN ? AND ?");
    $stmt->bind_param("ss", $startDate, $endDate);
    $stmt->execute();
    $result = $stmt->get_result();

    $emails = [];

    while ($row = $result->fetch_assoc()) {
      $orders[] = $row;
      if (!empty(trim($row['email']))) {
        $emails[] = strtolower(trim($row['email']));
      }
      $totalSales += $row['finalPrice'];
    }

    $totalCustomers = count(array_unique($emails));

    $adminID = 1; // Replace with session/admin logic if available
    $insertStmt = $conn->prepare("INSERT INTO salesreport (startDate, endDate, totalOrders, totalSales, adminID) VALUES (?, ?, ?, ?, ?)");
    $orderCount = count($orders);
    $insertStmt->bind_param("ssidi", $startDate, $endDate, $orderCount, $totalSales, $adminID);
    $insertStmt->execute();
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Generate Report | ShopLahBakawali</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #fcf8ed;
      margin: 0;
      padding: 0;
    }

    header {
      background-color: #064E3B;
      color: white;
      padding: 15px 30px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      position: relative;
      z-index: 1001;
    }

    .logo-container {
      display: flex;
      align-items: center;
      margin-right: auto;
    }

    .logo-container img {
      height: 50px;
      margin-right: 15px;
    }

    .logo-container h1 {
      font-size: 22px;
      margin: 0;
    }

    /* Sidebar styles */
    .sidebar {
      position: fixed;
      left: -250px;
      top: 0;
      height: 100%;
      width: 250px;
      background-color: #064E3B;
      color: white;
      padding-top: 80px;
      transition: left 0.3s ease;
      z-index: 1000;
    }

    .sidebar.open {
      left: 0;
    }

    .sidebar-menu {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .sidebar-menu li {
      margin: 0;
    }

    .sidebar-menu a {
      display: flex;
      align-items: center;
      padding: 15px 20px;
      color: white;
      text-decoration: none;
      transition: background-color 0.3s ease;
      border-left: 4px solid transparent;
    }

    .sidebar-menu a:hover {
      background-color: #0d6b4a;
    }

    .sidebar-menu a.active {
      background-color: #0d6b4a;
      border-left-color: #ff6b00;
    }

    .sidebar-menu i {
      margin-right: 15px;
      font-size: 18px;
      width: 20px;
      text-align: center;
    }

    .sidebar-menu span {
      font-weight: 500;
    }

    /* Main content */
    .main-content {
      margin-left: 0;
      padding: 20px;
      transition: margin-left 0.3s ease;
    }

    .main-content.sidebar-open {
      margin-left: 250px;
    }

    /* Menu toggle */
    .menu-toggle {
      background: none;
      border: none;
      color: white;
      font-size: 24px;
      cursor: pointer;
      padding: 10px;
      margin-right: 20px;
    }

    .menu-toggle:hover {
      background: none;
      color: white;
    }

    .container {
      max-width: 1000px;
      margin: 40px auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    h2 {
      margin-top: 0;
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      font-weight: bold;
      display: block;
      margin-bottom: 6px;
    }

    input[type="date"] {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      width: 100%;
      max-width: 300px;
    }

    button {
      background-color: #ff6b00;
      color: white;
      border: none;
      padding: 12px 20px;
      border-radius: 6px;
      cursor: pointer;
      font-weight: bold;
      margin-right: 10px;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #e65c00;
    }

    table {
      width: 100%;
      margin-top: 30px;
      border-collapse: collapse;
    }

    th, td {
      border: 1px solid #ddd;
      padding: 12px;
      text-align: left;
    }

    th {
      background-color: #f2f2f2;
    }

    /* Overlay for mobile */
    .sidebar-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 999;
    }

    .sidebar-overlay.open {
      display: block;
      }

    /* Modal styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 2000;
      left: 0;
      top: 0;
        width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }

    .modal-content {
      background-color: white;
      margin: 15% auto;
      padding: 0;
      border-radius: 12px;
      width: 90%;
      max-width: 400px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      animation: modalSlideIn 0.3s ease;
    }

    @keyframes modalSlideIn {
      from {
        opacity: 0;
        transform: translateY(-50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .modal-header {
      background-color: #064E3B;
      color: white;
      padding: 20px;
      border-radius: 12px 12px 0 0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .modal-header h3 {
      margin: 0;
      font-size: 18px;
    }

    .close {
      color: white;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
      line-height: 1;
    }

    .close:hover {
      opacity: 0.7;
    }

    .modal-body {
      padding: 30px 20px;
      text-align: center;
    }

    .modal-body p {
      margin: 0 0 25px 0;
      font-size: 16px;
      color: #333;
    }

    .modal-buttons {
      display: flex;
      gap: 15px;
      justify-content: center;
    }

    .btn-cancel, .btn-confirm {
      padding: 12px 25px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      transition: all 0.3s ease;
    }

    .btn-cancel {
      background-color: #6c757d;
      color: white;
    }

    .btn-cancel:hover {
      background-color: #5a6268;
    }

    .btn-confirm {
      background-color: #dc3545;
      color: white;
    }

    .btn-confirm:hover {
      background-color: #c82333;
    }

    /* Form styling */
    .form-row {
      display: flex;
      gap: 20px;
      margin-bottom: 15px;
    }

    .form-group {
      flex: 1;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-weight: 600;
      color: #333;
    }

    .form-group input {
      width: 100%;
      padding: 10px;
      font-size: 15px;
      border: 1px solid #ccc;
      border-radius: 8px;
      box-sizing: border-box;
    }

    .form-group input:focus {
      border-color: #ff6b00;
      outline: none;
      box-shadow: 0 0 0 2px rgba(255, 107, 0, 0.2);
    }

    .form-buttons {
      display: flex;
      gap: 15px;
      margin-top: 20px;
    }

    .btn-generate, .btn-export {
      padding: 12px 25px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      transition: all 0.3s ease;
    }

    .btn-generate {
      background-color: #ff6b00;
      color: white;
    }

    .btn-generate:hover {
      background-color: #e65c00;
    }

    .btn-export {
      background-color: #28a745;
      color: white;
    }

    .btn-export:hover {
      background-color: #218838;
    }

    /* Summary section */
    .summary-section {
      margin: 30px 0;
      padding: 20px;
      background-color: #f8f9fa;
      border-radius: 8px;
    }

    .summary-section h3 {
      margin-bottom: 20px;
      color: #333;
    }

    .summary-cards {
      display: flex;
      gap: 20px;
    }

    .summary-card {
      flex: 1;
      padding: 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      text-align: center;
    }

    .summary-card h4 {
      margin: 0 0 10px 0;
      color: #666;
      font-size: 14px;
    }

    .summary-card p {
      margin: 0;
      font-size: 24px;
      font-weight: bold;
      color: #ff6b00;
    }

    .table-container {
      margin-top: 30px;
    }

    .table-container h3 {
      margin-bottom: 15px;
      color: #333;
    }
  </style>
  <script defer>
    window.toggleSidebar = function() {
      document.getElementById('sidebar').classList.toggle('open');
      document.getElementById('mainContent').classList.toggle('sidebar-open');
    }

    function showGenerateReportConfirmation() {
      const startDate = document.getElementById('startDate').value;
      const endDate = document.getElementById('endDate').value;

      if (!startDate || !endDate) {
        alert("Please select both start and end dates.");
        return;
      }

      if (new Date(startDate) > new Date(endDate)) {
        alert("Start date cannot be after end date.");
        return;
      }

      document.getElementById('generateReportModal').style.display = 'block';
    }

    function confirmGenerateReport() {
      document.getElementById('generateReportForm').submit();
    }

    function showExportReportConfirmation() {
      document.getElementById('exportReportModal').style.display = 'block';
    }

    function confirmExportReport() {
      alert("PDF export functionality not implemented yet.");
      closeExportReportModal();
    }

    function closeGenerateReportModal() {
      document.getElementById('generateReportModal').style.display = 'none';
    }

    function closeExportReportModal() {
      document.getElementById('exportReportModal').style.display = 'none';
    }

    function showLogoutConfirmation() {
      document.getElementById('logoutModal').style.display = 'block';
    }

    function closeLogoutModal() {
      document.getElementById('logoutModal').style.display = 'none';
    }

    function logout() {
      window.location.href = "LoginForm.php";
    }

    window.addEventListener('click', function(event) {
      const modals = ['logoutModal', 'generateReportModal', 'exportReportModal'];
      modals.forEach(id => {
        const modal = document.getElementById(id);
        if (event.target === modal) modal.style.display = 'none';
      });
    });
  </script>
</head>
<body>

<header>
  <button class="menu-toggle" onclick="toggleSidebar()">
    <i class="fas fa-bars"></i>
  </button>
  <div class="logo-container">
    <a href="AdminHome.php">
      <img src="bakawaliLogo.png" alt="ShopLahBakawali Logo" />
    </a>
    <h1>Admin Dashboard - Generate Report</h1>
  </div>
</header>

<!-- Sidebar -->
<nav class="sidebar" id="sidebar">
  <ul class="sidebar-menu">
    <li><a href="AdminHome.php">
      <i class="fas fa-home"></i>
      <span>Dashboard</span>
    </a></li>
    <li><a href="AdminManageAccount.php">
      <i class="fas fa-users"></i>
      <span>Manage Account</span>
    </a></li>
    <li><a href="AdminManageproduct.php">
      <i class="fas fa-box"></i>
      <span>Manage Product</span>
    </a></li>
    <li><a href="AdminTrackorder.php">
      <i class="fas fa-truck"></i>
      <span>Track Order</span>
    </a></li>
    <li><a href="AdminGenerateSales.php" class="active">
      <i class="fas fa-chart-bar"></i>
      <span>Generate Sales</span>
    </a></li>
    <li><a href="#" onclick="showLogoutConfirmation()">
      <i class="fas fa-sign-out-alt"></i>
      <span>Logout</span>
    </a></li>
  </ul>
</nav>

<!-- Logout Confirmation Modal -->
<div id="logoutModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Confirm Logout</h3>
      <span class="close" onclick="closeLogoutModal()">&times;</span>
    </div>
    <div class="modal-body">
      <p>Are you sure you want to logout from your admin account?</p>
      <div class="modal-buttons">
        <button class="btn-cancel" onclick="closeLogoutModal()">Cancel</button>
        <button class="btn-confirm" onclick="logout()">Logout</button>
      </div>
    </div>
  </div>
</div>

<!-- Generate Report Confirmation Modal -->
<div id="generateReportModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Generate Sales Report</h3>
      <span class="close" onclick="closeGenerateReportModal()">&times;</span>
    </div>
    <div class="modal-body">
      <p>Are you sure you want to generate a sales report for the selected date range?</p>
      <div class="modal-buttons">
        <button class="btn-cancel" onclick="closeGenerateReportModal()">Cancel</button>
        <button class="btn-confirm" onclick="confirmGenerateReport()">Generate Report</button>
      </div>
    </div>
  </div>
  </div>

<!-- Export Report Confirmation Modal -->
<div id="exportReportModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h3>Export Sales Report</h3>
      <span class="close" onclick="closeExportReportModal()">&times;</span>
    </div>
    <div class="modal-body">
      <p>Are you sure you want to export the current sales report to PDF?</p>
      <div class="modal-buttons">
        <button class="btn-cancel" onclick="closeExportReportModal()">Cancel</button>
        <button class="btn-confirm" onclick="confirmExportReport()">Export to PDF</button>
      </div>
    </div>
  </div>
</div>

<div class="main-content" id="mainContent">
  <div class="container">
    <h2>Generate Sales Report</h2>
    <form method="POST" id="generateReportForm">
      <div class="form-row">
        <div class="form-group">
          <label for="startDate">Start Date *</label>
          <input type="date" name="start_date" id="startDate" value="<?= $startDate ?>" required />
        </div>
        <div class="form-group">
          <label for="endDate">End Date *</label>
          <input type="date" name="end_date" id="endDate" value="<?= $endDate ?>" required />
        </div>
      </div>
      <div class="form-buttons">
        <button type="submit" class="btn-generate">Generate Report</button>
        <button type="submit" formaction="exportSalesReport.php" formtarget="_blank" class="btn-export">Export to PDF</button>
        <input type="hidden" name="generate_report" value="1" />
      </div>
    </form>

    <?php if (!empty($orders)): ?>
    <div class="summary-section" id="summarySection">
      <h3>Sales Summary</h3>
      <div class="summary-cards">
        <div class="summary-card">
          <h4>Total Customers</h4>
          <p><?= $totalCustomers ?></p>
        </div>
        <div class="summary-card">
          <h4>Total Sales (RM)</h4>
          <p>RM <?= number_format($totalSales, 2) ?></p>
        </div>
      </div>
    </div>

    <div class="table-container" id="reportTableContainer">
      <h3>Detailed Report</h3>
      <table id="reportTable">
        <thead>
          <tr>
            <th>Order No</th>
            <th>Customer Name</th>
            <th>Customer Email</th>
            <th>Total Price (RM)</th>
            <th>Order Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($orders as $order): ?>
          <tr>
            <td><?= htmlspecialchars($order['checkoutID']) ?></td>
            <td><?= htmlspecialchars($order['fullName']) ?></td>
            <td><?= htmlspecialchars($order['email']) ?></td>
            <td>RM <?= number_format($order['finalPrice'], 2) ?></td>
            <td><?= htmlspecialchars($order['date']) ?></td>
            <td><?= htmlspecialchars($order['shippingStatus']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</div>

</body>
</html>
