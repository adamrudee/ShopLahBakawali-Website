<?php
session_start();

// Database connection
$host = 'localhost';
$dbname = 'shoplahbakawali';
$username = 'root';
$password = '';
$error = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = $_POST['email'] ?? '';
        $passwordInput = $_POST['password'] ?? '';
        $userType = $_POST['userType'] ?? 'Customer';

        if ($userType === 'Admin') {
            $stmt = $pdo->prepare('SELECT * FROM admin WHERE email = ?');
        } else {
            $stmt = $pdo->prepare('SELECT * FROM customer WHERE email = ?');
        }
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && (
                password_verify($passwordInput, $user['password']) 
                || $passwordInput === $user['password']           
            )) {
            if ($userType === 'Admin') {
                $_SESSION['user_type'] = 'admin';
                $_SESSION['adminID'] = $user['adminID'];
                $_SESSION['role'] = 'admin'; // Ensure admin role is set
                header('Location: AdminHome.php');
                exit;
            } else {
                $_SESSION['user_type'] = 'customer';
                $_SESSION['customerID'] = $user['customerID'];
                // Check if customer is a member
                if (!empty($user['membershipID'])) {
                    $_SESSION['is_member'] = true;
                    $_SESSION['membership_id'] = $user['membershipID'];
                    header("Location: ../2.Homes/MemberHome's.php");
                    exit;
                } else {
                    // Not a member yet
                    $_SESSION['is_member'] = false;
                    unset($_SESSION['membership_id']);
                    header('Location: Membership.php');
                    exit;
                }
            }
        } else {
            $error = 'Invalid email or password.';
        }
    }
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login | ShopLahBakawali</title>
  <!-- Font Awesome CDN for eye icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body::before {
      content: "";
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-image: url('bakawaliBuilding.png');
      background-size: cover;
      background-position: center;
      opacity: 0.4;
      z-index: -1;
    }
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #fcf8ed;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
    }
    .container {
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      display: flex;
      flex-direction: column;
      align-items: center;
      overflow: hidden;
      max-width: 500px;
      width: 90%;
      margin: 60px auto;
      padding: 60px;
    }
    .form-logo {
      max-width: 300px;
      margin-bottom: 10px;
    }
    .user-type-selector {
      display: flex;
      justify-content: center;
      margin-bottom: 30px;
      width: 100%;
      max-width: 360px;
    }
    .user-type-btn {
      flex: 1;
      padding: 12px 20px;
      border: 4px solid #e0e0e0;
      background-color: #f5f5f5;
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 15px;
      font-weight: 600;
    }
    .user-type-btn.active {
      background-color: #085c46;
      color: white;
      border-color: white;
    }
    .user-type-btn:first-child {
      border-radius: 25px 0 0 25px;
    }
    .user-type-btn:last-child {
      border-radius: 0 25px 25px 0;
    }
    form {
      width: 100%;
      max-width: 360px;
    }
    input[type="email"],
    input[type="password"],
    input[type="text"] {
      width: 100%;
      padding: 16px;
      margin: 10px 0;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      font-size: 15px;
      transition: border-color 0.3s ease;
      box-sizing: border-box;
    }
    input[type="email"]:focus,
    input[type="password"]:focus,
    input[type="text"]:focus {
      border-color: #ff6b00;
      outline: none;
    }
    button[type="submit"] {
      width: 100%;
      padding: 14px;
      background-color: #ff6b00;
      color: white;
      border: none;
      border-radius: 25px;
      font-size: 16px;
      font-weight: 600;
      margin-top: 20px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    button[type="submit"]:hover {
      background-color: #e65c00;
    }
    p {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
    }
    p a {
      color: #0d6b34;
      text-decoration: underline;
    }
    @media (max-width: 768px) {
      .container {
        width: 85%;
        padding: 30px 20px;
        margin: 20px auto;
      }
      .user-type-btn {
        font-size: 14px;
        padding: 10px 15px;
      }
      form {
        max-width: 100%;
      }
    }
    input[type="password"] {
      position: relative;
    }
    .password-wrapper {
      position: relative;
      width: 100%;
    }
    .toggle-password {
      position: absolute;
      top: 50%;
      right: 16px;
      transform: translateY(-50%);
      cursor: pointer;
      color: #888;
      font-size: 18px;
      z-index: 2;
    }
    .nav-history {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 20px;
    }
    .back-forward-btn {
      background-color: #064e3b;
      color: white;
      border: none;
      border-radius: 6px;
      padding: 8px 16px;
      margin: 0 5px;
      cursor: pointer;
      font-size: 1rem;
      transition: background 0.2s;
    }
    .back-forward-btn:hover {
      background-color: #053a2c;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="nav-history" style="margin-bottom: 20px;">
      <button type="button" class="back-forward-btn" onclick="window.history.back();">
        <i class="fa fa-arrow-left"></i> Back
      </button>
      <button type="button" class="back-forward-btn" onclick="window.history.forward();">
        Forward <i class="fa fa-arrow-right"></i>
      </button>
    </div>
    <img src="bakawaliLogo.png" alt="bakawali logo" class="form-logo" />
    <?php if ($error): ?>
      <div style="color:red; margin-bottom:15px; font-weight:bold;">
        <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>
    <div class="user-type-selector">
      <button type="button" class="user-type-btn active" data-type="Customer">Customer</button>
      <button type="button" class="user-type-btn" data-type="Admin">Admin</button>
    </div>

    <form id="loginForm" action="LoginForm.php" method="post">
      <input type="hidden" name="userType" id="userType" value="Customer" />
      <input type="email" name="email" id="email" placeholder="Email Address" required />
      <div class="password-wrapper">
        <input type="password" name="password" id="password" placeholder="Password" required />
        <span class="toggle-password" id="togglePassword">
          <i class="fa-regular fa-eye-slash" id="eyeIcon"></i>
        </span>
      </div>
      <button type="submit">Login</button>
      <div id="error-message" style="color: red; margin-top: 10px; display: none;"></div>
    </form>

    <p id="register-link">
      Don't have an account? 
      <a href="RegistrationAccount.php">Register here</a>
    </p>
  </div>
  <script>
  const userTypeButtons = document.querySelectorAll('.user-type-btn');
  const userTypeInput = document.getElementById('userType');
  const togglePassword = document.getElementById('togglePassword');
  const passwordInput = document.getElementById('password');
  const eyeIcon = document.getElementById('eyeIcon');

  // User type selection
  userTypeButtons.forEach(button => {
    button.addEventListener('click', () => {
      userTypeButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      userTypeInput.value = button.getAttribute('data-type');
      // Show/hide register link based on user type
      const registerLink = document.getElementById('register-link');
      if (button.getAttribute('data-type') === 'Admin') {
        registerLink.style.display = 'none';
      } else {
        registerLink.style.display = '';
      }
    });
  });
  // Set initial state for register link
  document.addEventListener('DOMContentLoaded', () => {
    const registerLink = document.getElementById('register-link');
    registerLink.style.display = '';
  });

  // Toggle password visibility
  togglePassword.addEventListener('click', () => {
    const isPassword = passwordInput.type === 'password';
    passwordInput.type = isPassword ? 'text' : 'password';
    eyeIcon.classList.toggle('fa-eye');
    eyeIcon.classList.toggle('fa-eye-slash');
  });
</script>
</body>
</html> 